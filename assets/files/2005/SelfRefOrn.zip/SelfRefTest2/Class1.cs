using System;
using System.Data;
using System.Data.SqlClient;

namespace SelfRefTest2
{
	class Worker
	{
		SqlConnection con=new SqlConnection("data source=BURKI;database=Veritabanim;integrated security=SSPI");
		SqlDataAdapter da;
		DataSet ds;		
		DataRelation dr;
 
		public void Baglan()
		{
			if(con.State==ConnectionState.Closed)
				con.Open();
		}

		public void VeriCek()
		{
			da=new SqlDataAdapter("SELECT * FROM Kadro",con);
			ds=new DataSet();			
			da.Fill(ds);
			dr=new DataRelation("self",ds.Tables[0].Columns["PersonelNo"],ds.Tables[0].Columns["Amiri"],false);
			ds.Relations.Add(dr);
		}

		public void DetayiniAl(DataRow dr,string giris)
		{
			Console.WriteLine(giris+dr["Personel"].ToString());	
			foreach(DataRow drChild in dr.GetChildRows("self"))
			{
				DetayiniAl(drChild,giris+"...");
			}
		}

		public void AgacOlustur()
		{
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				if(dr.IsNull("Amiri"))
				{
					DetayiniAl(dr,"");
				}
			}
		}
	}

	class Class1
	{
		[STAThread]
		static void Main(string[] args)
		{
			Worker wrk=new Worker();
			wrk.Baglan();
			wrk.VeriCek();
			wrk.AgacOlustur();
		}
	}
}
