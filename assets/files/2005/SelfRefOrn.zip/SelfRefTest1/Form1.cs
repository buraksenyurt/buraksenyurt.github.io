using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace SelfRefTest1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.SuspendLayout();
			// 
			// treeView1
			// 
			this.treeView1.ImageIndex = -1;
			this.treeView1.Location = new System.Drawing.Point(8, 8);
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.Size = new System.Drawing.Size(256, 288);
			this.treeView1.TabIndex = 2;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(280, 317);
			this.Controls.Add(this.treeView1);
			this.Name = "Form1";
			this.Text = "Hiyerarsik Yapi";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}		
		private System.Windows.Forms.TreeView treeView1;

		SqlConnection con=new SqlConnection("data source=BURKI;database=Veritabanim;integrated security=SSPI");
		SqlDataAdapter da;
		DataSet ds;		
		DataRelation dr;
 
        private void Baglan()
		{
			if(con.State==ConnectionState.Closed)
				con.Open();
		}

		private void VeriCek()
		{
			da=new SqlDataAdapter("SELECT * FROM Kadro",con);
			ds=new DataSet();			
			da.Fill(ds);
			dr=new DataRelation("self",ds.Tables[0].Columns["PersonelNo"],ds.Tables[0].Columns["Amiri"],false);
			ds.Relations.Add(dr);
		}

		private void DetayiniAl(DataRow dr,TreeNode t)
		{
			foreach(DataRow drChild in dr.GetChildRows("self"))
			{
				TreeNode tnChild=new TreeNode(drChild["Personel"].ToString());
				t.Nodes.Add(tnChild);
				DetayiniAl(drChild,tnChild);
			}
		}

		private void AgacOlustur()
		{
			foreach(DataRow dr in ds.Tables[0].Rows)
			{
				if(dr.IsNull("Amiri"))
				{
					TreeNode tn=new TreeNode(dr["Personel"].ToString());
					treeView1.Nodes.Add(tn);
					DetayiniAl(dr,tn);
				}
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			Baglan();
			VeriCek();
			AgacOlustur();
		}
	}
}
