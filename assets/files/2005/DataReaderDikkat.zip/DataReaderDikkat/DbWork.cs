using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace DataReaderDikkat
{
	public class DbWork
	{
		private SqlConnection con;
		private SqlDataReader dr;
		
		/* CloseConnection kullan�m�na �rnek metod.*/
		public DbWork(string conStr)
		{	
			con=new SqlConnection(conStr);
		}
		
		public SqlDataReader Results(string selectQuery)
		{
			SqlCommand cmd=new SqlCommand(selectQuery,con);
			con.Open();
			dr=cmd.ExecuteReader(CommandBehavior.CloseConnection); // Do�ru Kullan�m.
//			dr=cmd.ExecuteReader(); // Hatal� kullan�m.
			return dr;			
		}

		public SqlDataReader GetRow(string FindQuery,int orderID)
		{
			SqlCommand cmd=new SqlCommand(FindQuery,con);
			cmd.Parameters.Add("@OrderID",SqlDbType.Int);
			cmd.Parameters["@OrderID"].Value=orderID;
			con.Open();
			dr=cmd.ExecuteReader((CommandBehavior)40);
			return dr;
		}
		
		public SqlDataReader BatchResults(string[] sorgular)
		{
			StringBuilder sbSorgular=new StringBuilder();
			for(int i=0;i<sorgular.Length;i++)
			{
				sbSorgular.Append(sorgular[i]+";");	
			}
			SqlCommand cmd=new SqlCommand(sbSorgular.ToString(),con);
			con.Open();
			SqlDataReader dr=cmd.ExecuteReader(CommandBehavior.CloseConnection);
			return dr;
		}

		public SqlDataReader ReadText(string Query)
		{
			SqlCommand cmd=new SqlCommand(Query,con);
			con.Open();
			dr=cmd.ExecuteReader((CommandBehavior)48); 
			return dr;		
		}
	}
}
