using System;
using System.Data;
using System.Data.SqlClient;

namespace DataReaderDikkat
{
	class ClosingDataReader
	{		
		[STAThread]
		static void Main(string[] args)
		{				
			DbWork worker=new DbWork("data source=BURKI;database=Northwind;integrated security=SSPI");

			#region CloseConnection Kullan�n.
			
			SqlDataReader drOrders=worker.Results("SELECT TOP 10 * FROM Orders");
			while(drOrders.Read())
			{
				Console.WriteLine(drOrders[0].ToString()+" "+drOrders[1].ToString());
			}
			drOrders.Close();
			SqlDataReader drCustomers=worker.Results("SELECT TOP 10 * FROM Customers");
			while(drCustomers.Read())
			{
				Console.WriteLine(drCustomers[0].ToString()+" "+drCustomers[1].ToString());
			}
			drCustomers.Close();
			#endregion

			#region SingleRow Kullan�n.
			SqlDataReader drFind=worker.GetRow("SELECT * FROM Orders WHERE OrderID=@OrderID",10248);
			drFind.Read();
			Console.WriteLine("BULUNAN SATIR "+drFind[0].ToString());
			drFind.Close();

			drFind=worker.GetRow("SELECT * FROM Orders WHERE OrderID=@OrderID",10249);
			drFind.Read();
			Console.WriteLine("BULUNAN SATIR "+drFind[0].ToString());
			drFind.Close();
			#endregion
		
			#region BatchQuery' lerde
			string[] sorguKumesi={"SELECT TOP 5 * FROM Orders","SELECT TOP 5 * FROM Customers","SELECT TOP 5 * FROM [Order Details]"};
			SqlDataReader drToplu=worker.BatchResults(sorguKumesi);
			do
			{
				while(drToplu.Read())
				{
					Console.WriteLine(drToplu[0].ToString()+" "+drToplu[1].ToString());
				}
				Console.WriteLine("------------");
			}while(drToplu.NextResult());
			drToplu.Close();
			#endregion
			
			#region SequentialAccess Kullan�n.
			SqlDataReader drText=worker.ReadText("SELECT CategoryName,Description,Picture FROM Categories");
			char[] tampon=new char[150];
			while(drText.Read())			
			{				
				drText.GetChars(1,0,tampon,0,150);
				for(int i=0;i<150;i++)
				{
					Console.Write(tampon[i].ToString());
				}
				Console.WriteLine();
			}			
			#endregion
		}
	}
}
