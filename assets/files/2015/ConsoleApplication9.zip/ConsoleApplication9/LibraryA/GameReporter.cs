﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryA
{
    public abstract class GameReporter
    {
        public void GetResults()
        {
            Console.WriteLine("Oyuncuların istatistikleri toplanıyor");
        }

        public void ParseResults()
        {
            Console.WriteLine("İstatistikler ayrıştırılıyor");
        }

        public abstract void WriteResults();

        public void ExportFormatedData()
        {
            GetResults();
            ParseResults();
            WriteResults();
        }
    }
}
