﻿using System;
using LibraryA;
using LibraryB;

namespace ConsoleApplication9
{
    class Program
    {
        static void Main(string[] args)
        {
            GameReporter reporter = null;

            reporter = new XmlReporter();
            reporter.ExportFormatedData();
            Console.WriteLine();

            reporter = new TextReporter();
            reporter.ExportFormatedData();
            Console.WriteLine();

            reporter = new ConsoleReporter();
            reporter.ExportFormatedData();
        }
    }
}
