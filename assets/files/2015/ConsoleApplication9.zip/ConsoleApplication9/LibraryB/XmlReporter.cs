﻿using System;
using LibraryA;

namespace LibraryB
{
    public class XmlReporter
        : GameReporter
    {
        public override void WriteResults()
        {
            Console.WriteLine("İstatistikler XML dosyasına yazılıyor.");
        }
    }
}
