﻿using System;
using LibraryA;

namespace LibraryB
{
    public class ConsoleReporter
        : GameReporter
    {
        public override void WriteResults()
        {
            Console.WriteLine("İstatistikler Console ekranına basılıyor.");
        }
    }
}
