﻿using System;
using LibraryA;

namespace LibraryB
{
    public class TextReporter
        : GameReporter
    {
        public override void WriteResults()
        {
            Console.WriteLine("İstatistikler text dosyasına yazdırılıyor.");
        }
    }
}
