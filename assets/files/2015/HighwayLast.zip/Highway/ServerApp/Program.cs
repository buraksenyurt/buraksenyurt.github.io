﻿using HighwayServiceLibrary;
using System;
using System.ServiceModel;

namespace ServerApp
{
    class Program
    {
        static void Main(string[] args)
        {
            using(ServiceHost host=new ServiceHost(typeof(EchoService)))
            {
                host.Open();
                Console.WriteLine(@"Uygulama sunucusunu durumu: ""{0}"" ",host.State);
                Console.WriteLine("Uygulama sunucusunu kapatmak için bir tuşa basınız.");
                Console.ReadLine();
                host.Close();
            }
        }
    }
}
