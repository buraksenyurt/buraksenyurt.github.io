﻿using Highway.ClientApp.EchoSpace;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Highway.ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Başlamak için bir tuşa basınız");
            Console.ReadLine();

            string testData = CreateRandomString();

            Dictionary<EchoServiceClient,string> proxies = new Dictionary<EchoServiceClient,string>
            {
                {new EchoServiceClient("UdpBinding_IEchoService"),"UDP"},
                {new EchoServiceClient("BasicHttpBinding_IEchoService"),"BASIC HTTP"},
                {new EchoServiceClient("WSHttpBinding_IEchoService"),"WS HTTP"},
                {new EchoServiceClient("NetTcpBinding_IEchoService"),"NET TCP"},
            };

            foreach (var proxy in proxies)
            {
                for (int i = 1; i < 5; i++)
                {
                    Executer(proxy.Key, proxy.Value, i * 10000, testData);
                }
                proxy.Key.Close();
            }
        }

        static void Executer(EchoServiceClient proxy,string title,int tryCount,string testData)
        {
            Stopwatch watcher = new Stopwatch();

            watcher.Start();

            for (int i = 0; i < tryCount; i++)
            {
                //proxy.SendEcho(testData);
                proxy.GetEcho(1);
            }

            watcher.Stop();
            Console.WriteLine("{0} Total Milliseconds {1}",title, watcher.ElapsedMilliseconds.ToString());
        }

        static string CreateRandomString()
        {
            char[] charachters = new char[65507];
            for (int i = 0; i < charachters.Length; i++)
            {
                charachters[i] = 'S';
            }
            return new string(charachters);
        }
    }
}
