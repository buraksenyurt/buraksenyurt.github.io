﻿
namespace HighwayServiceLibrary
{
    public class EchoService
        :IEchoService
    {
        public void SendEcho(string content)
        {
            //Do Something
        }

        public string GetEcho(int length)
        {
            return "S";
        }
    }
}
