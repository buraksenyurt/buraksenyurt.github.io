﻿using System.ServiceModel;

namespace HighwayServiceLibrary
{
    [ServiceContract]
    public interface IEchoService
    {
        [OperationContract(IsOneWay=true)]
        void SendEcho(string content);

        [OperationContract]
        string GetEcho(int length);
    }
}

