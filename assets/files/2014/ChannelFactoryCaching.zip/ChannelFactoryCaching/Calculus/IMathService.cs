﻿using System.ServiceModel;

namespace Calculus
{
    
    [ServiceContract]
    public interface IMathService
    {
        [OperationContract]
        double Sum(int x,int y);
    }
}
