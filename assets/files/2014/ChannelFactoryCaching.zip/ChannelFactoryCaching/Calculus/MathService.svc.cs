﻿using System;

namespace Calculus
{
    public class MathService 
        : IMathService
    {
        public double Sum(int x, int y)
        {
            return x + y;
        }
    }
}
