﻿using Student.clcls;
using System;
using System.ServiceModel;

namespace Student
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Standart proxy kullanımı

            //MathServiceClient proxy = new MathServiceClient("BasicHttpBinding_IMathService");
            //double result=proxy.Sum(3, 4);
            //Console.WriteLine(result.ToString());
            //proxy.Close();

            #endregion

            #region Channel Factory kullanımı

            //ChannelFactory<IMathService> factory = new ChannelFactory<IMathService>("BasicHttpBinding_IMathService");
            //IMathService channel = factory.CreateChannel();
            //double result = channel.Sum(3, 4);
            //Console.WriteLine(result.ToString());
            //((IClientChannel)channel).Close();

            #endregion

            #region Caching Kullanımı

            ClientBase<IMathServiceChannel>.CacheSetting = CacheSetting.AlwaysOn;
            for (int i = 0; i < 5; i++)
            {
                MathServiceClient client = new MathServiceClient(
                    new BasicHttpBinding()
                    , new EndpointAddress("http://localhost:54837/MathService.svc")
                    );
                double result = client.Sum(i, 5);
                // İlk kullanımda kanal bilgisi cache' lenmiş durumda. Dolayısıyla sonraki çağrıda maliyet minimuma indirgenmiş olacak.
                Console.WriteLine("{0}", result.ToString());
            }

            #endregion
        }
    }
}
