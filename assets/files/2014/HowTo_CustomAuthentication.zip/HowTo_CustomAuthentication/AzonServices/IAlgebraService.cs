﻿using System.ServiceModel;

namespace AzonServices
{
    [ServiceContract]
    public interface IAlgebraService
    {
        [OperationContract]
        double Sum(double x, double y);
    }
}
