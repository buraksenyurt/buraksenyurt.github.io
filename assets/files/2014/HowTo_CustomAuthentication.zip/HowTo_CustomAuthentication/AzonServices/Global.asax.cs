﻿using System;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Web;
using System.Web.ApplicationServices;
using System.Web.Security;

namespace AzonServices
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            AuthenticationService.Authenticating +=new EventHandler<AuthenticatingEventArgs>(Authenticating);
        }

        private void Authenticating(object sender, AuthenticatingEventArgs e)
        {
            SpecialValidator validator = new SpecialValidator();
            List<string> roles = null;

            e.Authenticated = validator.IsUserValid(e.UserName, e.Password,out roles);
            e.AuthenticationIsComplete = true;

            if (e.Authenticated)
            {
                HttpCookie newCookie = new HttpCookie(FormsAuthentication.FormsCookieName);
                newCookie.Value = e.UserName+"|"+CreateRolesString(roles);

                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, e.UserName, DateTime.Now, DateTime.Now.AddHours(24), true, CreateRolesString(roles), FormsAuthentication.FormsCookiePath);
                string encryptedValue = FormsAuthentication.Encrypt(ticket);

                HttpResponseMessageProperty response = new HttpResponseMessageProperty();
                response.Headers[HttpResponseHeader.SetCookie] = FormsAuthentication.FormsCookieName + "=" + encryptedValue;
                OperationContext.Current.OutgoingMessageProperties[HttpResponseMessageProperty.Name] = response;
            }
        }

        public string CreateRolesString(List<string> roles)
        {
            string result = string.Empty;

            foreach (string role in roles)
            {
                result += role + "|";
            }

            return result.TrimEnd('|');
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}