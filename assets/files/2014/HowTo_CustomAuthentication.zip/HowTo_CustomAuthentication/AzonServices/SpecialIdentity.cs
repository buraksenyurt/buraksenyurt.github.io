﻿using System.Security.Principal;

namespace AzonServices
{
    public class SpecialIdentity
        :IIdentity
    {
        public string Name { get; set; }
        public bool IsAuthenticated { get; set; }
        public string AuthenticationType { get; set; }
    }
}
