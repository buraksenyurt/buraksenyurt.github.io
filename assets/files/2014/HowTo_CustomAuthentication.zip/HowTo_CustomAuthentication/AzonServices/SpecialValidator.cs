﻿
using System.Collections.Generic;
namespace AzonServices
{
    public class SpecialValidator
    {
        public bool IsUserValid(string userName, string password,out List<string> roles)
        {
            bool result = false;
            roles = new List<string>();

            // Burada pek tabi istenen herhangibir Membership Provider kullanımı sağlanabilir. Örneğin bir Oracle veritabanına veya NoSQL dosyasına gidilebilir. Ya da bir SSO hizmetine başvurulabilir. Hayal gücü sizin. Üretin
            if(userName == "burak" && password == "P@ssw0rd!")
            {
                result=true;
                roles.Add("Contributor");
                roles.Add("Administrator");
            }

            return result;
        }
    }
}
