﻿using System.Security.Permissions;
using System.Security.Principal;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;
using System.Threading;
using System.Web.Security;

namespace AzonServices
{
    [AspNetCompatibilityRequirements(RequirementsMode =AspNetCompatibilityRequirementsMode.Allowed)]
    public class AlgebraService 
        : IAlgebraService
    {
        public AlgebraService()
        {
            var messageProperty = (HttpRequestMessageProperty)OperationContext
                .Current
                .IncomingMessageProperties[HttpRequestMessageProperty.Name];

            string[] cookieParts=messageProperty.Headers.Get("Set-Cookie").Split(',');
            FormsAuthenticationTicket ticket = null;
            for (int i = 0; i < cookieParts.Length; i++)
			{
                if (cookieParts[i].Contains("SecuredCookie"))
                {
                    ticket = FormsAuthentication.Decrypt(cookieParts[i].Split('=')[1]);
                }
			}            
            
            SpecialIdentity customIdentity = new SpecialIdentity
            {
                Name = ticket.Name,
                 IsAuthenticated=true
            };
            GenericPrincipal threadCurrentPrincipal = new GenericPrincipal(customIdentity,ticket.UserData.Split('|'));
            Thread.CurrentPrincipal = threadCurrentPrincipal;
        }

        [PrincipalPermission(SecurityAction.Demand,Role="Contributor")]
        public double Sum(double x, double y)
        {
            return x + y;
        }
    }
}
