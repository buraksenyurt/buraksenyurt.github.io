﻿using ClientApp.MathSpace;
using ClientApp.MembershipSpace;
using System;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string cookie=string.Empty;
            // Önce login olmayı deniyoruz
            if (AuthenticateMember(ref cookie, "burak", "P@ssw0rd!"))
            {
                Console.WriteLine("{0}\n",cookie);
                try
                {
                    // Aynı member cookie için arka arkaya 3 test yapmaktayız.
                    CallSum(cookie, 4, 5);
                    CallSum(cookie, 6, 7);
                    CallSum(cookie, 1, -9);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);                    
                }
            }
            else
            {
                Console.WriteLine("Doğrulama işlemi başarısız olduğundan uygulama sonlanacaktır");
                return;
            }
        }

        // Servis metod çağrısı
        private static void CallSum(string cookie,double x,double y)
        {
            // AlgebraService' e ait bir örnek oluşturulur
            AlgebraServiceClient einstein = new AlgebraServiceClient("BasicHttpBinding_IAlgebraService");

            // Güncel kanal bilgisi üzerinden
            using (new OperationContextScope(einstein.InnerChannel))
            {
                // Request için gidecek mesaj özelliğinin içerisine az önce doğrulama servisinin gönderdiği member cookie gömülür.
                HttpRequestMessageProperty request = new HttpRequestMessageProperty();
                request.Headers[HttpResponseHeader.SetCookie] = cookie;
                OperationContext.Current.OutgoingMessageProperties[HttpRequestMessageProperty.Name] = request;

                Console.WriteLine("{0}+{1}={2}", x, y, einstein.Sum(x, y).ToString());
            }
        }

        // Login işlemini üstlenen fonksiyon
        private static bool AuthenticateMember(ref string cookie,string username,string password)
        {
            // AuthenticationService proxy örneği üretilir
            AuthenticationServiceClient authenticator = new AuthenticationServiceClient("BasicHttpBinding_AuthenticationService");
            bool result = false;

            // Güncel kanal bilgisi üzerinden
            using (new OperationContextScope(authenticator.InnerChannel))
            {
                // ValidateUser ile kullanıcı doğrulanmaya çalışılır
                result=authenticator.ValidateUser(username,password, string.Empty);
                // Dönen mesajın içerisinden gelen Cookie bilgisi yakalanır
                var responseMessageProperty = (HttpResponseMessageProperty)OperationContext.Current.IncomingMessageProperties[HttpResponseMessageProperty.Name];
                if (result)
                {
                    cookie = responseMessageProperty.Headers.Get("Set-Cookie");
                }
            }
            return result;
        }
    }
}
