﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace HowTo_ObservableCollection
{
    public class BookList
        :ObservableCollection<Book>
    {
        public BookList()
            :base()
        {
            Add(
                new Book 
                {   
                    BookId = 1
                    , Title = "Advanced WCF Programming"
                    , Producer = "Maybe Me"
                    , PageSize = 1280 
                }
                );
            Add(
                new Book 
                { 
                    BookId = 2, 
                    Title = "SOA: from a Developer Vision", 
                    Producer = "Maybe Me", 
                    PageSize = 740 
                }
                );
        }
    }
}
