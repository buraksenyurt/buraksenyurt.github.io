﻿using System.Windows;

namespace HowTo_ObservableCollection
{
    public partial class MainWindow 
        : Window
    {
        BookList sourceList = null;

        public MainWindow()
        {
            InitializeComponent();

            sourceList = ListBoxBooks.ItemsSource as BookList;
        }

        private void ButtonAdd_Click_1(object sender, RoutedEventArgs e)
        {
            sourceList.Add(new Book
            {
                BookId=94,
                 Title="Starwars Clone Wars",
                  Producer="Lucas Arts",
                   PageSize=180
            }
            );
        }

        private void ButtonRemove_Click_1(object sender, RoutedEventArgs e)
        {
            sourceList.RemoveAt(0);
            //ListBoxBooks.Items.RemoveAt(0); // Yorum satırını açıp bir deneyin bakalım ne olacak?
        }

        private void ButtonChange_Click_1(object sender, RoutedEventArgs e)
        {
            sourceList[1].Title = "Changed...";
        }
    }
}
