﻿namespace HowTo_ObservableCollection
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public int PageSize { get; set; }
        public string Producer { get; set; }
    }
}
