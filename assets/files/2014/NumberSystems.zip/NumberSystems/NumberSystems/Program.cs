﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;

namespace NumberSystems
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Giriş

            //int number1 = 78;
            //string number1Binary = Convert.ToString(number1, 2);
            //string number1Hexadecimal = Convert.ToString(number1, 16);

            //Console.WriteLine("Decimal to Binary/Hexadecimal\n{0}\t=\t{1}\n{2}\t=\t{3}\n"
            //    , number1
            //    , number1Binary
            //    , number1
            //    , number1Hexadecimal
            //    );

            //int number2 = Convert.ToInt32(number1Binary, 2);
            //int number3 = Convert.ToInt32(number1Hexadecimal, 16);

            //Console.WriteLine("Binary/Hexadecimal to Decimal\n{0}\t=\t{1}\n{2}\t=\t{3}\n"
            //    , number1Binary
            //    , number2
            //    , number1Hexadecimal
            //    , number3
            //    );

            #endregion

            string fileDecimal = Path.Combine(Environment.CurrentDirectory, "Decimal.txt");
            string fileBinary = Path.Combine(Environment.CurrentDirectory, "Binary.txt");
            string fileHexadecimal = Path.Combine(Environment.CurrentDirectory, "Hexadecimal.txt");

            for (int i = 4; i < 8; i++)
            {
                int length = (int)Math.Pow(10, i);
                Console.WriteLine(length);
                List<int> numbers = GetRandomNumbers(10000000, 90000000, length);
                WriteToFile(fileDecimal, numbers, BaseType.Decimal);
                WriteToFile(fileBinary, numbers, BaseType.Binary);
                WriteToFile(fileHexadecimal, numbers, BaseType.Hexadecimal);
                Console.WriteLine("---");
            }
        }

        private static List<int> GetRandomNumbers(int initialValue, int lastValue, int arrayLength)
        {
            List<int> numbers = new List<int>();

            Random random = new Random();
            for (int i = 0; i < arrayLength; i++)
            {
                numbers.Add(random.Next(initialValue, lastValue));
            }

            return numbers;
        }
        private static void WriteToFile(string fileName, List<int> numbers, BaseType baseType)
        {
            StringBuilder builder = new StringBuilder();
            Stopwatch watcher = new Stopwatch();

            for (int i = 0; i < numbers.Count; i++)
            {
                builder.AppendLine(Convert.ToString(numbers[i], (int)baseType));
            }

            watcher.Start();
            File.WriteAllText(fileName, builder.ToString());
            watcher.Stop();
            FileInfo fi=new FileInfo(fileName);
            Console.WriteLine(
                "{0}\tSize:{1}\tProcess Time:{2}"
                ,Path.GetFileName(fileName)
                ,fi.Length.ToString()
                ,watcher.ElapsedMilliseconds.ToString()
                );
        }
    }

    public enum BaseType
    {
        Binary = 2,
        Decimal = 10,
        Hexadecimal = 16
    }
}
