﻿using System;

namespace EmployeeService
{
    public class EntryService 
        : IEntryService
    {
        public Employee InsertEmployee(Employee newEmployee)
        {
            newEmployee.EmployeeId = 1903;
            return newEmployee;
        }
    }
}
