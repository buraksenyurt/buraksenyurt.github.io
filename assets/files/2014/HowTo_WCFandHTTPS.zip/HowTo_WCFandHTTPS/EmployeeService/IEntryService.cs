﻿using System.ServiceModel;

namespace EmployeeService
{
    [ServiceContract]
    public interface IEntryService
    {
        [OperationContract]
        Employee InsertEmployee(Employee newEmployee);
    }
}
