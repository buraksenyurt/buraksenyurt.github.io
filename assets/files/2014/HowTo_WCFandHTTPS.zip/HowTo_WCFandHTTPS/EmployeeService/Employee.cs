﻿namespace EmployeeService
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int Level { get; set; }
    }
}
