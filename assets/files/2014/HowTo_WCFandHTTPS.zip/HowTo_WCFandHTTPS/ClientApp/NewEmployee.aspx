﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="NewEmployee.aspx.cs" Inherits="ClientApp.NewEmployee" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <table>
        <tr>
            <td>
                Title : 
            </td>
            <td>
                <asp:TextBox ID="txtTitle" runat="server" />
            </td>
        </tr>
                <tr>
            <td>
                First Name : 
            </td>
            <td>
                <asp:TextBox ID="txtFirstName" runat="server" />
            </td>
        </tr>
                <tr>
            <td>
                Middle Name : 
            </td>
            <td>
                <asp:TextBox ID="txtMiddleName" runat="server" />
            </td>
        </tr>
                <tr>
            <td>
                Last Name : 
            </td>
            <td>
                <asp:TextBox ID="txtLastName" runat="server" />
            </td>
        </tr>
                <tr>
            <td>
                Level : 
            </td>
            <td>
                <asp:TextBox ID="txtLevel" runat="server" />
            </td>
        </tr>
                <tr>
            <td>
                
            </td>
            <td>
                <asp:Button ID="btnSend" runat="server" Text="Insert new Employee" OnClick="btnSend_Click" />
            </td>
        </tr>
                <tr>
            <td colspan="2">
                <asp:Label ID="lblResult" runat="server" />
            </td>
        </tr>
    </table>
    </div>
    </form>
</body>
</html>
