﻿using ClientApp.EmployeeRef;
using System;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace ClientApp
{
    public partial class NewEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            ServicePointManager.ServerCertificateValidationCallback =
                new RemoteCertificateValidationCallback(IgnoreCertificationError);

            EntryServiceClient proxy = new EntryServiceClient("WSHttpBinding_IEntryService");
            Employee newEmployee=proxy.InsertEmployee(new Employee 
            { 
                FirstName = txtFirstName.Text,
                MiddleName = txtMiddleName.Text,
                LastName = txtLastName.Text,
                Level = Convert.ToInt32(txtLevel.Text),
                Title = txtTitle.Text
            }
            );
            lblResult.Text = newEmployee.EmployeeId.ToString();
            proxy.Close();
        }

        public static bool IgnoreCertificationError(object sender,
      X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}