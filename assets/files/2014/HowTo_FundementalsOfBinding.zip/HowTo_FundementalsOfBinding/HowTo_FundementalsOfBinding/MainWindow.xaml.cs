﻿using System.Windows;

namespace HowTo_FundementalsOfBinding
{
    public partial class MainWindow 
        : Window
    {
        Product computer = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnChange_Click_1(object sender, RoutedEventArgs e)
        {
            // örnek olarak computer nesne örneğinin ListPrice özelliğinin değeri arttırılır
            computer.ListPrice += 10;
            // computer nesne örneğinin ListPrice özelliğinin yeni değeri, yapılan değişiklik üzerine ilgili kontrolün text özelliğine YENİDEN atanır
            //txtListPrice.Text = computer.ListPrice.ToString();
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            // computer isminde Product tipine ait nesne örneklenir
            computer = new Product 
            { 
                ProductId = 10934
                , Name = "HP Compaq 1024X"
                , ListPrice = 999 
            };

            // Tüm Window içeriğindeki XAML kontrollerini computer isimli Product nesne örneğine bağlamış oluyoruz.
            this.DataContext = computer; 

            // örneğe ait özelliklerin değerleri Window üzerindeki kontrollerin Text özelliklerine set edilir.
            //txtProductId.Text = computer.ProductId.ToString();
            //txtName.Text = computer.Name;
            //txtListPrice.Text = computer.ListPrice.ToString();
        }
    }
}
