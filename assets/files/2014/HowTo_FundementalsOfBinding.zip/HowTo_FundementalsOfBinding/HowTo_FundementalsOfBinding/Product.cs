﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;

namespace HowTo_FundementalsOfBinding
{
    public class Product
        : INotifyPropertyChanged
    {
        private int _productId;

        public int ProductId
        {
            get { return _productId; }
            set
            {
                if (_productId == value)
                    return;
                _productId = value;
                // Dış dünyayı ProductId özelliğinin değerinin değiştiğine dair bilgilendir
                OnPropertyChanged(()=>ProductId);
            }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name == value) 
                    return;
                _name = value;
                // Dış dünyayı Name özelliğinin değerinin değiştiğine dair bilgilendir
                OnPropertyChanged(()=>Name);
            }
        }

        private decimal _listPrice;
        public decimal ListPrice
        {
            get { return _listPrice; }
            set
            {
                if (_listPrice == value)
                    return;
                _listPrice = value;
                // Dış dünyayı ListPrice özelliğinin değerinin değiştiğine dair bilgilendir
                OnPropertyChanged(()=>ListPrice);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            // Özellik değiştiğine dair bir Event yüklendiyse bunu tetikle
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        protected virtual void OnPropertyChanged<T>(Expression<Func<T>> propertySelector)
        {
            var memberExpression = propertySelector.Body as MemberExpression;
            if (memberExpression != null)
            {
                OnPropertyChanged(memberExpression.Member.Name);
            }
        }
    }
}
