﻿using System.ServiceModel;

namespace Karma.Contract
{
    [ServiceContract]
    public interface IAlgebra
    {
        [OperationContract]
        double Sum(double x, double y);

        [OperationContract]
        double Multiply(double x, double y);

        [OperationContract]
        double Div(double x, double y);
    }
}
