﻿using Karma.Contract;

namespace Karma.Implementation
{
    public class Algebra
        :IAlgebra
    {
        public double Sum(double x, double y)
        {
            return x + y;
        }

        public double Multiply(double x,double y)
        {
            return x * y;
        }

        public double Div(double x,double y)
        {
            return x / y;
        }
    }
}
