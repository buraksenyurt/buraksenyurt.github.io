﻿using Karma.Contract;
using System;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnProcess_Click(object sender, EventArgs e)
    {
        using (AlgebraServiceClient<IAlgebra> dynamicProxy = 
            new AlgebraServiceClient<IAlgebra>("BasicHttpBinding_AlgebraService"))
        {
            double result=dynamicProxy.Proxy.Sum(3.2, 4.5);
            Response.Write(result.ToString());

            double result2 = dynamicProxy.Proxy.Multiply(1.5, -4.79);
            Response.Write(string.Format("<br/>{0}",result2.ToString()));

            double result3 = dynamicProxy.Proxy.Div(4.5, 2.5);
            Response.Write(string.Format("<br/>{0}", result3.ToString()));
        }
    }
}