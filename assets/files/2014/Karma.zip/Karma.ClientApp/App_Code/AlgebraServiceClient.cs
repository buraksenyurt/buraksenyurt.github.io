﻿using System.ServiceModel;

public class AlgebraServiceClient<T> 
    : ClientBase<T> 
    where T : class
{
    private bool _disposed = false;
    public AlgebraServiceClient()
        : base(typeof(T).FullName)
    {
    }
    public AlgebraServiceClient(string endpointConfigurationName)
        : base(endpointConfigurationName)
    {
    }
    public T Proxy
    {
        get { return this.Channel; }
    }
    protected virtual void Dispose(bool disposing)
    {
        if (!this._disposed)
        {
            if (disposing)
            {
                if (this.State == CommunicationState.Faulted)
                {
                    base.Abort();
                }
                else
                {
                    try
                    {
                        base.Close();
                    }
                    catch
                    {
                        base.Abort();
                    }
                }
                _disposed = true;
            }
        }
    }
}