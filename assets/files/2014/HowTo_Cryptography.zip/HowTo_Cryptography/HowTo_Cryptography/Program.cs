﻿using System;

namespace HowTo_Cryptography
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("***Test Case Start***");
                TestMethod();
                Console.WriteLine("***Test Case End***");
            }
        }

        private static void TestMethod()
        {
            string content = String.Empty;

            byte[] aesEncrypted = Utility.AES_Encrypt();
            content = Utility.AES_Decrypt(aesEncrypted);

            byte[] tdesEncrypted = Utility.TripleDES_Encrypt();
            content = Utility.TripleDES_Decrypt(tdesEncrypted);

            byte[] rijndaelEncrypted = Utility.Rijndael_Encrypt();
            content = Utility.Rijndael_Decrypt(rijndaelEncrypted);

            byte[] rc2Encrypted = Utility.RC2_Encrypt();
            content = Utility.RC2_Decrypt(rc2Encrypted);

            byte[] desEncrypted = Utility.DES_Encrypt();
            content = Utility.DES_Decrypt(desEncrypted);
        }
    }
}
