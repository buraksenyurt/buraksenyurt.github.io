﻿namespace UsingConverters
{
    public class Vehicle
    {
        public int VehicleId { get; set; }
        public string Name { get; set; }
        public int FuelLevel { get; set; }        
    }
}
