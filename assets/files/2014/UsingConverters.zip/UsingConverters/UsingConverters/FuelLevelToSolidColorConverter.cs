﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace UsingConverters
{
    public class FuelLevelToSolidColorConverter
        :IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int fuelLevel = (int)value;
            SolidColorBrush brush = null;

            if (fuelLevel <= 25)
                brush = new SolidColorBrush(Colors.Red);
            else if (fuelLevel > 25
                && fuelLevel <= 50)
                brush = new SolidColorBrush(Colors.Orange);
            else if (fuelLevel > 50
                && fuelLevel <= 75)
                brush = new SolidColorBrush(Colors.LightBlue);
            else if (fuelLevel > 75
                && fuelLevel <= 100)
                brush = new SolidColorBrush(Colors.DarkGreen);
            else
                brush = new SolidColorBrush(Colors.White);

            return brush;
        }
        
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value;
        }
    }
}
