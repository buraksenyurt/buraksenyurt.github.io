﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace UsingConverters
{
    public partial class MainWindow 
        : Window
    {
        List<Vehicle> vehicles = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            vehicles = new List<Vehicle>
            {
                new Vehicle{ VehicleId=1, Name="Su Todoroki", FuelLevel=75},
                new Vehicle{ VehicleId=2, Name="Migel Kamino", FuelLevel=50},
                new Vehicle{ VehicleId=3, Name="Francesco Bernulli", FuelLevel=45},
                new Vehicle{ VehicleId=4, Name="Meytır", FuelLevel=60},
                new Vehicle{ VehicleId=5, Name="Naycıl", FuelLevel=90},
                new Vehicle{ VehicleId=6, Name="Şimşek", FuelLevel=23},
                new Vehicle{ VehicleId=7, Name="Şolet", FuelLevel=85}
            };

            lstVehicles.DataContext = vehicles;
            Label lbl = new Label();
            lbl.Background = new SolidColorBrush(Colors.Red);
        }
    }
}
