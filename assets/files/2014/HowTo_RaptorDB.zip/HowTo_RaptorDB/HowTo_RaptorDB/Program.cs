﻿using RaptorDB;
using RaptorDB.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace HowTo_RaptorDB
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] categoryNames = {"Kitap","Bilgisayar","Elektronik","Çiçek","Oyuncak","Kırtasiye" };

            RaptorDB.RaptorDB db = RaptorDB.RaptorDB.Open("Data");
            
            if (db.RegisterView(new CategoryView()).OK == false)
            {
                Console.WriteLine("Registration işlemi sırasında bir hata oluştu. Programdan çıkılacak! Çık");
                return;
            }

            if (db.RegisterView(new CategoryWithProductsView()).OK == false)
            {
                Console.WriteLine("Registration işlemi sırasında bir hata oluştu. Programdan çıkılacak! Çık");
                return;
            }

            #region Veri Oluşturmak

            Stopwatch watcher = new Stopwatch();
            watcher.Start();

            foreach (string categoryName in categoryNames)
            {
                var newCategory = new Category
                           {
                               CategoryId = Guid.NewGuid(),
                               CategoryName = categoryName,
                               Description = categoryName + " için açıklama"
                           };
                newCategory.Products = new List<Product>();

                for (int j = 0; j < 100000; j++)
                {
                    newCategory.Products.Add(
                        new Product
                        {
                            ProductId = Guid.NewGuid(),
                            Title = "Product " + j.ToString(),
                            UnitPrice = 10.45M,
                            StockSize = 100
                        });
                }

                db.Save<Category>(newCategory.CategoryId, newCategory);
            }

            watcher.Stop();
            Console.WriteLine("Toplam kaydetme süresi {0}"
                , watcher.ElapsedMilliseconds.ToString()
                );
            Console.ReadLine();

            #endregion Veri Oluşturmak

            #region Veri Sorgulamak

            var result = db
                .Query(
                    typeof(Category)
                    , (Category c) => (c.CategoryName == "Kitap")
                    );

            Console.WriteLine(result.TotalCount);

            var result2 = db
                .Query("CategoryWithProductsView"
                , (Category c) => (c.CategoryName == "Kitap")
                );

            Console.WriteLine(result2.TotalCount);
                
            #endregion Veri Sorgulamak
        }
    }

    public class Category
    {
        public Guid CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public List<Product> Products { get; set; }
    }

    public class Product
    {
        public Guid ProductId { get; set; }
        public string Title { get; set; }
        public decimal UnitPrice { get; set; }
        public int StockSize { get; set; }
    }

    public class CategoryView
        : View<Category>
    {
        public class RowSchema
        {
            public string CategoryName { get; set; }
            public string Description { get; set; }
        }

        public CategoryView()
        {
            this.Name = "PrimaryCategoryView";
            this.Description = "Primary View of Category";
            this.isPrimaryList = true;
            this.isActive = true;
            this.BackgroundIndexing = true;

            this.Schema = typeof(CategoryView.RowSchema);

            this.AddFireOnTypes(typeof(Category));

            this.Mapper = (api, docId, doc) =>
            {
                    api.Emit(docId
                        , doc.CategoryName
                        , doc.Description
                        );                                
            };
        }
    }

    public class CategoryWithProductsView
    : View<Category>
    {
        public class RowSchemaV2
        {
            public NormalString ProductTitle { get; set; }
            public int ProductStockSize { get; set; }
            public string CategoryName { get; set; }
            public string Description { get; set; }
        }

        public CategoryWithProductsView()
        {
            this.Name = "CategoryWithProductsView";
            this.Description = "Category with Products View";
            this.isPrimaryList = false;
            this.isActive = true;
            this.BackgroundIndexing = true;

            this.Schema = typeof(CategoryWithProductsView.RowSchemaV2);

            this.AddFireOnTypes(typeof(Category));

            this.Mapper = (api, docId, doc) =>
            {
                foreach (var product in doc.Products)
                    api.Emit(docId
                        , product.Title
                        ,product.StockSize
                        , doc.CategoryName
                        , doc.Description
                        );
            };
        }
    }
}
