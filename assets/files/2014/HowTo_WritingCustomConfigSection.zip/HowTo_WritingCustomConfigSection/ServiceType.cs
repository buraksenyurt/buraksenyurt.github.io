﻿
namespace HowTo_WritingCustomConfigSection
{
    public enum ServiceType
    {
        WCF,
        XmlWebService,
        Remoting,
        COMPlus,
        Java,
        MSMQ
    }
}
