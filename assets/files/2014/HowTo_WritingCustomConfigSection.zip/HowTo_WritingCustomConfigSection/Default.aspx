﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="HowTo_WritingCustomConfigSection.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
        <table>
            <tr>
                <td><strong>Service Type</strong></td>
                <td>
                    <asp:DropDownList ID="ddlServiceType" runat="server">
                    </asp:DropDownList>
                </td>
            </tr>
            <tr>
                <td><strong>Definition</strong> <strong>Name</strong></td>
                <td>
                    <asp:TextBox ID="txtName" runat="server" Width="220px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td><strong>Definition WSDL</strong> <strong>Address</strong></td>
                <td>
                    <asp:TextBox ID="txtAddress" runat="server" Width="300px"></asp:TextBox>
&nbsp; </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <asp:Button ID="btnSave" runat="server" 
                        OnClick="btnSave_Click" Text="Save" Width="60px" />
                </td>
            </tr>
            </table>
    
    </div>
    </form>
</body>
</html>
