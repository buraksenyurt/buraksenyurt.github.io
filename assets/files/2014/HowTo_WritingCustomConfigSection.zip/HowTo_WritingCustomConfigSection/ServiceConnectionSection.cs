﻿using System;
using System.Configuration;

namespace HowTo_WritingCustomConfigSection
{
    public class ServiceConnectionSection
        :ConfigurationSection
    {
        // Save işlemine izin vermesi için false döndürecek şekilde ezdik
        public override bool IsReadOnly()
        {
            return false;
        }

        [ConfigurationProperty("type", DefaultValue = ServiceType.WCF, IsRequired = false)]
        public ServiceType Type
        {
            get
            {
                return (ServiceType)Enum.Parse(typeof(ServiceType), this["type"].ToString());
            }
            set
            {
                this["type"] = value.ToString();
            }
        }

        [ConfigurationProperty("definition",IsRequired=true)]
        public DefinitionSection Definition
        {
            get
            {
                return (DefinitionSection)this["definition"];
            }
            set
            {
                this["definition"]=value;
            }
        }
    }
}