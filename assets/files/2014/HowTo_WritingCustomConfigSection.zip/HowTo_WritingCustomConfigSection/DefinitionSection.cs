﻿using System.Configuration;

namespace HowTo_WritingCustomConfigSection
{
    public class DefinitionSection
        :ConfigurationElement
    {
        // Save işlemine izin vermesi için false döndürecek şekilde ezdik
        public override bool IsReadOnly()
        {
            return false;
        }

        [ConfigurationProperty("name", IsRequired = true)]
        [StringValidator(InvalidCharacters = "~!@#$%^&*()[]{}/;'\"|\\,çşöğüı")]
        public string Name
        {
            get
            {
                return this["name"].ToString();
            }
            set
            {
                this["name"] = value;
            }
        }

        [ConfigurationProperty("wsdlAddress", IsRequired = true)]
        public string WsdlAddress
        {
            get
            {
                return this["wsdlAddress"].ToString();
            }
            set
            {
                this["wsdlAddress"] = value;
            }
        }
    }
}