﻿using System;
using System.Configuration;
using System.Web.Configuration;
using System.Web.UI;

namespace HowTo_WritingCustomConfigSection
{
    public partial class Default 
        : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                ddlServiceType.DataSource = Enum.GetNames(typeof(ServiceType));
                ddlServiceType.DataBind();

                ServiceConnectionSection scs =
                    ConfigurationManager.GetSection("serviceConnectionGroup/serviceConnection")
                    as ServiceConnectionSection;

                if (scs != null)
                {
                    txtAddress.Text = scs.Definition.WsdlAddress;
                    txtName.Text = scs.Definition.Name;
                    ddlServiceType.SelectedValue = scs.Type.ToString();
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Configuration manager = WebConfigurationManager.OpenWebConfiguration("/");

            ServiceConnectionSection scs =
                manager.GetSection("serviceConnectionGroup/serviceConnection")
                as ServiceConnectionSection;
            if (scs != null)
            {
                scs.Type = (ServiceType)Enum.Parse(typeof(ServiceType), ddlServiceType.SelectedValue.ToString());
                scs.Definition.Name = txtName.Text;
                scs.Definition.WsdlAddress = txtAddress.Text;

                manager.Save();
            }
        }
    }
}