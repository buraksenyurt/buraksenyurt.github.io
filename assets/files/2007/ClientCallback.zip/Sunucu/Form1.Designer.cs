namespace Sunucu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnServisiAc = new System.Windows.Forms.Button();
            this.btnServisiKapat = new System.Windows.Forms.Button();
            this.lblServisDurumu = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnServisiAc
            // 
            this.btnServisiAc.Location = new System.Drawing.Point(12, 22);
            this.btnServisiAc.Name = "btnServisiAc";
            this.btnServisiAc.Size = new System.Drawing.Size(156, 39);
            this.btnServisiAc.TabIndex = 0;
            this.btnServisiAc.Text = "Servisi A�";
            this.btnServisiAc.UseVisualStyleBackColor = true;
            this.btnServisiAc.Click += new System.EventHandler(this.btnServisiAc_Click);
            // 
            // btnServisiKapat
            // 
            this.btnServisiKapat.Location = new System.Drawing.Point(214, 22);
            this.btnServisiKapat.Name = "btnServisiKapat";
            this.btnServisiKapat.Size = new System.Drawing.Size(156, 39);
            this.btnServisiKapat.TabIndex = 1;
            this.btnServisiKapat.Text = "Servisi Kapat";
            this.btnServisiKapat.UseVisualStyleBackColor = true;
            this.btnServisiKapat.Click += new System.EventHandler(this.btnServisiKapat_Click);
            // 
            // lblServisDurumu
            // 
            this.lblServisDurumu.AutoSize = true;
            this.lblServisDurumu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblServisDurumu.Location = new System.Drawing.Point(12, 78);
            this.lblServisDurumu.Name = "lblServisDurumu";
            this.lblServisDurumu.Size = new System.Drawing.Size(114, 17);
            this.lblServisDurumu.TabIndex = 2;
            this.lblServisDurumu.Text = "Servis Durumu";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 139);
            this.Controls.Add(this.lblServisDurumu);
            this.Controls.Add(this.btnServisiKapat);
            this.Controls.Add(this.btnServisiAc);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Sunucu Uygulama";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnServisiAc;
        private System.Windows.Forms.Button btnServisiKapat;
        private System.Windows.Forms.Label lblServisDurumu;
    }
}

