using System;
using System.ServiceModel;

namespace UrunYonetimKutuphanesi
{
    [ServiceContract(Name="UrunYonetimServisi",Namespace="http://www.bsenyurt.com/UrunYonetimServisi",SessionMode=SessionMode.Required)]
    public interface IUrunYonetici
    {
        [OperationContract(IsInitiating=true)]
        void SepeteUrunEkle(string urunId);
        [OperationContract(IsInitiating=false)]
        void SepettenUrunCikar(string urunId);
        [OperationContract(IsInitiating=false,IsTerminating=true)]
        void SiparisVer();
    }
}
