using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using UrunYonetimKutuphanesi;

namespace ServerApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ServiceHost host;

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnBaslat_Click(object sender, EventArgs e)
        {

            host = new ServiceHost(typeof(UrunYonetici));
            host.Open();
            lstDurum.Items.Add(DateTime.Now.ToLongTimeString() + host.State);           
        }

        private void btnBitir_Click(object sender, EventArgs e)
        {
            host.Close();
            lstDurum.Items.Add(DateTime.Now.ToLongTimeString() + host.State);
        }
    }
}