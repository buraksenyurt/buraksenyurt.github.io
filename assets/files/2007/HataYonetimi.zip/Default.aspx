﻿<%@ Page Language="C#" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void Page_Error(object sender, EventArgs e)
    {
        Exception olusanHata = Server.GetLastError();     
        throw olusanHata;
    }
       
    protected void Hesapla_Click(object sender, EventArgs e)
    {
        try
        {
            double deger1 = Convert.ToDouble(txtDeger1.Text);
            double deger2 = Convert.ToDouble(txtDeger2.Text);
            double sonuc = deger1 / deger2;
        }
        catch (Exception excp)
        {
            throw new Exception("Sayısal değer girişinde hata oluştu", excp);
        }
        
        //try
        //{
        //    double deger1 = Convert.ToDouble(txtDeger1.Text);
        //    double deger2 = Convert.ToDouble(txtDeger2.Text);
        //    double sonuc = deger1 / deger2;
        //}
        //catch (FormatException err)
        //{
        //    Response.Write("<b>Değerler sayısal olmalıdır. Lütfen girdiğiniz değerleri kontrol ediniz.</b><br/>Detaylı Mesaj : " + err.Message);
        //}
        //catch (Exception err)
        //{
        //    Response.Write("<b>Beklenmeyen bir hata oluştu.</b><br/>Detaylı Mesaj : " + err.Message);
        //} 
    }  

</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Hata Yonetimi (Metod Seviyesinde)</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    Birinci Değer : 
        <asp:TextBox ID="txtDeger1" runat="server"></asp:TextBox>  <br />
         İkinci Değer :       
        <asp:TextBox ID="txtDeger2" runat="server"></asp:TextBox>
        <br />
        <asp:Button ID="btnHesapla" runat="server" Text="Hesapla" OnClick="Hesapla_Click" />
    </div>
    </form>
</body>
</html>
