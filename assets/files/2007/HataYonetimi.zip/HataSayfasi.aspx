﻿<%@ Page Language="C#" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void Page_Load(object sender, EventArgs e)
    {
        string ekBilgi = Request.QueryString["EkBilgi"];
        string sayfa=Request.QueryString["Sayfa"];
        string hataMesaji = Request.QueryString["HataMesaji"];
        Response.Write("<b>Hata sayfası : </b>" + sayfa+"<br/>");
        Response.Write("<b>Ek bilgi : </b>" + ekBilgi + "<br/>");
        Response.Write("<b>Hata Mesajı : </b>" + hataMesaji);        
    }  

</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Hata Sayfası</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    
    </div>
    </form>
</body>
</html>
