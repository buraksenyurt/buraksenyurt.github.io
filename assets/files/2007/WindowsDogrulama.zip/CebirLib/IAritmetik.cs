using System;
using System.ServiceModel;

namespace CebirLib
{
    [ServiceContract(Name="AritmetikServisi",Namespace="http://www.bsenyurt.com/AritmetikServisi")]
    public interface IAritmetik
    {
        [OperationContract(Name="ToplamaOperasyonu")]
        int Topla(int x, int y);        
    }
}
