﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrafiklerleCalismak
{
    public partial class MerhabaFircalarKodIle : Window
    {
        private void SekilleriCiz()
        {
            Ellipse elips = new Ellipse();
            elips.Margin = new Thickness(78, 130, 54, 42);            
            SolidColorBrush firca = new SolidColorBrush(Colors.BlueViolet);
            firca.Opacity = 0.6;
            elips.Fill = firca;
            grdAlan.Children.Add(elips);
        }
        public MerhabaFircalarKodIle()
        {
            InitializeComponent();
            SekilleriCiz();
        }
    }
}
