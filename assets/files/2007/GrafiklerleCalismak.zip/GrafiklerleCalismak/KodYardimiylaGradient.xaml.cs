﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrafiklerleCalismak
{
    public partial class KodYardimiylaGradient : Window
    {
        private void LinearGradientDortgenCiz()
        {
            // LinearGradientBrush nesne örneği oluşturulur.
            LinearGradientBrush fircam = new LinearGradientBrush();

            // C# 3.0 ile gelen Object Initializers kullanılmıştır.
            GradientStopCollection noktalar = new GradientStopCollection() { new GradientStop(Colors.WhiteSmoke, 0), new GradientStop(Colors.RosyBrown, 0.25), new GradientStop(Colors.Salmon, 0.50), new GradientStop(Colors.Silver, 0.75), new GradientStop(Colors.Gold, 0.1) };
            // Gradient Stop noktaları set edilir
            fircam.GradientStops = noktalar;
            fircam.Opacity = 0.80; // Saydamlık değeri ayarlanır

            fircam.Freeze(); //Nesnenin değiştirilemeyeceğini belirtir. Bu metod çoğunlukla performans açısından kullanılır.
           
            // Dörtgen nesnesi örneklenir.
            Rectangle dortgen = new Rectangle();
            // Dörtgenin genişlik ve yükseklik değerleri belirlenir.
            dortgen.Width = 200;
            dortgen.Height = 50;
            
            dortgen.Margin = new Thickness(0, 0, 0, 0); // Sağ, sol kenar uzaklıkları belirlenir. Buna göre şekil formun tam ortasında olacaktır.
            dortgen.Fill = fircam; // Dortgenin içinin fircam isimli LinearGradientBrush sınıfının değerleri ile doldurulacağı belirlenir.
             
            grdAlan.Children.Add(dortgen); // Dortgen nesnesi Grid alanı içerisine eklenir.

            
            

        }
        public KodYardimiylaGradient()
        {
            InitializeComponent();
            LinearGradientDortgenCiz();
        }
    }
}
