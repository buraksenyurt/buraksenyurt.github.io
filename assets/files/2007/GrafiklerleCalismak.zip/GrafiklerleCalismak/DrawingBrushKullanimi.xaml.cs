﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace GrafiklerleCalismak
{
    public partial class DrawingBrushKullanimi : Window
    {
        private void VideoCiz()
        {            
            // Elips oluşturulur
            Ellipse elips = new Ellipse();
            // Yükseklik ve genişlik belirtilir.
            elips.Width = 250;
            elips.Height = 75;
            
            // Video dosyasını oynatacak bir MediaPlayer nesnesi örneklenir.
            MediaPlayer oynatici = new MediaPlayer();
            // intro.wmv dosyasının açılması sağlanır.
            oynatici.Open(new Uri("..\\..\\intro.wmv",UriKind.Relative));            
            
            // DrawingBrush' ın kullanacağı VideoDrawing nesnesi örneklenir.
            VideoDrawing vd=new VideoDrawing();
            // Oynatıcı set edilir.
            vd.Player=oynatici;
            // Videonun oynayacağı alan belirlenir. Örnekte bu alan elips' inki ile aynı tutulmuştur.
            vd.Rect = new Rect(0, 0, 250, 75);            

            // Fırça oluşturulur ve Drawing özelliğine VideoDrawing nesne örneği aktarılır
            DrawingBrush fircam = new DrawingBrush();
            fircam.Drawing = vd;

            // Elipsin için dolduracak nesne örneği belirlenir.
            elips.Fill = fircam;            

            // Elips Grid içerisine eklenir
            grdAlan.Children.Add(elips);

            // Video oynatılır.
            oynatici.Play();
        }

        public DrawingBrushKullanimi()
        {
            InitializeComponent();            
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                VideoCiz();
            }
            catch (Exception excp)
            {
                MessageBox.Show(excp.Message);
            }
        }
    }
}
