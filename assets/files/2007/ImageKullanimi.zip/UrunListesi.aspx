﻿<%@ Page Language="C#" AutoEventWireup="true" CodeFile="UrunListesi.aspx.cs" Inherits="UrunListesi" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Urun Listesi</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:DataList ID="DataList1" runat="server" DataSourceID="dsProducts" Width="600px" OnItemDataBound="DataList1_ItemDataBound">
            <ItemTemplate>
                <table>
                    <tr>
                        <td colspan="2">
                            <asp:Label ID="NameLabel" runat="server" Font-Italic="True" ForeColor="#000040" Text='<%# Eval("Name") %>'></asp:Label></td>
                        <td style="width: 100px; text-align: right">
                            <asp:Label ID="ProductIDLabel" runat="server" Font-Bold="True" ForeColor="#C00000"
                                Text='<%# Eval("ProductID") %>'></asp:Label></td>
                    </tr>
                    <tr>
                        <td rowspan="3" style="width: 100px">
                            <img runat="server" id="urunResmi" alt="Urun Resmi" src="" /></td>
                        <td style="width: 100px">
                            Standart Maliyet</td>
                        <td style="width: 100px">
                            <asp:Label ID="StandardCostLabel" runat="server" Text='<%# Eval("StandardCost", "{0:C}") %>'></asp:Label></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">
                            Liste Fiyatı</td>
                        <td style="width: 100px">
                            <asp:Label ID="ListPriceLabel" runat="server" Text='<%# Eval("ListPrice", "{0:C}") %>'></asp:Label></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">
                            Sınıf</td>
                        <td style="width: 100px">
                            <asp:Label ID="ClassLabel" runat="server" Text='<%# Eval("Class") %>'></asp:Label></td>
                    </tr>
                    <tr>
                        <td colspan="3">
                            <hr />
                        </td>
                    </tr>
                </table>
            </ItemTemplate>
        </asp:DataList><asp:SqlDataSource ID="dsProducts" runat="server" ConnectionString="<%$ ConnectionStrings:AdvConStr %>"
            SelectCommand="SELECT Top 20 P.ProductID, P.Name, P.StandardCost, P.ListPrice, PP.ProductPhotoID, P.Class FROM Production.Product P INNER JOIN Production.ProductProductPhoto PP ON P.ProductID = PP.ProductID WHERE P.ListPrice>1400">
        </asp:SqlDataSource>
    
    </div>
    </form>
</body>
</html>
