<%@ Page Language="C#" Trace="true" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void btnCek_Click(object sender, EventArgs e)
    {
        VeriBileseni veriBln = new VeriBileseni();
        Session.Add("TransactionIDler", veriBln.GetTransactionIdString()); 
    } 
     
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Button ID="btnCek" runat="server" Text="Veriyi �ek" OnClick="btnCek_Click" />
    </div>
    </form>
</body>
</html>
