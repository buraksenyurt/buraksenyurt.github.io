﻿<%@ Page Language="C#" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected bool TraceYazilsinmi()
    {
        string userHostAddress = Request.UserHostAddress;
        if (userHostAddress == "127.0.0.1")
            return true;
        else
        {
            string localAddress = Request.ServerVariables.GetValues("LOCAL_ADDR").ToString();
            if (localAddress == userHostAddress)
                return true;
            else
                return false;  
        }
    }
       
    protected void btnBaglantiAc_Click(object sender, EventArgs e)
    {
        SqlConnection conn = null; 
        try
        {
            conn = new SqlConnection("data source=.;database=" + txtVeritabani.Text + ";integrated security=SSPI");
            conn.Open();
            Response.Write("Bağlantı açıldı");
        }
        catch (Exception excp)
        {
            if (TraceYazilsinmi())
            {
                Trace.IsEnabled = true;
                Trace.Warn("Developer İçin Hata Bilgisi", "Bağlantı açılması sırasında hata oluştu", excp); 
            } 
        }
        finally
        {
            if (conn != null
                && conn.State == ConnectionState.Open)
                conn.Close(); 
        }
    }  
    
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        Veritabanı Adı : <asp:TextBox ID="txtVeritabani" runat="server" />
        <asp:Button ID="btnBaglantiAc" runat="server" Text="Bağlantı Aç" OnClick="btnBaglantiAc_Click" />
    </div>
    </form>
</body>
</html>
