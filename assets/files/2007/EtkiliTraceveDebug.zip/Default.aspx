﻿<%@ Page Language="C#"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">
    
    protected void Page_Load(object sender, EventArgs ea)
    {
        //Page.Trace.IsEnabled = true;
        //Page.Trace.TraceFinished += new TraceContextEventHandler(Trace_TraceFinished);
        //Response.Write("User Host Address : "+Request.UserHostAddress.ToString()+"<br/>");
        //Response.Write("Local Address : " + Request.ServerVariables.Get("LOCAL_ADDR").ToString());
    }

    void Trace_TraceFinished(object sender, TraceContextEventArgs e)
    {
        IEnumerator numarator=e.TraceRecords.GetEnumerator();
        while (numarator.MoveNext())
        {                        
            TraceContextRecord record = (TraceContextRecord)numarator.Current;
            Response.Write(record.Category + " : " + record.Message + "<br/>");
        }        
    }  
      
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Button ID="btnPost" Text="Post" runat="server" />
    </div>
    </form>
</body>
</html>
