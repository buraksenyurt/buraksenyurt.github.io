﻿<%@ Page Language="C#"%>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void btnCek_Click(object sender, EventArgs e)
    {
        StringBuilder builder = new StringBuilder();
        using (SqlConnection conn = new SqlConnection("data source=.;database=AdventureWorks;integrated security=SSPI"))
        {
            SqlCommand cmd = new SqlCommand("Select Top 10000 TransactionId From Production.TransactionHistory", conn);
            conn.Open();
            Trace.Warn("TransactionId Cekme", "TransactionId değerleri çekilmeye başlanacak");
            SqlDataReader reader = cmd.ExecuteReader();            
            while (reader.Read())
            {
                builder.Append(reader["TransactionId"].ToString());
                builder.Append("|");
                //urunAdlari += reader["TransactionId"].ToString()+"|";
            }
            Trace.Warn("TransactionId Cekme", "TransactionId değerleri çekildi...");
            reader.Close();
        }
        Session.Add("TumKategoriler", builder.ToString());        
    }  
     
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Button ID="btnCek" runat="server" Text="Veriyi Çek" OnClick="btnCek_Click" />
    </div>
    </form>
</body>
</html>
