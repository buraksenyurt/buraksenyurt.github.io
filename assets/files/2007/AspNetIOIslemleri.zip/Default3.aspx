﻿<%@ Page Language="C#" %>
<%@ Import Namespace="System.Xml" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void btnGonder_Click(object sender, EventArgs e)
    {
        if (uplKontroller.HasFile)
        {
            HttpPostedFile dosya = uplKontroller.PostedFile;
            if (dosya.ContentType == "text/xml")
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(dosya.InputStream);
                XmlNodeList  kontroller=doc.GetElementsByTagName("Kontrol");
                foreach (XmlNode kontrol in kontroller)
                {                    
                    switch (kontrol.Attributes["tip"].Value)
                    {                           
                        case "Dugme":
                            Button btn = new Button();
                            btn.ID = kontrol.Attributes["id"].Value;
                            btn.Text = kontrol.Attributes["metin"].Value;
                            phlKontroller.Controls.Add(btn);   
                            break;
                        case "MetinKutusu":
                            TextBox txt = new TextBox();
                            txt.ID = kontrol.Attributes["id"].Value;
                            phlKontroller.Controls.Add(txt); 
                            break;
                        case "Label":
                            Label lbl = new Label();
                            lbl.ID = kontrol.Attributes["id"].Value;
                            lbl.Text = kontrol.Attributes["metin"].Value;
                            phlKontroller.Controls.Add(lbl); 
                            break;  
                    }
                }  
            }
            else
                Response.Write("Dosya içeriği XML olmalıdır");
        }
        else
            Response.Write("Dosya bulunamadı");
    }  
     
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Upload Edilen Dosyayi O Anda Islemek</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        Xml Dosayasını Seçin : <asp:FileUpload ID="uplKontroller" runat="server" />
        <br />
        <asp:Button ID="btnGonder" Text="Gönder" runat="server" OnClick="btnGonder_Click" />
        <br />
        Yüklenen Kontroller:
        <asp:PlaceHolder ID="phlKontroller" runat="server" />
    </div>
    </form>
</body>
</html>
