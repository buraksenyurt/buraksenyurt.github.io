﻿<%@ Page Language="C#" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%@ Import Namespace="System.IO" %>
<%@ Import Namespace="System.Diagnostics" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void Page_PreInit(object sender, EventArgs e)
    {
        Debug.WriteLine("Page_PreInit metodu");        
    }
    protected void Page_Init(object sender, EventArgs e)
    {
        Debug.WriteLine("Page_Init metodu"); 
    }   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string[] dosyalar = Directory.GetFiles(Server.MapPath("Dokumanlar"));
            List<FileInfo> dosyaBilgileri = new List<FileInfo>();

            foreach (string dosya in dosyalar)
            {
                dosyaBilgileri.Add(new FileInfo(dosya));
                //FileInfo dosyaBilgisi=new FileInfo(dosya);            
            }
            grdDosyalar.DataSource = dosyaBilgileri;
            grdDosyalar.DataBind();
        }
        Debug.WriteLine("Page_Load metodu");
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        Debug.WriteLine("Page PreRender Metodu");
    }
    protected void Page_Unload(object sender, EventArgs e)
    {
        Debug.WriteLine("Page Unload Metodu"); 
    }   

    protected void grdDosyalar_SelectedIndexChanged(object sender, EventArgs e)
    {
        Debug.WriteLine("Dosya indirme işlemi başlıyor");
        string dosyaAdi = Server.MapPath("dokumanlar") + "\\" + grdDosyalar.SelectedRow.Cells[0].Text;

        FileInfo dosya = new FileInfo(dosyaAdi);
        
        Response.Clear(); // Her ihtimale karşı Buffer' da kalmış herhangibir veri var ise bunu silmek için yapıyoruz.
        Response.AddHeader("Content-Disposition","attachment; filename=" + dosyaAdi); // Bu şekilde tarayıcı penceresinden hangi dosyanın indirileceği belirtilir. Eğer belirtilmesse bulunulan sayfanın kendisi indirilir. Okunaklı bir formattada olmaz.
        Response.AddHeader("Content-Length",dosya.Length.ToString()); // İndirilecek dosyanın uzunluğu bildirilir.
        Response.ContentType = "application/octet-stream"; // İçerik tipi belirtilir. Buna göre dosyalar binary formatta indirilirler.
        Response.WriteFile(dosyaAdi); // Dosya indirme işlemi başlar.
        Response.End(); // Süreç bu noktada sonlandırılır. Bir başka deyişle bu satırdan sonraki satırlar işletilmez hatta global.asax dosyasında eğer yazılmışsa Application_EndRequest metodu çağırılır.
        Debug.WriteLine("Response.End metodu çağırıldı");
        Response.Write("Dosya indirildi");
    }
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Dosya Indirme Islemleri</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
    <h2>Dosyalar</h2>
   <asp:GridView ID="grdDosyalar" runat="server" AutoGenerateColumns="False" SelectedRowStyle-BackColor="Gold" OnSelectedIndexChanged="grdDosyalar_SelectedIndexChanged" Font-Size="Smaller">
        <Columns>
            <asp:BoundField DataField="Name" HeaderText="Dosya Adı" />
            <asp:BoundField DataField="Length" HeaderText="Dosya Uzunluğu" />
            <asp:BoundField DataField="Extension" HeaderText="Uzantısı" />
            <asp:BoundField DataField="CreationTime" HeaderText="Oluşturulma Zamanı" DataFormatString="{0:dd.MMMM.yy}" HtmlEncode="False" />
            <asp:BoundField DataField="LastWriteTime" HeaderText="Son Yazılma Zamanı" DataFormatString="{0:dd.MMMM.yy}" HtmlEncode="False" />
            <asp:CommandField ButtonType="Button" SelectText="indir" ShowSelectButton="True" />            
        </Columns>
   </asp:GridView>
    </div>
    </form>
</body>
</html>
