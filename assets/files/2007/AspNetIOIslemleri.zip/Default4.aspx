﻿<%@ Page Language="C#" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Configuration" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    protected void btnGonder_Click(object sender, EventArgs e)
    {
        if (uplDosya.HasFile)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(conStr))
            {
                SqlCommand cmd = new SqlCommand("Insert into Dosyalar (EkleNmeTarihi,DosyaIcerigi,DosyaAdi,IcerikTipi) Values (@EklenmeTarihi,@DosyaIcerigi,@DosyaAdi,@IcerikTipi)", conn);
                cmd.Parameters.AddWithValue("@EklenmeTarihi", DateTime.Now);
                cmd.Parameters.AddWithValue("@DosyaIcerigi", uplDosya.FileBytes);
                cmd.Parameters.AddWithValue("@DosyaAdi", uplDosya.FileName);
                cmd.Parameters.AddWithValue("@IcerikTipi", uplDosya.PostedFile.ContentType);
                conn.Open();
                int sonuc=cmd.ExecuteNonQuery();
                Response.Write(sonuc + " dosya aktarıldı"); 
            } 
        }
        else
            Response.Write("Dosya seçmelisiniz");
    }  
     
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Upload Edilen Dosyayı Veritabanına Yazma</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        Dosyayı Seçin : <asp:FileUpload ID="uplDosya" runat="server" />
        <br />
        <asp:Button ID="btnGonder" Text="Gönder" runat="server" OnClick="btnGonder_Click" /></div>
    </form>
</body>
</html>
