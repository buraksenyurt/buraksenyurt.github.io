using System;
using System.ServiceModel;

namespace RaporlamaServisi
{
    [ServiceContract(Name = "RaporlamaServisi", Namespace = "http://www.bsenyurt.com/RaporlamaServisi/2007/30/05")]
    public interface IRaporUretici
    {
        [OperationContract(IsOneWay = true)]
        void RaporUret(string kullaniciAdi);
        [OperationContract(IsOneWay = true)]
        void SatisYapildi(int productId);
    }
}
