using System;
using System.Collections.Generic;
using System.Text;

namespace Olaylar
{
    enum Marka
    {
        Fiat
        ,
        Peugeout
       , Ferrari
    }
    public delegate void HizHandler(object sender, HizArgs arg);

    public class HizArgs
    {
        private short guncelHiz;

        public DateTime Zaman
        {
            get { return DateTime.Now; }
        }
        public short GuncelHiz
        {
            get { return guncelHiz; }
        }
        public HizArgs(short guncelHizi)
        {
            guncelHiz = guncelHizi;
        }
    }

    class Otomobil
    {
        private byte hiz;
        private Marka markasi;
        public event HizHandler HizAsildi;

        internal Marka Markasi
        {
            get { return markasi; }
            set { markasi = value; }
        }
        public static int HizLimiti = 120;

        public byte Hiz
        {
            get { return hiz; }
            set
            {
                if (hiz >= 120
                    && HizAsildi != null)
                    HizAsildi(this, new HizArgs(value));
                hiz = value;
            }
        }
    }
}
