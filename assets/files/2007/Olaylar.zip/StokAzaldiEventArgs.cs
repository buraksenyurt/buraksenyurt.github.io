using System;
using System.Collections.Generic;
using System.Text;

namespace Olaylar
{
    class StokAzaldiEventArgs:EventArgs
    {
        private int guncelStokMiktari;

        public int GuncelStokMiktari
        {
            get { return guncelStokMiktari; }
            set { guncelStokMiktari = value; }
        }
        public StokAzaldiEventArgs(int gStk)
        {
            GuncelStokMiktari = gStk;
        }
    }
}
