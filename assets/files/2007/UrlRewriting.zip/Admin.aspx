﻿<%@ Page Language="C#" %>
<%@ Import Namespace="System.Data" %>
<%@ Import Namespace="System.Data.SqlClient" %>
<%@ Import Namespace="System.Web.Configuration" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<script runat="server">

    private static void AddMappings()
    {
        Configuration cfg = ConfigurationManager.OpenExeConfiguration("");
        UrlMappingsSection urlMapSct = (UrlMappingsSection)cfg.GetSection("system.web/urlMappings");
        urlMapSct.UrlMappings.Clear();

        string query = "SELECT DISTINCT PSC.ProductSubcategoryID, PSC.Name,PRD.Class FROM Production.ProductSubcategory AS PSC INNER JOIN Production.Product AS PRD ON PSC.ProductSubcategoryID = PRD.ProductSubcategoryID WHERE (PRD.Class IS NOT NULL)";
               
        using (SqlConnection conn = new SqlConnection(cfg.ConnectionStrings.ConnectionStrings["AdvConStr"].ConnectionString))
        {
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            string url = "", mappedUrl = "";

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                url = "~/Urunler/" + reader.GetString(1).Replace(" ","")+ "/" + reader.GetString(2).Replace(" ","") + "/Goster.aspx";
                mappedUrl = "~/Urunler.aspx?AltKategoriId=" + reader["ProductSubCategoryID"].ToString() + "&AltKategoriAdi=" + reader["Name"].ToString() + "&Sinifi=" + reader["Class"].ToString();
                UrlMapping map = new UrlMapping(url, mappedUrl);
                urlMapSct.UrlMappings.Add(map);
            }
            reader.Close();
        }
        cfg.Save();
    }
     
    protected void btnMappEkle_Click(object sender, EventArgs e)
    {
        AddMappings();
    }  
     
</script>

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Yonetici Sayfasi</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:Button ID="btnMappEkle" runat="server" Text="Güncel URL Eşleştirmelerini Ekle" OnClick="btnMappEkle_Click" />
    </div>
    </form>
</body>
</html>
