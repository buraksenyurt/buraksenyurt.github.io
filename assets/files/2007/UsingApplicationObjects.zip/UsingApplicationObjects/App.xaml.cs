﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Diagnostics;
using System.IO.IsolatedStorage;
using System.IO;
using System.Collections;
using System.Windows.Threading;

namespace UsingApplicationObjects
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public void Validasyon()
        {
        }
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            if (e.Args.Length == 4)
            {
                if (e.Args[0][0] == 's')
                    Application.Current.Properties["Sunucu"] = e.Args[0].Substring(2, e.Args[0].Length-2);
                if (e.Args[1][0] == 'd')
                    Application.Current.Properties["Veritabani"] = e.Args[1].Substring(2, e.Args[1].Length-2);
                if (e.Args[2][0] == 'u')
                    Application.Current.Properties["Kullanici"] = e.Args[2].Substring(2, e.Args[2].Length-2);
                if (e.Args[3][0] == 'p')
                    Application.Current.Properties["Sifre"] = e.Args[3].Substring(2, e.Args[3].Length-2);
            }

            try
            {
                IsolatedStorageFile storage = IsolatedStorageFile.GetUserStoreForDomain();
                IsolatedStorageFileStream stream = new IsolatedStorageFileStream("GlobalAppProperties.txt", FileMode.Open, storage);
                StreamReader reader = new StreamReader(stream);
                while (!reader.EndOfStream)
                {
                    string[] keyValue = reader.ReadLine().Split(new char[] { '|' });
                    Urun urn = new Urun() { Id = Convert.ToInt32(keyValue[0]), Ad = keyValue[1].ToString(), BirimFiyat = Convert.ToDouble(keyValue[2].ToString()) };
                    Application.Current.Properties["SonBakilanUrun"] = urn;
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void Application_Activated(object sender, EventArgs e)
        {
            Debug.WriteLine("Activated");
        }

        private void Application_Deactivated(object sender, EventArgs e)
        {
            Debug.WriteLine("DeActivated");
        }

        private void Application_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            // Burada EventLog dışından bir dosyaya yazdırma işlemleride gerçekleştirilebilir.
            EventLog.WriteEntry("Application", "X Uygulamasında "+DateTime.Now.ToString()+" zamanında "+e.Exception.Message+" hatası alınmıştır.", EventLogEntryType.Error); // e parametresi üzerinden oluşan istisna referansı Exception özelliği ile yakalanabilir.
            
            e.Handled = true; // Eğer oluşan istisna kurtarılabilecek cinstense, standart hata mesajı kutusunun çıkartılmaması ve uygulamanın çalışmaya devam etmesi sağlanmış olur. Bu özelliğin varsayılan değeri false dur.
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {           
            try
            {
                Urun sonUrun = (Urun)Application.Current.Properties["SonBakilanUrun"]; // Properties koleksiyonuna eklenmiş SonBakilanUrun isimli bir anahtar var ise bunun değeri Urun tipinden elde edilir.
                if (sonUrun != null) // Eğer sonUrun nesne örneği null değilse...
                {
                    IsolatedStorageFile storageFile = IsolatedStorageFile.GetUserStoreForDomain(); // Bu uygulamanın ve assembly' ın kimlik (Identity) bilgisine göre izole edilmiş kullanıcı odaklı depolama alanının elde edilmesini sağlar.
                    IsolatedStorageFileStream stream = new IsolatedStorageFileStream("GlobalAppProperties.txt", FileMode.Create, storageFile); // Bu uygulama için diğerlerinden ayrılmış olan bir alana path' ten bağımsız olacak şekilde GlobalAppProperties.txt dosyasının açılmasını sağlar.
                    StreamWriter writer = new StreamWriter(stream); // izole edilmiş alandaki dosya üzerine yazmak için bir StreamWriter kullanılabilir.
                    writer.WriteLine(sonUrun.Id.ToString() + "|" + sonUrun.Ad + "|" + sonUrun.BirimFiyat.ToString()); // Bilgiler text dosyasına yazdırılır.
                    writer.Close();
                    stream.Close();
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void Application_SessionEnding(object sender, SessionEndingCancelEventArgs e)
        {
            MessageBoxResult cevap=MessageBox.Show("Bilgisayar " + e.ReasonSessionEnding.ToString() + " nedeniyle kapatılıyor. İptal etmek ister misiniz?", "Kapatma Sorusu", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (cevap == MessageBoxResult.No)
                e.Cancel = true;
        }
    }
}
