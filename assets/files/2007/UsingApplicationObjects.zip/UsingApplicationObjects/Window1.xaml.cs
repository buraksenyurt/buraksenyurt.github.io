﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;
using System.Windows.Controls.Primitives;

namespace UsingApplicationObjects
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Urun bilgisayar = new Urun() { Id = 1000, Ad = "Bilgisayar", BirimFiyat = 1000 };
            Application.Current.Properties["SonBakilanUrun"] = bilgisayar;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Urun urn = (Urun)Application.Current.Properties["SonBakilanUrun"];
            if (urn != null)
                Title = urn.Ad.ToString();

            txtSunucu.Text += Application.Current.Properties["Sunucu"]!=null? Application.Current.Properties["Sunucu"].ToString():"Tanımlı Değil";
            txtVeritabani.Text += Application.Current.Properties["Veritabani"] != null ? Application.Current.Properties["Veritabani"].ToString() : "Tanımlı Değil";
            txtKullanici.Text += Application.Current.Properties["Kullanici"] != null ? Application.Current.Properties["Kullanici"].ToString() : "Tanımlı Değil";
        }

        private void btnDigerForm_Click(object sender, RoutedEventArgs e)
        {
            Window2 wnd2 = new Window2();
            wnd2.Show();
        }

        private void btnKapat_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnArgumentException_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                throw new ArgumentException();
            }
            catch (Exception excp)
            {
                MessageBox.Show("Bir istisna oluştu");
            }
        }

        private void btnStackOverFlow_Click(object sender, RoutedEventArgs e)
        {
            throw new StackOverflowException();
        }
    }
}
