﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UsingApplicationObjects
{
    class Urun
    {
        public int Id;
        public string Ad;
        public double BirimFiyat;
    }
}
