using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using AdventureLib;

namespace ServerApp
{
    public partial class Form1 : Form
    {
        ServiceHost host;
        
        public Form1()
        {
            InitializeComponent();                   
        }

        private void btnStartService_Click(object sender, EventArgs e)
        {
            host = new ServiceHost(typeof(AdventureManager));    
            host.Open();
            lblStatus.Text = host.State.ToString();
        }

        private void btnStopService_Click(object sender, EventArgs e)
        {
            host.Close();
            lblStatus.Text = host.State.ToString();
        }
    }
}