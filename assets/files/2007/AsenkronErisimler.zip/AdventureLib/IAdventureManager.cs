using System;
using System.ServiceModel;

namespace AdventureLib
{
    [ServiceContract(Name="AdventureContract",Namespace="http://www.bsenyurt.com/2007/6/6/AdventureService")]
    public interface IAdventureManager
    {
        [OperationContract(Name="AverageListPriceByCategory")]
        double AverageListPrice(int subCatId);

        [OperationContract(Name="TotalListPriceByCategory")]
        double TotalListPrice(int subCatId);

        [OperationContract(Name = "GetProductsCountByCategory")]
        int ProductCount(int subCatId);
        
    }
}
