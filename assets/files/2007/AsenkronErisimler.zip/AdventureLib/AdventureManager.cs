using System;
using System.Threading;

namespace AdventureLib
{
    public class AdventureManager:IAdventureManager
    {
        #region IAdventureManager Members

        public double AverageListPrice(int subCatId)
        {
            Thread.Sleep(5000);
            return 1000;
        }
        public double TotalListPrice(int subCatId)
        {
            Thread.Sleep(3000);
            return 4500;
        }
        public int ProductCount(int subCatId)
        {
            Thread.Sleep(7000);
            return 504;
        }

        #endregion
    }
}
