﻿
namespace WorldBankLib
{
    /// <summary>
    /// Gelir düzeyi bilgilerini içerir
    /// </summary>
    public class CountryIncome
    {
        /// <summary>
        /// Ülkenin adı
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Gelir düzeyi seviyesi
        /// </summary>
        public string IncomeLevel { get; set; }
        /// <summary>
        /// Bağlı bulunulan bölge
        /// </summary>
        public string Region { get; set; }
    }
}
