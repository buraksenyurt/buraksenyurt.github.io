﻿
namespace WorldBankLib
{
    /// <summary>
    /// Topic bilgilerini verir
    /// </summary>
    public class Topic
    {
        /// <summary>
        /// Topiğin adı
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Kaynak bilgisi(Education gibi)
        /// </summary>
        public string Source { get; set; }
        /// <summary>
        /// Kaynağa ait bir açıklama bilgisi
        /// </summary>
        public string SourceNote { get; set; }
    }
}
