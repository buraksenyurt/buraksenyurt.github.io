﻿using System.Collections.Generic;
using System.Json;
using System.Net.Http;

namespace WorldBankLib
{
    /// <summary>
    /// Worldbank OData servisi için genel sorguları içerir
    /// </summary>
    public static class CommonQueries
    {
        #region Temel sorgularımız

        // İlk 50 ülkenin bilgilerini JSON formatında verir
        private static string _first50Countries = "http://api.worldbank.org/countries?format=json";
        //{0} yerine gelen ülkenin bilgisini JSON formatında verir. Bu bilgi BR gibi ülke kodu şeklindedir
        private static string _specificCountry = "http://api.worldbank.org/countries/{0}?format=json";
        //ilk 50 ülkenin gelir düzeyi durumları JSON formatında verilir
        private static string _incomeLevels = "http://api.worldbank.org/countries?incomeLevels&format=json";
        // {0} yerine(Örneğin Education için 4) gelen konuya ait olacak şekilde bazı topic bilgileri json formatında çekilir. 
        private static string _Topic = "http://api.worldbank.org/topics/{0}/indicators?format=json";

        #endregion

        /// <summary>
        /// Http Get taleplerini göndermemizde devreye giren yardımcı tipimiz
        /// </summary>
        private static HttpClient _client = new HttpClient();

        /// <summary>
        /// İlk 50 ülkenin ad, başkent, enlem ve boylam bilgilerini bulur
        /// </summary>
        /// <returns>ülke listesi döner</returns>
        public static List<Country> GetFirst50Countries()
        {
            List<Country> countries = new List<Country>();

            _client.GetAsync(_first50Countries)
                .ContinueWith((r) =>
                {
                    HttpResponseMessage responseMessage = r.Result;
                    responseMessage.EnsureSuccessStatusCode();

                    responseMessage.Content.ReadAsAsync<JsonArray>().
                        ContinueWith((rt) =>
                                        {
                                            foreach (var country in rt.Result[1])
                                            {
                                                countries.Add(
                                                    new Country()
                                                        {
                                                            Name = country.Value["name"].ToString(),
                                                            CapitalCity =country.Value["capitalCity"].ToString(),
                                                            Latitude =country.Value["latitude"].ToString(),
                                                            Longtitude =country.Value["longitude"].ToString()
                                                        }
                                                    );
                                            }
                                        });
                }).Wait();
            return countries;
        }

        /// <summary>
        /// Belirli bir ülkeye ait isim, başkent, enlem ve boylam bilgilerini verir
        /// </summary>
        /// <param name="countryCode">Ülke kodu(brazilya için BR gibi)</param>
        /// <returns>ülke bilgisi</returns>
        public static Country GetCountry(string countryCode)
        {
            Country resultCountry=null;

            _client.GetAsync(string.Format(_specificCountry,countryCode))
                .ContinueWith((r) =>
                {
                    HttpResponseMessage responseMessage = r.Result;
                    responseMessage.EnsureSuccessStatusCode();

                    responseMessage.Content.ReadAsAsync<JsonArray>().
                        ContinueWith((rt) =>
                                         {
                                             var cntry = rt.Result[1];
                                             resultCountry = new Country()
                                                           {
                                                               
                                                               Name = cntry[0]["name"].ToString(),
                                                               CapitalCity = cntry[0]["capitalCity"].ToString(),
                                                               Latitude = cntry[0]["latitude"].ToString(),
                                                               Longtitude = cntry[0]["longitude"].ToString()
                                                           };
                                         });
                }).Wait();
            return resultCountry;
        }

        /// <summary>
        /// İlk 50 ülkenin Gelir düzeyi bilgilerini döndürür
        /// </summary>
        /// <returns>Gelir düzeyi bilgileri</returns>
        public static List<CountryIncome> GetCountryIncomeLevels()
        {
            List<CountryIncome> countries = new List<CountryIncome>();

            _client.GetAsync(_incomeLevels)
                .ContinueWith((r) =>
                {
                    HttpResponseMessage responseMessage = r.Result;
                    responseMessage.EnsureSuccessStatusCode();

                    responseMessage.Content.ReadAsAsync<JsonArray>().
                        ContinueWith((rt) =>
                        {
                            foreach (var country in rt.Result[1])
                            {
                                
                                countries.Add(
                                    new CountryIncome()
                                    {
                                        Name = country.Value["name"].ToString(),
                                        IncomeLevel = country.Value["incomeLevel"]["value"].ToString(),
                                        Region = country.Value["region"]["value"].ToString()
                                    }
                                    );
                            }
                        });
                }).Wait();
            return countries;
        }

        /// <summary>
        /// Topic(Education) bazlı rapor bilgilerini döndürür
        /// </summary>
        /// <param name="topicCode">Topic kodu(Education=4 gibi)</param>
        /// <returns>Topic içeriği</returns>
        public static List<Topic> GetTopics(string topicCode)
        {
            List<Topic> topics = new List<Topic>();

            _client.GetAsync(string.Format(_Topic,topicCode))
                .ContinueWith((r) =>
                {
                    HttpResponseMessage responseMessage = r.Result;
                    responseMessage.EnsureSuccessStatusCode();

                    responseMessage.Content.ReadAsAsync<JsonArray>().
                        ContinueWith((rt) =>
                        {
                            foreach (var topic in rt.Result[1])
                            {

                                topics.Add(
                                    new Topic()
                                    {
                                        Name = topic.Value["name"].ToString(),
                                        Source = topic.Value["source"]["value"].ToString(),
                                        SourceNote = topic.Value["sourceNote"].ToString()
                                    }
                                    );
                            }
                        });
                }).Wait();
            return topics;
        }
    }
}
