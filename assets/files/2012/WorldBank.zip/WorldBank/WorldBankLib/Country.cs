﻿
namespace WorldBankLib
{
    /// <summary>
    /// Ülke bilgilerini taşır
    /// </summary>
    public class Country
    {
        /// <summary>
        /// ülkenin adı
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// ülkenin başkenti
        /// </summary>
        public string CapitalCity { get; set; }
        /// <summary>
        /// Enlem
        /// </summary>
        public string Latitude { get; set; }
        /// <summary>
        /// Boylam
        /// </summary>
        public string Longtitude { get; set; }

        public override string ToString()
        {
            return string.Format("{0}\t\t{1}\t\t({2};{3})"
                , Name
                , CapitalCity
                , Latitude
                , Longtitude
                );
        }
    }
}
