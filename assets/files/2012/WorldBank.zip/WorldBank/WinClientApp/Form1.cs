﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using WorldBankLib;

namespace WinClientApp
{
    public partial class Form1 : Form
    {
        private List<Country> countries = null;
        private Country brazil = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnGetFirst50Countries_Click(object sender, EventArgs e)
        {
            bgwGetFirst50Countries.RunWorkerAsync();
        }

        private void bgwGetFirst50Countries_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = CommonQueries.GetFirst50Countries();
        }

        private void bgwGetFirst50Countries_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if(!e.Cancelled || e.Error==null)
                dgvResult.DataSource = (List<Country>)e.Result;
        }

        private void bgwGetBrazil_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = CommonQueries.GetCountry("br");
        }

        private void bgwGetBrazil_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!e.Cancelled || e.Error == null)
            {
                var country=e.Result as Country;
                if(country!=null)
                    MessageBox.Show(country.ToString());
            }
        }

        private void btnGetBrazil_Click(object sender, EventArgs e)
        {
            bgwGetBrazil.RunWorkerAsync();
        }

        private void btnGetIncomeLevels_Click(object sender, EventArgs e)
        {
            bgwGetIncomeLevels.RunWorkerAsync();
        }

        private void bgwGetIncomeLevels_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = CommonQueries.GetCountryIncomeLevels();
        }

        private void bgwGetIncomeLevels_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!e.Cancelled || e.Error == null)
            {
                dgvResult.DataSource=(List<CountryIncome>)e.Result;
            }
        }

        private void btnGetEducationTopics_Click(object sender, EventArgs e)
        {
            bgwGetEducationTopics.RunWorkerAsync();
        }

        private void bgwGetEducationTopics_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = CommonQueries.GetTopics("4");
        }

        private void bgwGetEducationTopics_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (!e.Cancelled || e.Error == null)
            {
                dgvResult.DataSource = (List<Topic>)e.Result;
            }
        }
    }
}
