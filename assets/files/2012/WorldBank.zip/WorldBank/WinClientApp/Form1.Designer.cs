﻿namespace WinClientApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnGetBrazil = new System.Windows.Forms.Button();
            this.btnGetFirst50Countries = new System.Windows.Forms.Button();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.bgwGetFirst50Countries = new System.ComponentModel.BackgroundWorker();
            this.bgwGetBrazil = new System.ComponentModel.BackgroundWorker();
            this.btnGetIncomeLevels = new System.Windows.Forms.Button();
            this.bgwGetIncomeLevels = new System.ComponentModel.BackgroundWorker();
            this.btnGetEducationTopics = new System.Windows.Forms.Button();
            this.bgwGetEducationTopics = new System.ComponentModel.BackgroundWorker();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(578, 483);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnGetEducationTopics);
            this.tabPage1.Controls.Add(this.btnGetIncomeLevels);
            this.tabPage1.Controls.Add(this.btnGetBrazil);
            this.tabPage1.Controls.Add(this.btnGetFirst50Countries);
            this.tabPage1.Controls.Add(this.dgvResult);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(570, 457);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Queries";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnGetBrazil
            // 
            this.btnGetBrazil.Location = new System.Drawing.Point(149, 17);
            this.btnGetBrazil.Name = "btnGetBrazil";
            this.btnGetBrazil.Size = new System.Drawing.Size(134, 32);
            this.btnGetBrazil.TabIndex = 1;
            this.btnGetBrazil.Text = "Get Brazil";
            this.btnGetBrazil.UseVisualStyleBackColor = true;
            this.btnGetBrazil.Click += new System.EventHandler(this.btnGetBrazil_Click);
            // 
            // btnGetFirst50Countries
            // 
            this.btnGetFirst50Countries.Location = new System.Drawing.Point(9, 17);
            this.btnGetFirst50Countries.Name = "btnGetFirst50Countries";
            this.btnGetFirst50Countries.Size = new System.Drawing.Size(134, 32);
            this.btnGetFirst50Countries.TabIndex = 1;
            this.btnGetFirst50Countries.Text = "Get(First 50 Queries)";
            this.btnGetFirst50Countries.UseVisualStyleBackColor = true;
            this.btnGetFirst50Countries.Click += new System.EventHandler(this.btnGetFirst50Countries_Click);
            // 
            // dgvResult
            // 
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgvResult.Location = new System.Drawing.Point(3, 73);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.Size = new System.Drawing.Size(564, 381);
            this.dgvResult.TabIndex = 0;
            // 
            // bgwGetFirst50Countries
            // 
            this.bgwGetFirst50Countries.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwGetFirst50Countries_DoWork);
            this.bgwGetFirst50Countries.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwGetFirst50Countries_RunWorkerCompleted);
            // 
            // bgwGetBrazil
            // 
            this.bgwGetBrazil.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwGetBrazil_DoWork);
            this.bgwGetBrazil.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwGetBrazil_RunWorkerCompleted);
            // 
            // btnGetIncomeLevels
            // 
            this.btnGetIncomeLevels.Location = new System.Drawing.Point(289, 17);
            this.btnGetIncomeLevels.Name = "btnGetIncomeLevels";
            this.btnGetIncomeLevels.Size = new System.Drawing.Size(134, 32);
            this.btnGetIncomeLevels.TabIndex = 2;
            this.btnGetIncomeLevels.Text = "Get Income Levels";
            this.btnGetIncomeLevels.UseVisualStyleBackColor = true;
            this.btnGetIncomeLevels.Click += new System.EventHandler(this.btnGetIncomeLevels_Click);
            // 
            // bgwGetIncomeLevels
            // 
            this.bgwGetIncomeLevels.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwGetIncomeLevels_DoWork);
            this.bgwGetIncomeLevels.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwGetIncomeLevels_RunWorkerCompleted);
            // 
            // btnGetEducationTopics
            // 
            this.btnGetEducationTopics.Location = new System.Drawing.Point(429, 17);
            this.btnGetEducationTopics.Name = "btnGetEducationTopics";
            this.btnGetEducationTopics.Size = new System.Drawing.Size(134, 32);
            this.btnGetEducationTopics.TabIndex = 3;
            this.btnGetEducationTopics.Text = "Education Topics";
            this.btnGetEducationTopics.UseVisualStyleBackColor = true;
            this.btnGetEducationTopics.Click += new System.EventHandler(this.btnGetEducationTopics_Click);
            // 
            // bgwGetEducationTopics
            // 
            this.bgwGetEducationTopics.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bgwGetEducationTopics_DoWork);
            this.bgwGetEducationTopics.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwGetEducationTopics_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 483);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Example Queries";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnGetFirst50Countries;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.ComponentModel.BackgroundWorker bgwGetFirst50Countries;
        private System.Windows.Forms.Button btnGetBrazil;
        private System.ComponentModel.BackgroundWorker bgwGetBrazil;
        private System.Windows.Forms.Button btnGetIncomeLevels;
        private System.ComponentModel.BackgroundWorker bgwGetIncomeLevels;
        private System.Windows.Forms.Button btnGetEducationTopics;
        private System.ComponentModel.BackgroundWorker bgwGetEducationTopics;
    }
}

