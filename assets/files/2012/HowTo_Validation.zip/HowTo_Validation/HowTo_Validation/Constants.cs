﻿
namespace HowTo_Validation
{
    public static class Constants
    {
        public static short[] Levels = new short[] { 100, 200, 400, 800, 2000 };
        public static string[] Countries = new string[] { "Mordor", "Gondor", "Middle Earth", "Shire", "Asgard" };
    }
}
