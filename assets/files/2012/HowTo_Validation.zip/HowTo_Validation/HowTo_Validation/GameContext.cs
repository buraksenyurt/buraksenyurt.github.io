﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace HowTo_Validation
{
    public class GameContext
        :DbContext
    {
        public DbSet<Player> Players { get; set; }
        public DbSet<Layer> Layers { get; set; }
        public DbSet<Author> Authors { get; set; }

        protected override DbEntityValidationResult ValidateEntity(
            DbEntityEntry entityEntry, IDictionary<object, object> items)
        {
            var result = base.ValidateEntity(entityEntry, items);

            if (entityEntry.State == EntityState.Added &&
                entityEntry.Entity is Author)
            {
                var author = entityEntry.Entity as Author;

                if (author.Birthday > DateTime.Today)
                {
                    result.ValidationErrors.Add(
                        new DbValidationError(
                            "Yazar doğum tarihi",
                            "Doğum tarihi bugünden büyük olamaz.")
                            );
                }
            }

            return result;
        }
    }
}
