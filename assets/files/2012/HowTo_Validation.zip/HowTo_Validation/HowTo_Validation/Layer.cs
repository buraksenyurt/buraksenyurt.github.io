﻿using System.ComponentModel.DataAnnotations;

namespace HowTo_Validation
{
    public class Layer
    {
        public int LayerId { get; set; }
        
        [MaxLength(25,ErrorMessage="Katman başlığı en fazla 25 karakter olabilir")
        , Required(ErrorMessage="Bir başlık girilmelidir")]
        public string Title { get; set; }
        
        [Required(ErrorMessage="Maximum oyuncu kapasitesini girmelisiniz")
        , Range(5,100,ErrorMessage="En az 5 en fazla 100 oyuncu olabilir")]
        public int MaxPlayerCapacity { get; set; }

        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Geçersiz posta adresi")]
        public string ModeratorMail { get; set; }
    }
}   
