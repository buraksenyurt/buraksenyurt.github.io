﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace HowTo_Validation
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Code First için Doğrulama Teknikleri

            // Initialization stratejisi olarak modelde bir değişiklik olursa yeni baştan üretilmesini ifade ediyoruz
            Database.SetInitializer<GameContext>(new DropCreateDatabaseIfModelChanges<GameContext>());

            // Context nesnesi örneklenir
            using (GameContext context = new GameContext())
            {
                try
                {
                    Player jedi = new Player();
                    jedi.NickName = "jd";
                    jedi.Level = 5000;
                    jedi.Country = "Coroban";

                    context.Players.Add(jedi);

                    Layer layerSubZero = new Layer();
                    layerSubZero.Title = "bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla";
                    layerSubZero.ModeratorMail = "birmailiste";
                    layerSubZero.MaxPlayerCapacity = 200;

                    context.Layers.Add(layerSubZero);

                    Author me = new Author();
                    me.FirstName = "Burak";
                    me.Scenario = "Güzel bir oyun senaryosu var burada";
                    me.Birthday = new DateTime(2014, 1, 1);
                    me.SocialSecurityNumber = "912020";

                    context.Authors.Add(me);

                    var validationErros = context.GetValidationErrors();
                    var errorCount=WriteErrosToConsole(validationErros);
                    if(errorCount==0)
                        context.SaveChanges();

                }
                catch (DbEntityValidationException exception) // Validasyon ile ilişkili Exception' lar yakalanır
                {
                    WriteErrosToConsole(exception.EntityValidationErrors); // Exception loglanmak amacıyla ilgili metoda gönderirilir
                }
            }

            #endregion
        }

        private static int WriteErrosToConsole(IEnumerable<DbEntityValidationResult> validationErrors)
        {
            int errorCount = 0;
            // Her bir Validation Error dolaşılmaya başlanır
            foreach (DbEntityValidationResult validationError
                in validationErrors)
            {
                // Doğrulama hatasına neden olan Entity bilgisi verilir
                Console.WriteLine(
                    "Entity bazlı hata : {0}",
                    validationError.Entry.Entity);

                // Entity içerisinde doğrulama hatasına takılan özelliklerin her biri dolaşılır
                foreach (DbValidationError propertyError
                    in validationError.ValidationErrors)
                {
                    // Doğrulama hatasına takılan özelliğin adı ve hata mesajı yazdırılır
                    Console.WriteLine(
                        @" ""{0}"" özelliğinde : ""{1}"" hatası söz konusudur.",
                        propertyError.PropertyName,
                        propertyError.ErrorMessage);
                }
                errorCount++;
            }
            return errorCount;
        }
    }
}
