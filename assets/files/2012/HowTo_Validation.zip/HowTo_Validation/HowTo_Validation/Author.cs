﻿using System;

namespace HowTo_Validation
{
    public class Author
    {
        public int AuthorId { get; set; }
        public string FirstName { get; set; }
        public string Scenario { get; set; }
        public DateTime Birthday{ get; set; }
        
        [SSNValidator(ErrorMessage="Hatalı sosyal güvenlik numarası")]
        public string SocialSecurityNumber { get; set; }
    }
}
