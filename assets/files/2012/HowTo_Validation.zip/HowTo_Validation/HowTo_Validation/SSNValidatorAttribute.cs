﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HowTo_Validation
{
    [AttributeUsage(AttributeTargets.Property)]
    public class SSNValidatorAttribute
        :ValidationAttribute
    {
        private bool CheckIsValid(string ssn)
        {
            //TODO@Burak Do Something for SSN check

            return false;
        }

        public override bool IsValid(object value)
        {
            return CheckIsValid(value.ToString());
        }
    }
}
