﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace HowTo_Validation
{
    public class Player
        :IValidatableObject
    {
        public int PlayerId { get; set; }
        public string NickName { get; set; }
        public string FirstName { get; set; }
        public short Level { get; set; }
        public string Country { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (String.IsNullOrEmpty(NickName) || String.IsNullOrEmpty(FirstName) || String.IsNullOrEmpty(Country))
                yield return new ValidationResult("Nickname, FirstName veya Country değerleri boş bırakılamaz"
                    , new string[] { "NickName", "FirstName", "Country" }
                    );

            if (NickName.Length < 3 || NickName.Length>10)
                yield return new ValidationResult("NickName en az 3 karakter en fazla 10 karakter olmalıdır",new string[]{"NickName"});

            if (!Constants.Levels.Contains(Level))
                yield return new ValidationResult("Geçersiz oyuncu seviyesi.", new string[] { "Level" });

            if (!Constants.Countries.Contains(Country))
                yield return new ValidationResult("Geçersiz ülke.", new string[] { "Country" });

        }
    }
}
