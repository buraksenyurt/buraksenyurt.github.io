﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;

namespace EF6_Alpha_AsyncAwait
{
    class Program
    {
        static void Main(string[] args)
        {
            // InsertAndSelectAsync().Wait();

            Task[] tasks = new Task[5];
            tasks[0] = InsertCategory("Kitap");
            tasks[1] = InsertCategory("Kalem");
            tasks[2] = InsertCategory("Defter");
            tasks[3] = InsertCategory("Oyuncak");
            tasks[4] = WriteCategories();
            Task.WaitAll(tasks);
        }

        static async Task InsertAndSelectAsync()
        {
            await InsertCategory("Kitap");
            await InsertCategory("Kalem");
            await InsertCategory("Defter");
            await InsertCategory("Oyuncak");

            await WriteCategories();
        }

        static async Task InsertCategory(string categoryName)
        {
            using (Shop context = new Shop())
            {
                Category newCategory = new Category 
                { 
                    Name = categoryName 
                };
                context.Categories.Add(newCategory);               
                await context.SaveChangesAsync();
            }
        }

        static async Task WriteCategories()
        {
            using (Shop context = new Shop())
            {
                await context
                    .Categories
                    .ForEachAsync(c=>
                {
                    Console.WriteLine("{0} {1}",c.CategoryId,c.Name);
                });
            }
        }
    }   

    class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        //public virtual ICollection<Product> Products{ get; set; }
    }

    //class Product
    //{
    //    public int ProductId { get; set; }
    //    public string Name { get; set; }
    //    public decimal ListPrice { get; set; }
    //    public virtual Category Category { get; set; }
    //}

    class Shop
        : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        //public DbSet<Product> Products { get; set; }
    }
}
