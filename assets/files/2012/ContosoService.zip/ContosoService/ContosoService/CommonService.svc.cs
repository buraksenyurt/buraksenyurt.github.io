﻿using System;
using System.Collections.Generic;

namespace ContosoService
{
    public class CommonService 
        : ICommonService
    {
        public List<Country> GetRegion()
        {
            List<Country> asiaRegion = new List<Country>
            {
                new Country{Id=1,Name="Japan",Level=100},
                new Country{Id=2,Name="S. Korea",Level=200},
                new Country{Id=3,Name="Singapur",Level=300}
            };
            return asiaRegion;
        }
    }
}
