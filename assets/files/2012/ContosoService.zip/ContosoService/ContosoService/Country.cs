﻿
namespace ContosoService
{
    public class Country
    {
        public int Level { get; set; }
        public string Name { get; set; }
        public int Id { get; set; }
    }
}
