﻿using System.Collections.Generic;
using System.ServiceModel;

namespace ContosoService
{
    [ServiceContract]
    public interface ICommonService
    {
        [OperationContract]
        List<Country> GetRegion();
    }
}
