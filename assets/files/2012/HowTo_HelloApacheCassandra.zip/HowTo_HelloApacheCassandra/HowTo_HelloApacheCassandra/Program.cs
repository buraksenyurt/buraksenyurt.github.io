﻿using FluentCassandra;
using FluentCassandra.Connections;
using System;

namespace HowTo_HelloApacheCassandra
{
    class Program
    {
        static void Main(string[] args)
        {
            // Sunucu ile bağlant kuralım. Varsayılan olarak localhost ismiyle bağlanabiliriz.
            Server cassandraServer = new Server("localhost");

            // Komut satırından ürettiğimiz BigFootMotorCompany isimli key space ile çalışacağız
            using (var database = new CassandraContext(keyspace: "BiGFootMotorCompany", server: cassandraServer))
            {
                // sunucuya ve veritabanına bağlanıp bağlanamadığımız test etmek için bir kaç bilgi talep edelim.
                Console.WriteLine("Server port : {0}, database verison : {1}"
                    ,cassandraServer.Port
                    , database.DescribeVersion()
                    );

                #region Yeni bir Column Family oluşturmak

                CassandraColumnFamily newFamily = database.GetColumnFamily("ModelDesigner");

                // Cassandra Query Language kullanarak bir Column Family oluşturuyor ve içerisine bir kaç column ilave ediyoruz
                // Sonraki denemelerde bu satırda hata vermemesi için bir null kontrolü yapmak da işe yarayabilir
                if(newFamily==null)
                    database.ExecuteQuery(@"
                    create columnfamily 
                    ModelDesigner(
                        ModelDesignerId ascii Primary Key
                        ,Title text
                        ,Nickname text
                        ,Level int
                        ,Outsource boolean);"
                    );

                // Yeni bir satır oluşturalım
                // dynamic tipin çalışma zamanında çözümlenmesine neden olacaktır.
                dynamic burkinyus=newFamily.CreateRecord("burkinyus");
                // Key' lerin değerlerini atayalım
                burkinyus.Title = "Mr.";
                burkinyus.Nickname = "burkinyus";
                burkinyus.Level = 100;
                burkinyus.Outsource = false;

                // Yeni oluşturlan satırları Context' e ekleyelim
                database.Attach(burkinyus);

                // bir satır daha oluşturalım ve alanlarını set edelim
                dynamic oktavyus = newFamily.CreateRecord("oktavyus");
                oktavyus.Title = "Mr.";
                oktavyus.Nickname = "oktavyus";
                oktavyus.Level = 400;
                oktavyus.Outsource = true;
                
                database.Attach(oktavyus);

                // Değişiklikleri kayıt edelim
                database.SaveChanges();

                // şimdi de verileri çekip gösterelim
                var designers = database.ExecuteQuery("select * from ModelDesigner");

                foreach (dynamic designer in designers)
                {
                    Console.WriteLine("{4} - {0} {1}({2}) {3}"
                        ,designer.Title
                        ,designer.Nickname
                        ,designer.Level
                        ,designer.Outsource==true?"Outsource":"_"
                        ,designer.ModelDesignerId
                        );
                }
                #endregion
            }            
        }
    }
}
