﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="STDC_Old.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <asp:FormView runat="server" ID="formviewPlayers" DefaultMode="Edit">
        <EditItemTemplate>
                   Player Id
                   <asp:Label ID="lblPlayerId" runat="server" Text='<%#Bind("PlayerId") %>'/>
                   <br />
                   Nick name
                   <asp:TextBox ID="txtNickname" runat="server" Text='<%#Bind("Nickname") %>' />
                   <br />
                   Score
                   <asp:TextBox ID="txtScore" runat="server" Text='<%#Bind("Score") %>' />
                   <br />
           <asp:Button ID="btnUpdate" Text="Update Player Informations" runat="server" CommandName="Update"/>
            <br />
        </EditItemTemplate>
</asp:FormView>
    </div>
    </form>
</body>
</html>
