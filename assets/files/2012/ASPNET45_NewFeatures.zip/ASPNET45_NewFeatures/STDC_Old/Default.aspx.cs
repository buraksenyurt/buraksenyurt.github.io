﻿using System;
using System.Collections.Generic;
using System.Web.UI;

namespace STDC_Old
{
    public partial class Default : System.Web.UI.Page
    {        
        static List<Player> players = new List<Player>
        {
            new Player{ PlayerId=1, Nickname="Brit", Score=125},
            new Player{ PlayerId=2, Nickname="Kuşbeyin", Score=250},
            new Player{ PlayerId=3, Nickname="Zeyno", Score=90},
            new Player{ PlayerId=4, Nickname="Nikol", Score=175}
        };
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                formviewPlayers.DataSource = players;
                formviewPlayers.DataBind();
            }
        }
    }
}