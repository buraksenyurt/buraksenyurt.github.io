﻿using System.Collections.Generic;

namespace STDC_New
{
    public class Game
    {
        public int GameId { get; set; }
        public string Title { get; set; }
        public List<Player> Players { get; set; }
    }
}