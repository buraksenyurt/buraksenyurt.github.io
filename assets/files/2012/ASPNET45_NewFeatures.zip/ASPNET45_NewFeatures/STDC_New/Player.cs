﻿namespace STDC_New
{
    public class Player
    {
        public int PlayerId { get; set; }
        public string Nickname { get; set; }
        public int Score { get; set; }
    }
}