﻿using System;
using System.Collections.Generic;
using System.Web.UI;

namespace STDC_New
{
    public partial class Default 
        : System.Web.UI.Page
    {
        static List<Player> players1 = new List<Player>
        {
            new Player{ PlayerId=1, Nickname="Brit", Score=125},
            new Player{ PlayerId=2, Nickname="Kuşbeyin", Score=250},
            new Player{ PlayerId=3, Nickname="Zeyno", Score=90},
            new Player{ PlayerId=4, Nickname="Nikol", Score=175}
        };

        static List<Player> players2 = new List<Player>
        {
            new Player{ PlayerId=6, Nickname="Legolat", Score=450},
            new Player{ PlayerId=7, Nickname="Aragorn", Score=485},
            new Player{ PlayerId=8, Nickname="Gandalf the Gray", Score=555},
            new Player{ PlayerId=9, Nickname="Arven", Score=1005}
        };

        static List<Game> mordor = new List<Game>
        {
            new Game{
             GameId=1001,
             Title="Mordor Game Zone",
             Players=players1
            },
            new Game{
             GameId=4587,
             Title="Gondor Game Zone",
             Players=players2
            }
        };

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //formviewPlayers.DataSource = players1;
                //formviewPlayers.DataBind();

                listViewGame.DataSource = mordor;
                listViewGame.DataBind();
            }
        }
    }
}