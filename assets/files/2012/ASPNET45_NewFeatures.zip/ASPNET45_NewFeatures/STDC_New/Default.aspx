﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="STDC_New.Default" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <asp:ListView runat="server" ID="listViewGame" 
                ItemType="STDC_New.Game">
                <ItemTemplate>
                    <div style="background-color: gold">
                        <asp:Label ID="lblGameIt" runat="server" 
                            Text="<%#BindItem.GameId %>" />
                        Title :
                        <asp:Label ID="lblGameTitle" runat="server" 
                            Text="<%#BindItem.Title %>" /><br />
                    </div>
                    <div style="border: medium; border-color: black; background-color: lightgray">
                        <asp:ListView ID="listViewPlayers" 
                            DataSource="<%#BindItem.Players %>" 
                            ItemType="STDC_New.Player" runat="server">
                            <ItemTemplate>
                                <div style="border: double; border-color: red">
                                    <asp:Label ID="lblPlayerId" runat="server" 
                                        Text='<%#BindItem.PlayerId %>' /><br />
                                    Nickname        :
                                    <asp:Label ID="txtNickname" runat="server" 
                                        Text='<%#BindItem.Nickname %>' /><br />
                                    Current Score   :
                                    <asp:Label ID="txtScore" runat="server" 
                                        Text='<%#BindItem.Score %>' /><br />
                                </div>
                            </ItemTemplate>
                        </asp:ListView>
                    </div>
                </ItemTemplate>
            </asp:ListView>
        </div>
    </form>
</body>
</html>
