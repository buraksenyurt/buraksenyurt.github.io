﻿
namespace HowTo_EFCodeFirstConvetions
{
    class Program
    {
        static void Main(string[] args)
        {
            using(AzonBookShop context=new AzonBookShop())
            {
                Category computer = new Category { Name = "Computer Books" };
                context.Categories.Add(computer);
            }
        }
    }
}
