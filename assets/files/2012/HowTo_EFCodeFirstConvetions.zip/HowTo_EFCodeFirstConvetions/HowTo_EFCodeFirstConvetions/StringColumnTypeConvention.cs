﻿using System;
using System.Data.Entity.ModelConfiguration.Configuration.Properties.Primitive;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Reflection;

namespace HowTo_EFCodeFirstConvetions
{
    public class StringColumnTypeConvention
        :IConfigurationConvention<PropertyInfo,StringPropertyConfiguration>
    {
        public void Apply(PropertyInfo memberInfo
            , Func<StringPropertyConfiguration> configuration)
        {
            if (configuration().ColumnType == null)
            {
                configuration().ColumnType = "nvarchar";
                configuration().IsNullable = false;
                configuration().MaxLength = 50;
            }
        }
    }
}
