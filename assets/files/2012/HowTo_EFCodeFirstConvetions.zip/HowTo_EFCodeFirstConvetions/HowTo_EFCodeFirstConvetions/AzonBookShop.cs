﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace HowTo_EFCodeFirstConvetions
{
    public class AzonBookShop
        :DbContext
    {
        public DbSet<Book> Books { get; set; }
        public DbSet<Category> Categories { get; set; }

        static AzonBookShop()
        {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<AzonBookShop>());
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder
                .Properties()
                .Where(p => p.Name.Contains("Signature"))
                .Configure(p => p.IsKey());
            //modelBuilder.Conventions.AddBefore<StringLengthAttributeConvention>(new StringLengthConversion());
            modelBuilder.Conventions.Add<StringColumnTypeConvention>();
        }
    }

    public class Category
    {
        public Guid Signature { get; set; }
        public string Name { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }

    public class Book
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public decimal ListPrice { get; set; }
        public virtual Category Category { get; set; }
        //public int CategoryId { get; set; }
        public Detail BookDetail { get; set; }
    }

    public class Detail
    {
        public int PageSize { get; set; }
        public double Weight { get; set; }
        public bool HardCover { get; set; }
        public string Language { get; set; }
    }
}
