﻿using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace HowTo_EFCodeFirstConvetions
{
    public class StringLengthConversion
        : IEdmConvention<EdmProperty>
    {
        public void Apply(EdmProperty edmDataModelItem, EdmModel model)
        {
            if (edmDataModelItem.PrimitiveType.PrimitiveTypeKind == PrimitiveTypeKind.String)
                edmDataModelItem.MaxLength = 200;
        }
    }
}
