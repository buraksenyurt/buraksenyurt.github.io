﻿namespace Azon.Workflow.Activity
{
    using System.Collections.Generic;

    public class InstanceMethod
    {
        public string Name { get; set; }
        public List<InstanceMethodParameter> Parameters{ get; set; }
    }
}
