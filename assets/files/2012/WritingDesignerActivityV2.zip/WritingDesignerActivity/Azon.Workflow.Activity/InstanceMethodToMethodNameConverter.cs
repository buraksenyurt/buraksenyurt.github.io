﻿namespace Azon.Workflow.Activity
{
    using System;
    using System.Globalization;
    using System.Windows.Data;
    using System.Windows.Controls;


    public class InstanceMethodToMethodNameConverter
        :IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            InstanceMethod instanceMethod = (InstanceMethod)value;
            return instanceMethod.Name;
        }
    }
}
