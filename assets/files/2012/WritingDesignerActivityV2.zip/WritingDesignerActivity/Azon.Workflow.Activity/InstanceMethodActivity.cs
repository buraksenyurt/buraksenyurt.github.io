﻿using System.Activities;

namespace Azon.Workflow.Activity
{
    public sealed class InstanceMethodActivity
        :NativeActivity<object>
    {
        public InArgument<string> Description { get; set; }
        public string MethodName { get; set; }

        protected override void Execute(NativeActivityContext context)
        {
            //TODO@Burak burada bir takım kodlar işletilir
        }
    }
}
