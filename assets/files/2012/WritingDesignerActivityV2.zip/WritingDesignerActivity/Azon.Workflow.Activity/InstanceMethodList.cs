﻿namespace Azon.Workflow.Activity
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    public class InstanceMethodList
        :ObservableCollection<InstanceMethod>
    {
        public InstanceMethodList()
        {
            Add(new InstanceMethod
            {
                Name = "Sum",
                Parameters = new List<InstanceMethodParameter>{
                    new InstanceMethodParameter{ Name="X", DotNetType="System.Int32", ParameterType= ParameterType.Standart},
                    new InstanceMethodParameter{ Name="Y", DotNetType="System.Int32", ParameterType= ParameterType.Standart},
                    new InstanceMethodParameter{ Name="Result", DotNetType="System.Int32", ParameterType= ParameterType.Return}
                }
            });
            Add(new InstanceMethod
            {
                Name = "TotalSum",
                Parameters = new List<InstanceMethodParameter>{
                    new InstanceMethodParameter{ Name="Values", DotNetType="System.Int32[]", ParameterType= ParameterType.Params},
                    new InstanceMethodParameter{ Name="Result", DotNetType="System.Int32", ParameterType= ParameterType.Return}
                }
            });
            Add(new InstanceMethod
            {
                Name = "CallSp",
                Parameters = new List<InstanceMethodParameter>{
                    new InstanceMethodParameter{ Name="SpName", DotNetType="System.String", ParameterType= ParameterType.Standart},
                    new InstanceMethodParameter{ Name="ResultSet", DotNetType="System.Data.DataTable", ParameterType= ParameterType.Ref}
                }
            });
        }
    }
}
