﻿namespace Azon.Workflow.Activity
{
    public enum ParameterType
    {
        Ref,
        Out,
        Standart,
        Return,
        Params
    }
}
