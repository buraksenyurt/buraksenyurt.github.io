﻿namespace Azon.Workflow.Activity
{
    public class InstanceMethodParameter
    {
        public string Name { get; set; }
        public string DotNetType { get; set; }
        public ParameterType ParameterType{ get; set; }

        public override string ToString()
        {
            return string.Format("{0} {1} {2}", Name, DotNetType, ParameterType.ToString());
        }
    }
}
