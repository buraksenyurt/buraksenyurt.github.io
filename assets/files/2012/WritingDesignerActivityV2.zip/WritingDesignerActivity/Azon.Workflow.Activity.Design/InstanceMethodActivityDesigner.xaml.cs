﻿using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Text;

namespace Azon.Workflow.Activity.Design
{
    public partial class InstanceMethodActivityDesigner
    {
        #region Constructors and Destructors

        public InstanceMethodActivityDesigner()
        {
            this.InitializeComponent();
        }

        #endregion

        #region Public Methods

        public static void RegisterMetadata(AttributeTableBuilder builder)
        {
            builder.AddCustomAttributes(
                typeof(InstanceMethodActivity),
                new DesignerAttribute(typeof(InstanceMethodActivityDesigner)),
                new DescriptionAttribute("Instance Method Activity"));
        }

        #endregion

        private void btnCatchParameters_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Grid parent=((Grid)((Button)e.Source).Parent);
            foreach (UIElement control in parent.Children)
            {
                DataGrid grid=control as DataGrid;
                if(grid!=null)
                {
                    StringBuilder builder = new StringBuilder();
                    foreach (var item in grid.ItemsSource)
                    {
                        builder.AppendLine(item.ToString());
                    }
                    MessageBox.Show(builder.ToString(),"Parametreler");
                }
            }                          
        }
    }
}
