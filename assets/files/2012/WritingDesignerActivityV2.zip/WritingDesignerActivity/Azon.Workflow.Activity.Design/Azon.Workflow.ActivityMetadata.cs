﻿using System.Activities.Presentation.Metadata;
namespace Azon.Workflow.Activity.Design
{
    public sealed class ActivityLibraryMetadata
        : IRegisterMetadata
    {
        public void Register()
        {
            RegisterAll();
        }

        public static void RegisterAll()
        {
            var builder = new AttributeTableBuilder();
            InstanceMethodActivityDesigner.RegisterMetadata(builder);
            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
