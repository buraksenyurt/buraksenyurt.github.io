﻿using Kernel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace KernelTest
{
    
    
    /// <summary>
    ///This is a test class for AnalystTest and is intended
    ///to contain all AnalystTest Unit Tests
    ///</summary>
    [TestClass()]
    public class AnalystTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        /// Olmayan bir web adresi için test yapar
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Kernel.dll")]
        public void PokeTestFail()
        {
            Analyst_Accessor target = new Analyst_Accessor(); 
            string serviceAddress = "http://www.yok.com/yok.asmx"; 
            Exception actual;
            actual = target.Poke(serviceAddress);
            Assert.AreNotEqual(null, actual);
        }

        /// <summary>
        /// Var olan bir adres için test yapar
        ///</summary>
        [TestMethod()]
        [DeploymentItem("Kernel.dll")]
        public void PokeTestOk()
        {
            Analyst_Accessor target = new Analyst_Accessor();
            string serviceAddress = "http://www.w3schools.com/webservices/tempconvert.asmx"; 
            Exception actual;
            actual = target.Poke(serviceAddress);
            Assert.AreEqual(null, actual);
        }

        /// <summary>
        /// Bir servis adres listesi için gerekli testi yapar
        ///</summary>
        [TestMethod()]
        public void GetReportTestOk()
        {
            Analyst target = new Analyst();
            target.AddSource(

                new Source
                    {
                        Address = "http://www.yok.com/yok.sv",
                        Histories = null,
                        ServiceName = "Yok Servisi",
                        ServiceType = ServiceType.WcfService,
                        SourceId = 1
                    }
                );

            target.AddSource(new Source
                                 {
                                     Address = "ftp://www.w3schools.com/webservices/tempconvert.asmx",
                                     Histories = null,
                                     ServiceName = "Temp Convert",
                                     ServiceType = ServiceType.XmlWebService,
                                     SourceId = 2
                                 }
                );
            
            Dictionary<Source, SourceHistory> actual;
            actual = target.GetReport();
            Assert.AreNotEqual(0, actual.Keys.Count);
        }
    }
}
