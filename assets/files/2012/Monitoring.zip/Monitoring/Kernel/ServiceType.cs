﻿
namespace Kernel
{
    public enum ServiceType
    {
        XmlWebService,
        WcfService,
        None
    }
}
