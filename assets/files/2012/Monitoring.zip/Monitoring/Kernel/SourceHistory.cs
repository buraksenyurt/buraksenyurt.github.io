﻿using System;

namespace Kernel
{
    public class SourceHistory
    {
        public Guid SourceHistoryId { get; set; }
        public int ServiceId { get; set; }
        public ServiceState CurrentServiceState { get; set; }
        public DateTime CheckDate { get; set; }
        public Exception Exception { get; set; }
        public Source Source { get; set; }
    }
}
