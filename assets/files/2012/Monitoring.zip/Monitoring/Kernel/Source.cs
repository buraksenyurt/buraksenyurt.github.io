﻿using System;
using System.Collections.Generic;

namespace Kernel
{
    public class Source
    {
        public int SourceId { get; set; }
        public string ServiceName { get; set; }
        public ServiceType ServiceType { get; set; }
        public string Address { get; set; }
        public virtual List<SourceHistory> Histories { get; set; }
    }
}
