﻿
namespace Kernel
{
    public enum ServiceState
    {
        Live,
        Dead,
        Zombie
    }
}
