﻿using System;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;
using Kernel;
using System.Linq;

namespace Monitor
{
    public partial class frmMonitor : Form
    {
        private Analyst jackRyan = new Analyst();

        public frmMonitor()
        {
            InitializeComponent();
        }

        private void frmMonitor_Load(object sender, EventArgs e)
        {
            int interval = 10000;
            Int32.TryParse(ConfigurationManager.AppSettings["Interval"], out interval);

            timer1.Enabled = false;

            LoadSamples();

            timer1.Enabled = true;
        }

        private void LoadSamples()
        {
            jackRyan.AddSource(
                new Source
                    {
                        Address = "http://www.w3schools.com/webservices/tempconvert.asmx",
                        Histories = null,
                        ServiceName = "Temp Convert",
                        ServiceType = ServiceType.XmlWebService,
                        SourceId = 1
                    }
                );
            jackRyan.AddSource(
                new Source
                    {
                        Address = "http://www.w3schools.com/webservices/yok.asmx",
                        Histories = null,
                        ServiceName = "Empty Name",
                        ServiceType = ServiceType.None,
                        SourceId = 2
                    }
                );
            jackRyan.AddSource(
                new Source
                    {
                        Address = "http://www.webservicex.net/stockquote.asmx",
                        Histories = null,
                        ServiceName = "Stock Quote Service",
                        ServiceType = ServiceType.XmlWebService,
                        SourceId = 3
                    }
                );

            jackRyan.AddSource(
                new Source
                    {
                        Address = "http://www.webservicex.net/RealTimeMarketData.asmx",
                        Histories = null,
                        ServiceName = "Real Time Market Data Service",
                        ServiceType = ServiceType.XmlWebService,
                        SourceId = 4
                    }
                );
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            var report = jackRyan.GetReport().Select((s, h) => new
                                                                   {
                                                                       s.Key.ServiceName
                                                                       ,s.Key.Address
                                                                       ,s.Value.CheckDate
                                                                       ,s.Value.CurrentServiceState
                                                                       ,s.Value.Exception
                                                                   }).ToList();
            grdReport.DataSource = report;
        }
    }
}
