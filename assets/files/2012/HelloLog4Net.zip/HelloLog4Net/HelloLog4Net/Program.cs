﻿using System;
using System.Data;
using System.Data.SqlClient;
using log4net;

namespace HelloLog4Net
{
    class Program
    {
        static ILog log = log4net.LogManager.GetLogger(typeof(Program));

        static void Main(string[] args)
        {
            log4net.Config.BasicConfigurator.Configure();

            SqlConnection connection = null;
            try
            {
                const string connectionString = @"data source=.\SQLEXPRESS;database=AdventureWorks;user id=sa;pwd=1234.";
                log.Warn(String.Format("Bağlantı açılacak. Connection String :{0}",connectionString));
                connection=new SqlConnection(connectionString);
                if(connection.State==ConnectionState.Closed)
                    connection.Open();

                log.Info(String.Format("Bağlantı durumu : {0}",connection.State));
            }
            catch (Exception excp)
            {
                log.Error(excp.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    log.Debug(String.Format("Finally bloğundayız. Bağlantı durumu {0}", connection.State));
                }
            }

            log.Info("Program sonu");
        }
    }
}
