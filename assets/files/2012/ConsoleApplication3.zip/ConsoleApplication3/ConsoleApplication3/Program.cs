﻿using System;
using System.Linq;
using System.IO;
using Common;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Country listesini tutan fiziki dosya adresini ve telefon kod bilgilerini tutan fiziki dosya adreslerini alalım
            string countryXmlFilePath = Path.Combine(Environment.CurrentDirectory, "Countries.xml");
            string telephoneCodeXmlFilePath = Path.Combine(Environment.CurrentDirectory, "TelephoneCodes.xml");

            try
            {
                // Country tipinden generic List koleksiyonunu yardımcı kütüphanedeki static fonksiyondan üretelim.
                var countries = CountryUtility.GetCountryListFromXmlFile(countryXmlFilePath, telephoneCodeXmlFilePath);
                // Test sonuçlarını görmek amacıyla ülke listesinin bir kısmını yazdıralım
                foreach (var country in countries.Take(20))
                    Console.WriteLine(country.ToString());


                CountryUtility.WriteToXml(countries);
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
            }
        }
    }
}
