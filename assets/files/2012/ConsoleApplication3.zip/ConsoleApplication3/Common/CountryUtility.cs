﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace Common
{
    /// <summary>
    /// Country listesinin çekilmesi için gerekli yardımcı sınıftır
    /// </summary>
    public static class CountryUtility
    {
        /// <summary>
        /// Ülke listesini geriye döndürür
        /// </summary>
        /// <param name="countryFile">Ülke ad,kod ve iso bilgilerinin tutulduğu XML dosya adresidir</param>
        /// <param name="phoneCodeFile">Kod ve telefon kodu bilgilerinin tutulduğu XML dosya adresidir</param>
        /// <returns>Ülke adı, kodu, telefon alan kodu ve ISO kod bilgilerini tutan Country tipine ait bir listedir</returns>
        public static List<Country> GetCountryListFromXmlFile(string countryFile,string phoneCodeFile)
        {
            List<Country> countryList = null;

            try
            {
                XDocument countryDocument = XDocument.Load(countryFile);
                XDocument telephoneDocument = XDocument.Load(phoneCodeFile);

                countryList = (from countryNode in countryDocument.Document.Root.Elements("Country")
                               let code=countryNode.Attribute("Code").Value
                               select new Country
                               {
                                   Name = countryNode.Value,
                                   ISO = Convert.ToInt16(countryNode.Attribute("ISOCode").Value),
                                   CountryCode = code,
                                   PhoneCode = telephoneDocument.Root.Element(code)!=null?Convert.ToInt16(telephoneDocument.Root.Element(code).Value):(short)-1
                               })
                              .OrderBy(c => c.Name)
                              .ToList();
            }
            catch (Exception excp)
            {
                throw excp;
            }

            return countryList;
        }

        /// <summary>
        /// Toparlanan ülke listesini XML dosyasına kaydetmek üzere kullanılır
        /// </summary>
        /// <param name="countries">Ülkerin listesi</param>
        /// <returns>Kayıt başarılı bir şekilde yapılmış ise fiziki dosya adres bilgisini döndürür</returns>
        public static string WriteToXml(List<Country> countries)
        {
            string fileOutputPath = String.Empty;
            if (countries.Count != 0)
            {
                fileOutputPath = Path.Combine(Environment.CurrentDirectory, "Country.xml");
                XDocument xDoc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"));
                XElement root = new XElement("Countries");

                foreach (var country in countries)
                {
                    XElement element = new XElement("Country", new XAttribute("Name", country.Name), new XAttribute("PhoneCode", country.PhoneCode), new XAttribute("Code", country.CountryCode), new XAttribute("ISO", country.ISO));
                    root.Add(element);
                }
                xDoc.Add(root);
                xDoc.Save(fileOutputPath);                
            }
            return fileOutputPath;
        }
    }
}
