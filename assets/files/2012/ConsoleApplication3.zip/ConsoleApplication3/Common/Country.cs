﻿using System;

namespace Common
{
    /// <summary>
    /// Ülke
    /// </summary>
    public class Country
    {
        /// <summary>
        /// İki karakterden oluşan ülke kodu
        /// </summary>
        public string CountryCode { get; set; }
        /// <summary>
        /// ISO kodu
        /// </summary>
        public short ISO { get; set; }
        /// <summary>
        /// Ülke adı
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Uluslararası telefon kodu
        /// </summary>
        public short PhoneCode { get; set; }

        /// <summary>
        /// Bir ülkenin özelliklerini string formatta geri döndürür
        /// </summary>
        /// <returns>Ülke bilgileri</returns>
        public override string ToString()
        {
            return String.Format("{0},{1},({2}),({3})", Name, CountryCode, ISO.ToString(),PhoneCode.ToString());
        }

    }
}
