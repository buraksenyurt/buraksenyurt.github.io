﻿using System;

namespace SomeServiceApp
{
    public class WorkItem
    {
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Owner { get; set; }
        public WorkItemType Type { get; set; }
    }
}
