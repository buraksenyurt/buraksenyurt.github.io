﻿using System;

namespace SomeServiceApp
{
    public class ShipService 
        : IShipService
    {
        public string SaveWorkItem(WorkItem item)
        {
            return string.Format("{0}[{3}] {1} tarihinde {2} tarafından oluşturuldu"
                , item.Title
                ,item.CreatedDate
                ,item.Owner
                ,item.Type);
        }

        // ProccessCad için özel bir çalışma zamanı davranışı belirtilmiştir.
        [CADSizeOperationBehavior]
        public bool ProcessCadImage(byte[] sourceData)
        {
            return true;
        }
    }
}
