﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;

namespace SomeServiceApp
{
    public class ShipServiceMessageInspector
        :IDispatchMessageInspector
    {
        // Operasyon talebi servis tarafına ulaştıkan sonra devreye giriyor olacak
        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            // Gelen request nesnesinin içeriği ele alınır ;)

            return null;
        }

        // Cevap istemci tarafına gönderilmeden önce çağırılacak. Tabi eğer istisnai bir durum oluşmamışsa
        public void BeforeSendReply(ref Message reply, object correlationState)
        {
            object cs = correlationState;
        }
    }
}