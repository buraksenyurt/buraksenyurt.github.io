﻿using System;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace SomeServiceApp
{   
    public class CADSizeOperationBehavior
        :Attribute,IOperationBehavior
    {
        public void AddBindingParameters(OperationDescription operationDescription, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation)
        {
        }

        // Servis tarafındaki dispatch sürecinde araya girilmesi için gerekli tanımlamanın yapıldığı metoddur
        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {
            // sürece bir Parametre kesici tipi bildirilmektedir
            dispatchOperation.ParameterInspectors.Add(
                new CADSizeInspector 
                { 
                    DefaultControlSize = 1024 // Bu kontrol değeri ve benzeri özellikler Behavior tipi içerisinde tanımlanıp geçirilebilir de
                }
                );
        }

        public void Validate(OperationDescription operationDescription)
        {
        }
    }
}