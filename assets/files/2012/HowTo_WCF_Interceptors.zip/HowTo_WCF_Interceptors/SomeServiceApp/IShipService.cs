﻿using System.ServiceModel;

namespace SomeServiceApp
{
    [ServiceContract]
    public interface IShipService
    {
        [OperationContract]
        string SaveWorkItem(WorkItem item);

        [OperationContract]
        bool ProcessCadImage(byte[] sourceData);
    }
}
