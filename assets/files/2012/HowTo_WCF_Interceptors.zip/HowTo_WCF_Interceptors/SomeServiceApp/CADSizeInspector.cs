﻿using System.ServiceModel;
using System.ServiceModel.Dispatcher;

namespace SomeServiceApp
{
    public class CADSizeInspector
        :IParameterInspector
    {
        public double DefaultControlSize { get; set; }

        // Operasyon çağrısı tamamlandıktan sonra devreye girecektir.
        public void AfterCall(string operationName, object[] outputs, object returnValue, object correlationState)
        {
            
        }

        // Çağırılan operasyon başlatılmadan önce devreye girecektir
        public object BeforeCall(string operationName, object[] inputs)
        {
            // Operasyon adını kontrol ediyoruz
            if (operationName == "ProcessCadImage")
            {
                // Gelen ilk parametre operasyonumuza göre byte[] dizisi. Eğer DefaultControlSize' dan büyükse geriye bir FaultException döndürülmektedir
                if (((byte[])inputs[0]).Length > DefaultControlSize)
                    throw new FaultException("CAD çizimine ait mesaj boyutu varsayılandan büyük.");
            }

            // Herhangibir sıkıntı yoksa null dönerek operasyonun devam etmesini sağlayabiliriz.
            return null;
        }
    }
}