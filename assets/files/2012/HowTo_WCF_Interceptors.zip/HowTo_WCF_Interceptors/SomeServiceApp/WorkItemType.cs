﻿
namespace SomeServiceApp
{
    public enum WorkItemType
    {
        UserStory,
        Task,
        TestCase,
        Bug
    }
}
