﻿using ClientApp.ShipServiceReference;
using System;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ShipServiceClient proxy = null;
            try
            {
                proxy = new ShipServiceClient("BasicHttpBinding_IShipService");

                WorkItem wi = new WorkItem
                {
                    CreatedDate = DateTime.Now,
                    Owner = "Burak",
                    Title = "Login sayfasına ait Web User Control geliştirilmesi",
                    Type = WorkItemType.Task
                };

                string swiResult = proxy.SaveWorkItem(wi);
                Console.WriteLine(swiResult);

                byte[] someImageData = new byte[4096];
                bool pcResult = proxy.ProcessCadImage(someImageData);
                Console.WriteLine(pcResult);
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
            }
            finally
            {
                if (proxy != null
                    && proxy.State == System.ServiceModel.CommunicationState.Opened)
                    proxy.Close();
            }
        }
    }
}
