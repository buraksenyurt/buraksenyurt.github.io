﻿using System;
using System.Windows.Forms;

namespace DbGenerator.Design
{
    public partial class Form1 : Form
    {
        public string ConnectionString { get; set; }
        public string NamespaceName { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtConnectionString.Text))
                ConnectionString = txtConnectionString.Text;
            if (!string.IsNullOrEmpty(txtDbName.Text))
                NamespaceName = txtDbName.Text;

            DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
