﻿using System.Collections.Generic;
using System.Windows.Forms;
using EnvDTE;
using Microsoft.VisualStudio.TemplateWizard; 

namespace DbGenerator.Design
{
    public class GeneratorDesigner
        :IWizard
    {
        private bool CanAddProjectItem;

        public void RunStarted(object automationObject, Dictionary<string, string> replacementsDictionary, WizardRunKind runKind, object[] customParams)
        {
            Form1 frm = new Form1();
            if (frm.ShowDialog() == DialogResult.OK)
            {
                replacementsDictionary.Add("$connectionString$", frm.ConnectionString);
                replacementsDictionary.Add("$dbnameString$", frm.NamespaceName);
            }
            else
            {
                // Default bir değer kısımlarına geçerli bir takım bilgiler yazmakta yarar olabilir. Nitekim geçerli bir ConnectionString bilgisi olmaması halinde uygulama hata verecek ve cs dosyaları başarılı bir şekilde üretilmeyecektir.
                replacementsDictionary.Add("$connectionString$", "default bir değer");
                replacementsDictionary.Add("$dbnameString$", "Default bir değer");
            }
            CanAddProjectItem = true;
        }

        public bool ShouldAddProjectItem(string filePath)
        {
            return CanAddProjectItem;
        }

        public void BeforeOpeningFile(ProjectItem projectItem)
        {
        }

        public void ProjectFinishedGenerating(Project project)
        {
        }

        public void ProjectItemFinishedGenerating(ProjectItem projectItem)
        {
        }

        public void RunFinished()
        {
        } 
    }
}
