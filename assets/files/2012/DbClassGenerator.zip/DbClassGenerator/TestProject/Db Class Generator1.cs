﻿// Özet			: Bu dosya içerisinde seçilen veritabanı içerisindeki tablolara eş düşen birer sınıf söz konusudur
// Yazan		: Unknown Developer
// Yazım tarihi : Uzay Tarihi 2012
using System;
using System.Linq;

namespace Chinook 
{
	public class Album
	{
		public int AlbumId{get;set;}
		public int ArtistId{get;set;}
		public string Title{get;set;}
	}
	public class Artist
	{
		public int ArtistId{get;set;}
		public string Name{get;set;}
	}
	public class Customer
	{
		public string Address{get;set;}
		public string City{get;set;}
		public string Company{get;set;}
		public string Country{get;set;}
		public int CustomerId{get;set;}
		public string Email{get;set;}
		public string Fax{get;set;}
		public string FirstName{get;set;}
		public string LastName{get;set;}
		public string Phone{get;set;}
		public string PostalCode{get;set;}
		public string State{get;set;}
		public int SupportRepId{get;set;}
	}
	public class Employee
	{
		public string Address{get;set;}
		public DateTime BirthDate{get;set;}
		public string City{get;set;}
		public string Country{get;set;}
		public string Email{get;set;}
		public int EmployeeId{get;set;}
		public string Fax{get;set;}
		public string FirstName{get;set;}
		public DateTime HireDate{get;set;}
		public string LastName{get;set;}
		public string Phone{get;set;}
		public string PostalCode{get;set;}
		public int ReportsTo{get;set;}
		public string State{get;set;}
		public string Title{get;set;}
	}
	public class Genre
	{
		public int GenreId{get;set;}
		public string Name{get;set;}
	}
	public class Invoice
	{
		public string BillingAddress{get;set;}
		public string BillingCity{get;set;}
		public string BillingCountry{get;set;}
		public string BillingPostalCode{get;set;}
		public string BillingState{get;set;}
		public int CustomerId{get;set;}
		public DateTime InvoiceDate{get;set;}
		public int InvoiceId{get;set;}
		public int Total{get;set;}
	}
	public class InvoiceLine
	{
		public int InvoiceId{get;set;}
		public int InvoiceLineId{get;set;}
		public int Quantity{get;set;}
		public int TrackId{get;set;}
		public int UnitPrice{get;set;}
	}
	public class MediaType
	{
		public int MediaTypeId{get;set;}
		public string Name{get;set;}
	}
	public class Playlist
	{
		public string Name{get;set;}
		public int PlaylistId{get;set;}
	}
	public class PlaylistTrack
	{
		public int PlaylistId{get;set;}
		public int TrackId{get;set;}
	}
	public class Track
	{
		public int AlbumId{get;set;}
		public int Bytes{get;set;}
		public string Composer{get;set;}
		public int GenreId{get;set;}
		public int MediaTypeId{get;set;}
		public int Milliseconds{get;set;}
		public string Name{get;set;}
		public int TrackId{get;set;}
		public int UnitPrice{get;set;}
	}
 
}