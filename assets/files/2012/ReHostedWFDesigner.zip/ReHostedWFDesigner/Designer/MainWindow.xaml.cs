﻿using System;
using System.Activities;
using System.Activities.Core.Presentation;
using System.Activities.Presentation;
using System.Activities.Presentation.Toolbox;
using System.Activities.Statements;
using System.Activities.XamlIntegration;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace Designer
{
    // Illegal Cross Thread Exception' dan kaçmak için kullandığımız temsilci tipi
    delegate void BindCompletionStateToLabelDelegate(WorkflowApplicationCompletedEventArgs state);

    public partial class MainWindow
        : Window
    {
        // WorkflowDesigner
        private WorkflowDesigner wfDesigner;
        private string currentFileName = String.Empty;

        public MainWindow()
        {
            InitializeComponent();

            RegisterMetadata();
            AddDesigner(new Flowchart());
            AddToolBox();
            AddPropertyInspector();
        }


        // Designer için Metadata içeriği register edilir
        private void RegisterMetadata()
        {
            DesignerMetadata dMetadata = new DesignerMetadata();
            dMetadata.Register();
        }

        // Bir instance' dan WorkflowDesigner' ın yüklenilmesi sağlanır. Örneğin bir Flowchart bileşeni veya Sequence designer içerisine açılabilir.
        private void AddDesigner(object instance)
        {
            wfDesigner = new WorkflowDesigner();            
            wfDesigner.Load(instance);
            BindDesignerEvents(wfDesigner);
            BindWfDesignerToGrid();
        }

        // WorkflowDesigner içeriğinin XAML tabanlı bir dosya içeriğindeki activity ile yüklenmesini sağlar
        private void AddDesigner(string xamlFileName)
        {
            wfDesigner = new WorkflowDesigner();
            wfDesigner.Load(xamlFileName);
            BindDesignerEvents(wfDesigner);
            BindWfDesignerToGrid();
        }

        // WorkflowDesigner' ın örnek olay metodlarını yükler
        private void BindDesignerEvents(WorkflowDesigner wfDesigner)
        {
            wfDesigner.ModelChanged += (obj, e) =>
            {
                labelStatus.Content = "Model Changed";
            };
        }

        // WorkflowDesigner bileşeninin WPF içeriğine element olarak eklenmesini sağlar
        private void BindWfDesignerToGrid()
        {
            Grid.SetColumn(wfDesigner.View, 1);
            if (Grid.GetColumn(wfDesigner.View) == 1)
                grdScene.Children.Remove(wfDesigner.View);
            grdScene.Children.Add(wfDesigner.View);
        }

        // Toolbox içeriğinin WPF penceresine eklenmesini sağlar
        private void AddToolBox()
        {
            ToolboxControl control = GetToolboxControl();
            Grid.SetColumn(control, 0);
            grdScene.Children.Add(control);
        }

        // Örnek Workflow Component' lerinin Toolbox içeriğine eklenmesini sağlar
        private ToolboxControl GetToolboxControl()
        {
            ToolboxControl tbxControl = new ToolboxControl();

            #region Genel

            ToolboxCategory tbxStandartControls = new ToolboxCategory("Genel");

            ToolboxItemWrapper toolAssign = new ToolboxItemWrapper(typeof(Assign), "Atama");
            ToolboxItemWrapper toolFlowDecision = new ToolboxItemWrapper(typeof(FlowDecision), "Karar");
            ToolboxItemWrapper toolFlowchart = new ToolboxItemWrapper(typeof(Flowchart), "Akış Diagramı");
            ToolboxItemWrapper toolIf = new ToolboxItemWrapper(typeof(If), "Eğer");
            ToolboxItemWrapper toolSequence = new ToolboxItemWrapper(typeof(Sequence), "Sekans");
            ToolboxItemWrapper toolDelay = new ToolboxItemWrapper(typeof(Delay), "Duraksat");
            ToolboxItemWrapper toolDoWhile = new ToolboxItemWrapper(typeof(DoWhile), "Do While Döngü");

            tbxStandartControls.Add(toolAssign);
            tbxStandartControls.Add(toolSequence);
            tbxStandartControls.Add(toolDelay);
            tbxStandartControls.Add(toolDoWhile);
            tbxStandartControls.Add(toolFlowchart);
            tbxStandartControls.Add(toolFlowDecision);
            tbxStandartControls.Add(toolIf);

            #endregion

            #region Adapterler

            ToolboxCategory tbxAdapterControls = new ToolboxCategory("External Adapters");

            tbxControl.Categories.Add(tbxStandartControls);
            tbxControl.Categories.Add(tbxAdapterControls);

            #endregion

            return tbxControl;
        }

        // Seçilen Workflow bileşeni veya component için gerekli özelliklerin yüklenmesini sağlar
        private void AddPropertyInspector()
        {
            if (Grid.GetColumn(wfDesigner.PropertyInspectorView) == 2)
            {
                grdScene.Children.Remove(wfDesigner.PropertyInspectorView);
            }
            else
            {
                Grid.SetColumn(wfDesigner.PropertyInspectorView, 2);
                grdScene.Children.Add(wfDesigner.PropertyInspectorView);
            }
        }

        // Tasarlanan Workflow içeriğinin XAML uzantılı olarak kayıt edilmesini sağlar
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "XAML Files|*.xaml";
            sfd.InitialDirectory = Environment.CurrentDirectory;
            if (sfd.ShowDialog().Value == true)
            {
                wfDesigner.Save(sfd.FileName);
                currentFileName = sfd.FileName;
                labelStatus.Content = string.Format("{0}(Saved)", sfd.FileName);
            }
        }

        // Workflow' un designer içerisine XAML tabanlı bir içerikten okunmasını sağlar
        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "XAML Files|*.xaml";
            ofd.InitialDirectory = Environment.CurrentDirectory;
            if (ofd.ShowDialog().Value == true)
            {
                AddDesigner(ofd.FileName);
                AddPropertyInspector();
                currentFileName = ofd.FileName;
                labelStatus.Content = string.Format("{0}(Loaded)", ofd.FileName);
            }
        }

        // Boş bir Flowchart içerikli Workflow oluşturulmasını sağlar
        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            AddDesigner(new Flowchart());
            AddPropertyInspector();
            labelStatus.Content = "Yeni Akışı";
            currentFileName = String.Empty;
        }

        // Workflow' un Run edilmesi için kullanılır
        private void btnRun_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Activity activity = LoadActivity(currentFileName);
                ExecuteActivity(activity);
            }
            catch (Exception excp)
            {
                labelStatus.Content = string.Format("{0} nedeni ile activity başarılı bir şekilde çalıştırılamadı", excp.Message);
            }
        }

        // Workflow icrasını gerçekleştirir
        private void ExecuteActivity(Activity activity)
        {
            AutoResetEvent aReseter = new AutoResetEvent(false);

            WorkflowApplication wfApp = new WorkflowApplication(activity);
            wfApp.Completed += ea =>
            {
                aReseter.Set();
                labelStatus
                    .Dispatcher
                    .Invoke(
                    new BindCompletionStateToLabelDelegate(BindCompletaionStateToLabel)
                    , ea
                    );
            };
            wfApp.Run();
            aReseter.WaitOne();
        }

        // Illegal Cross Thread Exception' dan kaçtığımız ve Label kontrolüne diğer Thread içerisinden değiştirmemizi sağlayan metod
        private void BindCompletaionStateToLabel(WorkflowApplicationCompletedEventArgs state)
        {
            labelStatus.Content = string.Format(
                "{0} ID li akış için Completion State {1}"
                , state.InstanceId, state.CompletionState
                );
        }

        // XAML içeriğinden Activity bileşenini üretmek için kullanılır
        private Activity LoadActivity(string currentFileName)
        {
            Activity loadedActivity = null;

            if (!string.IsNullOrEmpty(currentFileName)
                && Path.GetExtension(currentFileName).ToUpper() == ".XAML")
            {
                loadedActivity = ActivityXamlServices.Load(currentFileName);
                labelStatus.Content = string.Format(
                    "{0}({2}) run edilmek üzere {1} lokasyonundan yüklendi"
                    , loadedActivity.DisplayName
                    , currentFileName
                    , loadedActivity.Id
                    );
            }
            return loadedActivity;
        }
    }
}
