﻿using BingMaps.Common.Route;
using Geo = BingMaps.Common.GeoCode;
using System;
using Src = BingMaps.Common.Search;
using System.Text;
using System.Collections.Generic;
using Route = BingMaps.Common.Route;

namespace BingMaps.Common
{
    public static class CommonOperations
    {
        private const string appKey = "Config dosyasından okuyabilir veya buraya sabit olarak ekleyebilirsiniz";

        public static Geo.GeocodeResponse GetLocationPoints(string city)
        {
            Geo.GeocodeResponse response = null;
            if (string.IsNullOrEmpty(city))
                return response;

            Geo.GeocodeRequest geocodeRequest = new Geo.GeocodeRequest();

            geocodeRequest.Credentials = new Geo.Credentials();
            geocodeRequest.Credentials.ApplicationId = appKey;

            geocodeRequest.Query = city;

            Geo.ConfidenceFilter[] filters = new Geo.ConfidenceFilter[1];
            filters[0] = new Geo.ConfidenceFilter();
            filters[0].MinimumConfidence = Geo.Confidence.Low;

            Geo.GeocodeOptions geocodeOptions = new Geo.GeocodeOptions();
            geocodeOptions.Filters = filters;
            geocodeRequest.Options = geocodeOptions;

            Geo.GeocodeServiceClient geocodeService = new Geo.GeocodeServiceClient();
            response = geocodeService.Geocode(geocodeRequest);

            return response;
        }

        public static List<string> Search(string keyword, string location)
        {
            List<String> results = new List<string>();
            if (String.IsNullOrEmpty(keyword) || string.IsNullOrEmpty(location))
                return results;

            Src.SearchRequest request = new Src.SearchRequest();
            request.Culture = "en-US";

            request.Credentials = new Src.Credentials();
            request.Credentials.ApplicationId = appKey;

            Src.StructuredSearchQuery query = new Src.StructuredSearchQuery();
            query.Keyword = keyword;
            query.Location = location;
            request.StructuredQuery = query;

            Src.FilterExpression atmosphereFilterExpression = new Src.FilterExpression();
            atmosphereFilterExpression.PropertyId = 23; // Atmosphere Property ID değeri 23
            atmosphereFilterExpression.FilterValue = 10; // 10 = Romantic bir ortam arıyoruz
            atmosphereFilterExpression.CompareOperator = Src.CompareOperator.Equals;

            Src.FilterExpression ratingExpression = new Src.FilterExpression()
                        {
                            PropertyId = 3, //Rating property ID
                            CompareOperator = Src.CompareOperator.GreaterThanOrEquals, //Rating değerine göre 3 ve üstünde olan yerler
                            FilterValue = 7 // Kullanıcıların verdiği rating değeri
                        };

            Src.FilterExpressionClause combinedFilterExpressionClause = new Src.FilterExpressionClause();
            combinedFilterExpressionClause.Expressions =
               new Src.FilterExpressionBase[]
               {
                   ratingExpression,
                   atmosphereFilterExpression
               };

            combinedFilterExpressionClause.LogicalOperator = Src.LogicalOperator.And;

            request.SearchOptions = new Src.SearchOptions();
            request.SearchOptions.Filters = combinedFilterExpressionClause;


            Src.SearchServiceClient searchService = new Src.SearchServiceClient();
            Src.SearchResponse response = searchService.Search(request);

            if (response.ResultSets[0].Results.Length > 0)
            {
                for (int i = 0; i < response.ResultSets[0].Results.Length; i++)
                {
                    results.Add(String.Format("{0}\n({1};{2})\n",
                        response.ResultSets[0].Results[i].Name,
                        response.ResultSets[0].Results[i].LocationData.Locations[0].Latitude,
                        response.ResultSets[0].Results[i].LocationData.Locations[0].Longitude
                        )
                        );
                }
            }

            return results;
        }

        public static Route.RouteResponse GetRoute(List<string> points)
        {
            if (points.Count < 2)
                return null;

            List<Route.Waypoint> waypoints = new List<Route.Waypoint>();
            Route.RouteRequest routeRequest = new RouteRequest();
            routeRequest.Credentials = new Route.Credentials();
            routeRequest.Credentials.ApplicationId = appKey;

            foreach (string point in points)
            {
                Geo.GeocodeResponse response=GetLocationPoints(point);
                if (response != null)
                {
                    Waypoint wp = new Waypoint();
                    wp.Location = new Route.Location();
                    wp.Location.Latitude = response.Results[0].Locations[0].Latitude;
                    wp.Location.Longitude = response.Results[0].Locations[0].Longitude;
                    waypoints.Add(wp);
                }
                else
                {
                    return null;
                }
            }
            routeRequest.Waypoints = waypoints.ToArray();

            Route.RouteServiceClient routeService = new Route.RouteServiceClient();
            Route.RouteResponse routeResponse = routeService.CalculateRoute(routeRequest);

            return routeResponse;
        }
    }
}
