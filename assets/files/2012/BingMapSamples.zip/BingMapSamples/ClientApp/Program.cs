﻿using System;
using BingMaps.Common;
using BingMaps.Common.GeoCode;
using System.Collections.Generic;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Bir lokasyon bilgisi giriniz");
            //GetValue(Console.ReadLine());

            //Console.WriteLine("Ne arıyorsunuz?");
            //string keyword = Console.ReadLine();
            //Console.WriteLine("Nerede arıyorsunuz?");
            //string location = Console.ReadLine();

            //Search(keyword,location);

            Console.WriteLine("Nereden?");
            string nereden = Console.ReadLine();
            Console.WriteLine("Nereye?");
            string nereye = Console.ReadLine();
            GetValue(nereye, nereden);
        }

        private static void GetValue(string nereye, string nereden)
        {
            var result = CommonOperations.GetRoute(new List<string> {nereden, nereye});

            foreach (var leg in result.Result.Legs)
            {
                foreach (var i in leg.Itinerary)
                {
                    Console.WriteLine("{0}\n", i.Text);
                }
            }
        }

        private static void Search(string keyword,string location)
        {
            List<string> results = CommonOperations.Search(keyword,location);
            foreach (string result in results)
            {
                Console.WriteLine(result);
            }
        }
        private static void GetValue(string location)
        {
            GeocodeResponse response = CommonOperations.GetLocationPoints(location);
            foreach (GeocodeResult r in response.Results)
            {
                Console.WriteLine("{0}", r.DisplayName);

                foreach (GeocodeLocation l in r.Locations)
                {
                    Console.WriteLine("\t(Enlem : {0}; Boylam : {1})"
                                      , l.Latitude
                                      , l.Longitude
                        );
                }
            }
        }
    }
}
