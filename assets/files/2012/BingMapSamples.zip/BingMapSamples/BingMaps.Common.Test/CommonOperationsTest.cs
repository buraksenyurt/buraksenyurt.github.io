﻿using BingMaps.Common.GeoCode;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BingMaps.Common;
using System;
using System.Collections.Generic;
using BingMaps.Common.Route;

namespace BingMaps.Common.Test
{   
    [TestClass()]
    public class CommonOperationsTest
    {
        [TestMethod()]
        public void FindIstanbulOkTest()
        {
            string city = "istanbul";
            string expected = "Istanbul, Turkey";
            GeocodeResponse actual;
            actual = CommonOperations.GetLocationPoints(city);
            Assert.AreEqual(expected, actual.Results[0].DisplayName);
        }

        [TestMethod()]
        public void ZeroDataFailTest()
        {
            string city = string.Empty;
            string expected = null;
            GeocodeResponse actual;
            actual = CommonOperations.GetLocationPoints(city);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void SearchRomanticRestaurantsInLasVegasOkTest()
        {
            string keyword = "restaurant";
            string location = "las vegas";
            List<string> actual;
            actual = CommonOperations.Search(keyword, location);
            Assert.AreNotEqual(0, actual.Count);
        }

        [TestMethod()]
        public void GetRouteFromSirkeciToPendikIsExistTest()
        {
            List<string> points = new List<string> {"sirkeci,istanbul"
                , "pendik,istanbul"};
            RouteResponse actual;
            actual = CommonOperations.GetRoute(points);
            Assert.AreNotEqual(null, actual);
        }
    }
}
