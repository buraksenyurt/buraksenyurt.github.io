﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Workflow.Activities.Rules;
using System.Workflow.Activities.Rules.Design;

namespace WFRuleSetHowTo
{
    public partial class Form1 : Form
    {
        Product sampleProduct = null;
        RuleSet sampleRuleSet = null;
        string ruleSetFileName = Path.Combine(Environment.CurrentDirectory, "Product.rules");

        public Form1()
        {
            InitializeComponent();
            // Kullanılacak olan RuleSet örneklenir
            sampleRuleSet = new RuleSet();
        }

        private void btnCreateProduct_Click(object sender, EventArgs e)
        {
            decimal price;
            int stockLevel;
            
            // RuleSet testi için örnek bir Product instance' ı oluşturulur
            sampleProduct = new Product
            {
                ProductId=Guid.NewGuid(),
                Name=!String.IsNullOrEmpty(txtProductName.Text)?txtProductName.Text:"Ornektir",
                ListPrice=decimal.TryParse(txtProductListPrice.Text,out price)?price:1M,
                StockLevel=int.TryParse(txtStockLevel.Text,out stockLevel)?stockLevel:100
            };

            MessageBox.Show(string.Format("{0} örnek kullanım için üretildi",sampleProduct.ToString()));
        }

        private void btnCreateRule_Click(object sender, EventArgs e)
        {
            // RuleSet' in oluşturulacağı Dialog nesnesi örneklenir
            // ilk parametre kuralın uygulanacağı nesne tipidir
            RuleSetDialog rsDialog = new RuleSetDialog(typeof(Product), null, sampleRuleSet);
            if (rsDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (Utility.Save(ruleSetFileName,rsDialog.RuleSet))
                    MessageBox.Show("Rule Set başarılı bir şekilde kayıt edildi");
                else
                    MessageBox.Show("İşlemlerinizi gözden geçiriniz. RuleSet kayıt edilemedi");
            }
        }

        private void btnLoadRule_Click(object sender, EventArgs e)
        {
            sampleRuleSet = Utility.Load(ruleSetFileName);
            if (sampleRuleSet != null)
                MessageBox.Show("RuleSet başarılı bir şekilde yüklendi");
            else
                MessageBox.Show("RuleSet yüklenemedi!");
        }

        private void btnRunRule_Click(object sender, EventArgs e)
        {
            // Elimizde bir RuleSet' imiz var ise
            if (sampleRuleSet != null)
            {
                // Kuralı işletmek için gerekli doğrulama nesnesi örnek Product tipi için üretilir
                RuleValidation validation = new RuleValidation(sampleProduct.GetType(), null);
                // Kuralı işletecek olan motor örneklenir. İlk parametre doğrulama kriterlerini ikinci parametre ise doğrulamaya tabi olacak canlı nesne örneğini içerir
                RuleExecution engine = new RuleExecution(validation, sampleProduct);
                // Kural işletilir.
                sampleRuleSet.Execute(engine);
                MessageBox.Show(sampleProduct.ToString());
            }
        }
    }
}
