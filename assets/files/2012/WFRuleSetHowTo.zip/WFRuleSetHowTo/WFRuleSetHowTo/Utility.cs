﻿using System;
using System.Workflow.Activities.Rules;
using System.Workflow.ComponentModel.Serialization;
using System.Xml;

namespace WFRuleSetHowTo
{
    public static class Utility
    {
        // Workflow RuleSet' lerin XAML bazlı serileştirilmesi/ters serileştirilmesi için gerekli nesne örneklenir
        private static WorkflowMarkupSerializer serializer = new WorkflowMarkupSerializer();
        
        public static RuleSet Load(string ruleSetFileName)
        {
            RuleSet ruleSet = null;
            try
            {
                // RuleSet dosyası okunmak üzere reader' a yüklenir
                XmlTextReader reader = new XmlTextReader(ruleSetFileName);
                // Ters serileştirme işlemi uygulanarak RuleSet içeriği nesnelleştirilir
                ruleSet = serializer.Deserialize(reader) as RuleSet;
                reader.Close();
            }
            catch (Exception excp)
            {
                //TODO@Burak Do Something   
            }

            return ruleSet;
        }

        public static bool Save(string ruleSetFileName, RuleSet ruleset)
        {
            bool result = false;
            try
            {
                // RuleSet' i kaydetmek için bir writer oluşturulur
                XmlTextWriter writer = new XmlTextWriter(ruleSetFileName, null);
                // RuleSet ilgili dosya içerisine serileştirilir
                serializer.Serialize(writer, ruleset);
                result = true;
                writer.Flush();
                writer.Close();
            }
            catch (Exception excp)
            {
                //TODO@Burak Do Something
            }
            return result;         
        }
    }
}
