﻿namespace WFRuleSetHowTo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtProductListPrice = new System.Windows.Forms.TextBox();
            this.txtStockLevel = new System.Windows.Forms.TextBox();
            this.btnCreateProduct = new System.Windows.Forms.Button();
            this.btnCreateRule = new System.Windows.Forms.Button();
            this.btnLoadRule = new System.Windows.Forms.Button();
            this.btnRunRule = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCreateProduct);
            this.groupBox1.Controls.Add(this.txtStockLevel);
            this.groupBox1.Controls.Add(this.txtProductListPrice);
            this.groupBox1.Controls.Add(this.txtProductName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(391, 124);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Yeni Ürün";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Birim Fiyatı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Stok Miktarı";
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(84, 26);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(179, 20);
            this.txtProductName.TabIndex = 3;
            // 
            // txtProductListPrice
            // 
            this.txtProductListPrice.Location = new System.Drawing.Point(84, 55);
            this.txtProductListPrice.Name = "txtProductListPrice";
            this.txtProductListPrice.Size = new System.Drawing.Size(100, 20);
            this.txtProductListPrice.TabIndex = 4;
            // 
            // txtStockLevel
            // 
            this.txtStockLevel.Location = new System.Drawing.Point(84, 87);
            this.txtStockLevel.Name = "txtStockLevel";
            this.txtStockLevel.Size = new System.Drawing.Size(100, 20);
            this.txtStockLevel.TabIndex = 5;
            // 
            // btnCreateProduct
            // 
            this.btnCreateProduct.Location = new System.Drawing.Point(306, 87);
            this.btnCreateProduct.Name = "btnCreateProduct";
            this.btnCreateProduct.Size = new System.Drawing.Size(75, 23);
            this.btnCreateProduct.TabIndex = 6;
            this.btnCreateProduct.Text = "Örneklendir";
            this.btnCreateProduct.UseVisualStyleBackColor = true;
            this.btnCreateProduct.Click += new System.EventHandler(this.btnCreateProduct_Click);
            // 
            // btnCreateRule
            // 
            this.btnCreateRule.Location = new System.Drawing.Point(12, 29);
            this.btnCreateRule.Name = "btnCreateRule";
            this.btnCreateRule.Size = new System.Drawing.Size(75, 23);
            this.btnCreateRule.TabIndex = 1;
            this.btnCreateRule.Text = "Rule Oluştur";
            this.btnCreateRule.UseVisualStyleBackColor = true;
            this.btnCreateRule.Click += new System.EventHandler(this.btnCreateRule_Click);
            // 
            // btnLoadRule
            // 
            this.btnLoadRule.Location = new System.Drawing.Point(93, 29);
            this.btnLoadRule.Name = "btnLoadRule";
            this.btnLoadRule.Size = new System.Drawing.Size(75, 23);
            this.btnLoadRule.TabIndex = 2;
            this.btnLoadRule.Text = "Rule Yükle";
            this.btnLoadRule.UseVisualStyleBackColor = true;
            this.btnLoadRule.Click += new System.EventHandler(this.btnLoadRule_Click);
            // 
            // btnRunRule
            // 
            this.btnRunRule.Location = new System.Drawing.Point(306, 29);
            this.btnRunRule.Name = "btnRunRule";
            this.btnRunRule.Size = new System.Drawing.Size(75, 23);
            this.btnRunRule.TabIndex = 3;
            this.btnRunRule.Text = "Rule Çalıştır";
            this.btnRunRule.UseVisualStyleBackColor = true;
            this.btnRunRule.Click += new System.EventHandler(this.btnRunRule_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCreateRule);
            this.groupBox2.Controls.Add(this.btnRunRule);
            this.groupBox2.Controls.Add(this.btnLoadRule);
            this.groupBox2.Location = new System.Drawing.Point(12, 143);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(391, 69);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rules";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 229);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "WF Rule How To";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtStockLevel;
        private System.Windows.Forms.TextBox txtProductListPrice;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCreateProduct;
        private System.Windows.Forms.Button btnCreateRule;
        private System.Windows.Forms.Button btnLoadRule;
        private System.Windows.Forms.Button btnRunRule;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

