﻿using System;

namespace WFRuleSetHowTo
{
    public class Product
    {
        public Guid ProductId { get; set; }
        public string Name { get; set; }
        public decimal ListPrice { get; set; }
        public int StockLevel { get; set; }
        public string ErrorInformation { get; set; }

        public override string ToString()
        {
            return string.Format("{0} {1} {2} {3} [{4}]"
                , ProductId
                , Name
                , ListPrice
                , StockLevel
                ,ErrorInformation
                );
        }
    }
}
