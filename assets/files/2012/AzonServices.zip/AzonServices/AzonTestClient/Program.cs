﻿using System;
using System.Collections.Generic;
using AzonTestClient.Azon;

namespace AzonTestClient
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductServiceClient proxy = new ProductServiceClient("BasicHttpBinding_IProductService");
            int result = proxy.CreateProducts(1000000);

            Console.WriteLine(result.ToString());
            Console.WriteLine("Kapatmak için bir tuşa basınız");
            Console.ReadLine();
        }
    }
}
