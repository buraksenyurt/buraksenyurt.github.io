﻿using System.ServiceModel;
using System;

namespace AzonServices
{
    [ServiceContract]
    public interface IProductService
    {
        //[OperationContract]
        //int CreateProducts(int totalProductCount);

        [OperationContract(AsyncPattern=true,Action="CreateProducts",Name="CreateProducts",ReplyAction ="CreateProductsReply")]
        IAsyncResult BeginCreateProducts(int totalProductCount,AsyncCallback callback,object asyncState);

        int EndCreateProducts(IAsyncResult result);
    }
}
