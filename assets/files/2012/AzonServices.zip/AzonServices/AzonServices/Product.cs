﻿
namespace AzonServices
{
    class Product
    {
        public char Class { get; set; }
        public int StockSize { get; set; }
        public int ListPrice { get; set; }
        public string Name { get; set; }
        public int ProductId { get; set; }
    }
}
