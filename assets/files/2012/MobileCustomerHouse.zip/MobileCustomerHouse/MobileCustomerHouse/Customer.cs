﻿using System.ComponentModel;
using System.Data.Linq.Mapping;

namespace MobileCustomerHouse
{
    [Table(Name="Customer")]
    public class Customer
        :INotifyPropertyChanged,INotifyPropertyChanging
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public event PropertyChangingEventHandler PropertyChanging;

        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private void NotifyPropertyChanging(string propertyName)
        {
            if (PropertyChanging != null)
            {
                PropertyChanging(this, new PropertyChangingEventArgs(propertyName));
            }
        }

        private int _customerId;
        private string _name;
        private string _surname;
        private decimal _salary;

        [Column(IsPrimaryKey = true, IsDbGenerated = true, DbType = "INT NOT NULL Identity", CanBeNull = false, AutoSync = AutoSync.OnInsert)]
        public int CustomerId
        {
            get { return _customerId; }
            set
            {
                NotifyPropertyChanging("CustomerId");
                _customerId = value;
                NotifyPropertyChanged("CustomerId");
            }
        }

        [Column(DbType = "nvarchar(25) NOT NULL", CanBeNull = false, AutoSync = AutoSync.OnInsert,Name="CustomerName")]
        public string Name
        {
            get { return _name; }
            set
            {
                NotifyPropertyChanging("Name");
                _name = value;
                NotifyPropertyChanged("Name");
            }
        }

        [Column(DbType = "nvarchar(25) NOT NULL", CanBeNull = false, AutoSync = AutoSync.OnInsert,Name="CustomerSurname")]
        public string Surname
        {
            get { return _surname; }
            set
            {
                NotifyPropertyChanging("Surname");
                _surname = value;
                NotifyPropertyChanged("Surname");
            }
        }

        [Column(DbType = "money NOT NULL", CanBeNull = false, AutoSync = AutoSync.OnInsert,Name="CustomerSalary")]
        public decimal Salary
        {
            get { return _salary; }
            set
            {
                NotifyPropertyChanging("Salary");
                _salary = value;
                NotifyPropertyChanged("Salary");
            }
        }
    }
}
