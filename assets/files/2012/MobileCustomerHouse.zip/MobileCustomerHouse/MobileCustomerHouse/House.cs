﻿using System.Data.Linq;

namespace MobileCustomerHouse
{
    public class House
        :DataContext
    {
            public House(string connectionString)
                : base(connectionString)
            {
                Customers = this.GetTable<Customer>();
            }
        public Table<Customer> Customers;
    }
}
