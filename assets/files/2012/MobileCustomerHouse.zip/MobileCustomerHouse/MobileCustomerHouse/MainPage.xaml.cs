﻿using System;
using System.Linq;
using Microsoft.Phone.Controls;

namespace MobileCustomerHouse
{
    public partial class MainPage 
        : PhoneApplicationPage
    {
        House houseDb = null;

        public MainPage()
        {
            InitializeComponent();

            houseDb = new House("Data Source = 'isostore:/House.sdf'; File Mode = read write");

            if (!houseDb.DatabaseExists())
            {
                houseDb.CreateDatabase();
                
            }
        }

        private void btnInsert_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            Customer newCustomer = new Customer
            {
                 Name=txtCustomerName.Text,
                 Surname=txtSurname.Text,
                 Salary=Convert.ToDecimal(txtCustomerSalary.Text)
            };

            houseDb.Customers.InsertOnSubmit(newCustomer);
            houseDb.SubmitChanges();

            lstCustomers.ItemsSource = houseDb.Customers.ToList();

            
        }
    }
}