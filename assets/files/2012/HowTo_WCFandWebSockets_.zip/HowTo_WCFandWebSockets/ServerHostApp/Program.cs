﻿using StockServiceLibrary;
using System;
using System.ServiceModel;

namespace ServerHostApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(StockTransactionService));
            host.AddServiceEndpoint(
                typeof(IStockTransactionService)
                , new NetHttpBinding()
                , "ws://localhost/StockTransactionService"
                );
            host.Open();
            Console.WriteLine("Host durumu {0}. Kapatmak için bir tuşa basınız.",host.State);
            Console.ReadLine();
            host.Close();
            Console.WriteLine("Host durumu {0}.", host.State);
        }
    }
}
