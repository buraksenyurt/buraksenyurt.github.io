﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;

namespace StockServiceLibrary
{
    public class StockTransactionService 
        : IStockTransactionService
    {
        static string[] productCodes = { "PRD1001", "PRD45", "PRD2451", "PRD2501", "PRD2301", "PRD2001", "PRD1190", "PRD1007", "PRD1006", "PRD1004", "PRD1023" };

        public async Task StartSendingTransactions()
        {
            var callback = OperationContext.Current.GetCallbackChannel<IStockTransactionCallback>();
            var random = new Random();
            double price = 29.00;

            while (((IChannel)callback).State == CommunicationState.Opened)
            {
                await callback.SendTransaction(
                    new StockTransaction{ 
                        ProductCode=productCodes[random.Next(0,productCodes.Length)], 
                        TransactionQuantity=random.Next(50,5000)
                    });
                price += random.NextDouble();
                await Task.Delay(1000);
            }
        }
    }
}
