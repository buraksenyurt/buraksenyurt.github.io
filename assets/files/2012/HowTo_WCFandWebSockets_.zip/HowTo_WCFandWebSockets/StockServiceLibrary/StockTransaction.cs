﻿
using System.Runtime.Serialization;

namespace StockServiceLibrary
{
    [DataContract]
    public class StockTransaction
    {
        [DataMember]
        public string ProductCode { get; set; }
        [DataMember]
        public int TransactionQuantity { get; set; }
    }
}
