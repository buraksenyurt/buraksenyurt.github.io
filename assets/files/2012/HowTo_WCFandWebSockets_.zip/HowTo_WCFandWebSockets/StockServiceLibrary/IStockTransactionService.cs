﻿using System.ServiceModel;
using System.Threading.Tasks;

namespace StockServiceLibrary
{
    [ServiceContract(CallbackContract = typeof(IStockTransactionCallback))]
    public interface IStockTransactionService
    {
        [OperationContract(IsOneWay = true)]
        Task StartSendingTransactions();
    }

    [ServiceContract()]
    public interface IStockTransactionCallback
    {
        [OperationContract(IsOneWay = true)]
        Task SendTransaction(StockTransaction transaction);
    }
}
