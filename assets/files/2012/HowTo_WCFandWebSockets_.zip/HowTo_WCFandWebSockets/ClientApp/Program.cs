﻿using StockServiceLibrary;
using System;
using System.ServiceModel;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("İşlemlere başlamak için bir tuşa basınız.");
            Console.ReadLine();

            var context = new InstanceContext(new CallbackHandler());
            var client = new StockTransactionServiceClient(context);
            client.StartSendingTransactions();

            Console.WriteLine("Çıkmak için bir tuşa basınız.");
            Console.ReadLine();
        }
    }

    class CallbackHandler 
        : IStockTransactionServiceCallback
    {
        public void SendTransaction(StockTransaction transaction)
        {
            Console.WriteLine("{0} {1}",transaction.ProductCode,transaction.TransactionQuantity.ToString());
        }
    }
}
