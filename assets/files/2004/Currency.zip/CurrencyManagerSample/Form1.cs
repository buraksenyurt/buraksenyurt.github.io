using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace CurrencyManagerSample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label lblPersonelID;
		private System.Windows.Forms.TextBox txtPersonelAd;
		private System.Windows.Forms.TextBox txtPersonelSoyad;
		private System.Windows.Forms.TextBox txtSaatUcreti;
		private System.Windows.Forms.TextBox txtCalismaSuresi;
		private System.Windows.Forms.Button btnIlkSatiraGotur;
		private System.Windows.Forms.Button btnOncekiSatiraGotur;
		private System.Windows.Forms.Button btnSonrakiSatiraGotur;
		private System.Windows.Forms.Button btnSonSatiraGotur;
		private System.Windows.Forms.Label lblPozisyon;
		private System.Windows.Forms.Button btnYeniSatirEkler;
		private System.Windows.Forms.Button btnVeritabaninaYaz;
		private System.Windows.Forms.Button btnDegisiklikleriKaydet;
		private System.Windows.Forms.Button btnGuncelSatiriSil;
		private System.Windows.Forms.Button btnIslemIptali;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPersonelID = new System.Windows.Forms.Label();
			this.txtPersonelAd = new System.Windows.Forms.TextBox();
			this.txtPersonelSoyad = new System.Windows.Forms.TextBox();
			this.txtSaatUcreti = new System.Windows.Forms.TextBox();
			this.txtCalismaSuresi = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.btnIlkSatiraGotur = new System.Windows.Forms.Button();
			this.btnOncekiSatiraGotur = new System.Windows.Forms.Button();
			this.btnSonrakiSatiraGotur = new System.Windows.Forms.Button();
			this.btnSonSatiraGotur = new System.Windows.Forms.Button();
			this.lblPozisyon = new System.Windows.Forms.Label();
			this.btnYeniSatirEkler = new System.Windows.Forms.Button();
			this.btnVeritabaninaYaz = new System.Windows.Forms.Button();
			this.btnDegisiklikleriKaydet = new System.Windows.Forms.Button();
			this.btnGuncelSatiriSil = new System.Windows.Forms.Button();
			this.btnIslemIptali = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblPersonelID
			// 
			this.lblPersonelID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPersonelID.Location = new System.Drawing.Point(205, 8);
			this.lblPersonelID.Name = "lblPersonelID";
			this.lblPersonelID.Size = new System.Drawing.Size(48, 23);
			this.lblPersonelID.TabIndex = 0;
			this.lblPersonelID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// txtPersonelAd
			// 
			this.txtPersonelAd.Location = new System.Drawing.Point(152, 40);
			this.txtPersonelAd.Name = "txtPersonelAd";
			this.txtPersonelAd.TabIndex = 1;
			this.txtPersonelAd.Text = "";
			// 
			// txtPersonelSoyad
			// 
			this.txtPersonelSoyad.Location = new System.Drawing.Point(152, 64);
			this.txtPersonelSoyad.Name = "txtPersonelSoyad";
			this.txtPersonelSoyad.TabIndex = 2;
			this.txtPersonelSoyad.Text = "";
			// 
			// txtSaatUcreti
			// 
			this.txtSaatUcreti.Location = new System.Drawing.Point(152, 88);
			this.txtSaatUcreti.Name = "txtSaatUcreti";
			this.txtSaatUcreti.TabIndex = 3;
			this.txtSaatUcreti.Text = "";
			// 
			// txtCalismaSuresi
			// 
			this.txtCalismaSuresi.Location = new System.Drawing.Point(152, 112);
			this.txtCalismaSuresi.Name = "txtCalismaSuresi";
			this.txtCalismaSuresi.TabIndex = 4;
			this.txtCalismaSuresi.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(112, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(28, 23);
			this.label2.TabIndex = 5;
			this.label2.Text = "Ad";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(88, 64);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(52, 23);
			this.label3.TabIndex = 6;
			this.label3.Text = "Soyad";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(56, 88);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(84, 23);
			this.label4.TabIndex = 7;
			this.label4.Text = "Saat �creti";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(40, 112);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(112, 23);
			this.label5.TabIndex = 8;
			this.label5.Text = "�alisma S�resi";
			// 
			// btnIlkSatiraGotur
			// 
			this.btnIlkSatiraGotur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.btnIlkSatiraGotur.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnIlkSatiraGotur.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
			this.btnIlkSatiraGotur.Location = new System.Drawing.Point(56, 160);
			this.btnIlkSatiraGotur.Name = "btnIlkSatiraGotur";
			this.btnIlkSatiraGotur.Size = new System.Drawing.Size(48, 32);
			this.btnIlkSatiraGotur.TabIndex = 9;
			this.btnIlkSatiraGotur.Text = "|<<";
			this.btnIlkSatiraGotur.Click += new System.EventHandler(this.btnIlkSatiraGotur_Click);
			// 
			// btnOncekiSatiraGotur
			// 
			this.btnOncekiSatiraGotur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.btnOncekiSatiraGotur.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnOncekiSatiraGotur.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
			this.btnOncekiSatiraGotur.Location = new System.Drawing.Point(104, 160);
			this.btnOncekiSatiraGotur.Name = "btnOncekiSatiraGotur";
			this.btnOncekiSatiraGotur.Size = new System.Drawing.Size(48, 32);
			this.btnOncekiSatiraGotur.TabIndex = 10;
			this.btnOncekiSatiraGotur.Text = "<<";
			this.btnOncekiSatiraGotur.Click += new System.EventHandler(this.btnOncekiSatiraGotur_Click);
			// 
			// btnSonrakiSatiraGotur
			// 
			this.btnSonrakiSatiraGotur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.btnSonrakiSatiraGotur.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnSonrakiSatiraGotur.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
			this.btnSonrakiSatiraGotur.Location = new System.Drawing.Point(152, 160);
			this.btnSonrakiSatiraGotur.Name = "btnSonrakiSatiraGotur";
			this.btnSonrakiSatiraGotur.Size = new System.Drawing.Size(48, 32);
			this.btnSonrakiSatiraGotur.TabIndex = 11;
			this.btnSonrakiSatiraGotur.Text = ">>";
			this.btnSonrakiSatiraGotur.Click += new System.EventHandler(this.btnSonrakiSatiraGotur_Click);
			// 
			// btnSonSatiraGotur
			// 
			this.btnSonSatiraGotur.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.btnSonSatiraGotur.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnSonSatiraGotur.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
			this.btnSonSatiraGotur.Location = new System.Drawing.Point(200, 160);
			this.btnSonSatiraGotur.Name = "btnSonSatiraGotur";
			this.btnSonSatiraGotur.Size = new System.Drawing.Size(48, 32);
			this.btnSonSatiraGotur.TabIndex = 12;
			this.btnSonSatiraGotur.Text = ">>|";
			this.btnSonSatiraGotur.Click += new System.EventHandler(this.btnSonSatiraGotur_Click);
			// 
			// lblPozisyon
			// 
			this.lblPozisyon.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.lblPozisyon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblPozisyon.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.lblPozisyon.Location = new System.Drawing.Point(0, 295);
			this.lblPozisyon.Name = "lblPozisyon";
			this.lblPozisyon.Size = new System.Drawing.Size(304, 23);
			this.lblPozisyon.TabIndex = 13;
			// 
			// btnYeniSatirEkler
			// 
			this.btnYeniSatirEkler.BackColor = System.Drawing.Color.Gold;
			this.btnYeniSatirEkler.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnYeniSatirEkler.ForeColor = System.Drawing.Color.Black;
			this.btnYeniSatirEkler.Location = new System.Drawing.Point(56, 192);
			this.btnYeniSatirEkler.Name = "btnYeniSatirEkler";
			this.btnYeniSatirEkler.Size = new System.Drawing.Size(48, 32);
			this.btnYeniSatirEkler.TabIndex = 14;
			this.btnYeniSatirEkler.Text = "Ekle";
			this.btnYeniSatirEkler.Click += new System.EventHandler(this.btnYeniSatirEkler_Click);
			// 
			// btnVeritabaninaYaz
			// 
			this.btnVeritabaninaYaz.BackColor = System.Drawing.Color.OrangeRed;
			this.btnVeritabaninaYaz.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnVeritabaninaYaz.ForeColor = System.Drawing.Color.White;
			this.btnVeritabaninaYaz.Location = new System.Drawing.Point(56, 256);
			this.btnVeritabaninaYaz.Name = "btnVeritabaninaYaz";
			this.btnVeritabaninaYaz.Size = new System.Drawing.Size(192, 32);
			this.btnVeritabaninaYaz.TabIndex = 15;
			this.btnVeritabaninaYaz.Text = "G�ncelle";
			this.btnVeritabaninaYaz.Click += new System.EventHandler(this.btnVeritabaninaYaz_Click);
			// 
			// btnDegisiklikleriKaydet
			// 
			this.btnDegisiklikleriKaydet.BackColor = System.Drawing.Color.Gold;
			this.btnDegisiklikleriKaydet.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnDegisiklikleriKaydet.ForeColor = System.Drawing.Color.Black;
			this.btnDegisiklikleriKaydet.Location = new System.Drawing.Point(104, 192);
			this.btnDegisiklikleriKaydet.Name = "btnDegisiklikleriKaydet";
			this.btnDegisiklikleriKaydet.Size = new System.Drawing.Size(96, 32);
			this.btnDegisiklikleriKaydet.TabIndex = 16;
			this.btnDegisiklikleriKaydet.Text = "Kaydet";
			this.btnDegisiklikleriKaydet.Click += new System.EventHandler(this.btnDegisiklikleriKaydet_Click);
			// 
			// btnGuncelSatiriSil
			// 
			this.btnGuncelSatiriSil.BackColor = System.Drawing.Color.Gold;
			this.btnGuncelSatiriSil.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnGuncelSatiriSil.ForeColor = System.Drawing.Color.Black;
			this.btnGuncelSatiriSil.Location = new System.Drawing.Point(200, 192);
			this.btnGuncelSatiriSil.Name = "btnGuncelSatiriSil";
			this.btnGuncelSatiriSil.Size = new System.Drawing.Size(48, 32);
			this.btnGuncelSatiriSil.TabIndex = 17;
			this.btnGuncelSatiriSil.Text = "Sil";
			this.btnGuncelSatiriSil.Click += new System.EventHandler(this.btnGuncelSatiriSil_Click);
			// 
			// btnIslemIptali
			// 
			this.btnIslemIptali.BackColor = System.Drawing.Color.OrangeRed;
			this.btnIslemIptali.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnIslemIptali.ForeColor = System.Drawing.Color.White;
			this.btnIslemIptali.Location = new System.Drawing.Point(56, 224);
			this.btnIslemIptali.Name = "btnIslemIptali";
			this.btnIslemIptali.Size = new System.Drawing.Size(192, 32);
			this.btnIslemIptali.TabIndex = 18;
			this.btnIslemIptali.Text = "Islem Iptal";
			this.btnIslemIptali.Click += new System.EventHandler(this.btnIslemIptali_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 17);
			this.ClientSize = new System.Drawing.Size(304, 318);
			this.Controls.Add(this.btnIslemIptali);
			this.Controls.Add(this.btnGuncelSatiriSil);
			this.Controls.Add(this.btnDegisiklikleriKaydet);
			this.Controls.Add(this.btnVeritabaninaYaz);
			this.Controls.Add(this.btnYeniSatirEkler);
			this.Controls.Add(this.lblPozisyon);
			this.Controls.Add(this.btnSonSatiraGotur);
			this.Controls.Add(this.btnSonrakiSatiraGotur);
			this.Controls.Add(this.btnOncekiSatiraGotur);
			this.Controls.Add(this.btnIlkSatiraGotur);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtCalismaSuresi);
			this.Controls.Add(this.txtSaatUcreti);
			this.Controls.Add(this.txtPersonelSoyad);
			this.Controls.Add(this.txtPersonelAd);
			this.Controls.Add(this.lblPersonelID);
			this.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Personel Bilgileri";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		SqlConnection con;
		SqlDataAdapter da;
		DataTable dt;
		CurrencyManager cm;

		private void Bagla()
		{
			lblPersonelID.DataBindings.Add("Text",dt,"PersonelID");
			txtPersonelAd.DataBindings.Add("Text",dt,"PersonelAd");
			txtPersonelSoyad.DataBindings.Add("Text",dt,"PersonelSoyad");
			txtSaatUcreti.DataBindings.Add("Text",dt,"SaatUcreti");
			txtCalismaSuresi.DataBindings.Add("Text",dt,"CalismaSuresi");
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			con=new SqlConnection("data source=localhost;initial catalog=Northwind;integrated security=SSPI");
			da=new SqlDataAdapter("SELECT * FROM PERSONEL",con);
			dt=new DataTable("Personel");
			da.Fill(dt);
			Bagla();
			cm=(CurrencyManager)this.BindingContext[dt];
			lblPozisyon.Text="Guncel Pozisyon ------> "+Convert.ToString(cm.Position+1);
			cm.PositionChanged+=new EventHandler(cm_PositionChanged);
		}

		private void btnIlkSatiraGotur_Click(object sender, System.EventArgs e)
		{
			cm.Position=0;
		}

		private void btnOncekiSatiraGotur_Click(object sender, System.EventArgs e)
		{
			cm.Position--;
		}

		private void btnSonrakiSatiraGotur_Click(object sender, System.EventArgs e)
		{
			cm.Position++;
		}

		private void btnSonSatiraGotur_Click(object sender, System.EventArgs e)
		{
			cm.Position=dt.Rows.Count-1;
		}

		private void Temizle()
		{
			lblPersonelID.Text="";

			for(int i=0;i<this.Controls.Count;i++)
			{
				if(this.Controls[i] is TextBox)
				{
					this.Controls[i].Text="";
				}
			}
		}

		private void btnYeniSatirEkler_Click(object sender, System.EventArgs e)
		{
			cm.AddNew();
			Temizle();
		}

		private void btnDegisiklikleriKaydet_Click(object sender, System.EventArgs e)
		{
			if(MessageBox.Show("Degisiklikler kaydedilsin mi?","Degisiklik",MessageBoxButtons.OKCancel,MessageBoxIcon.Question)==DialogResult.OK)
			{
				cm.EndCurrentEdit();
			}
			else
			{
				cm.CancelCurrentEdit();
			}
		}		

		private void btnVeritabaninaYaz_Click(object sender, System.EventArgs e)
		{			
			SqlCommandBuilder cmb=new SqlCommandBuilder(da);
			da.Update(dt);
		}

		private void btnGuncelSatiriSil_Click(object sender, System.EventArgs e)
		{
			cm.RemoveAt(cm.Position);
		}

		private void cm_PositionChanged(object sender, EventArgs e)
		{
			lblPozisyon.Text="Guncel Pozisyon ------> "+Convert.ToString(cm.Position+1);
		}

		private void btnIslemIptali_Click(object sender, System.EventArgs e)
		{
			cm.CancelCurrentEdit();
		}
	}
}
