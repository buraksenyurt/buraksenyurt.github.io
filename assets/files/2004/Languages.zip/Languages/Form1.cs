using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.Resources;
using System.Threading;

namespace Languages
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label lblTarih;
		private System.Windows.Forms.Label lblSaat;
		private System.Windows.Forms.Label lblParasal;
		private System.Windows.Forms.Label lblDil;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblTarih = new System.Windows.Forms.Label();
			this.lblSaat = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.lblParasal = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.lblDil = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblTarih
			// 
			this.lblTarih.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTarih.Location = new System.Drawing.Point(24, 56);
			this.lblTarih.Name = "lblTarih";
			this.lblTarih.TabIndex = 0;
			this.lblTarih.Text = "Tarih";
			// 
			// lblSaat
			// 
			this.lblSaat.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblSaat.Location = new System.Drawing.Point(24, 88);
			this.lblSaat.Name = "lblSaat";
			this.lblSaat.TabIndex = 1;
			this.lblSaat.Text = "Saat";
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(320, 16);
			this.button1.Name = "button1";
			this.button1.TabIndex = 2;
			this.button1.Text = "G�ster";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(136, 56);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(256, 23);
			this.textBox1.TabIndex = 3;
			this.textBox1.Text = "";
			// 
			// textBox2
			// 
			this.textBox2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBox2.Location = new System.Drawing.Point(136, 88);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(144, 23);
			this.textBox2.TabIndex = 4;
			this.textBox2.Text = "";
			// 
			// textBox3
			// 
			this.textBox3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBox3.Location = new System.Drawing.Point(136, 120);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(144, 23);
			this.textBox3.TabIndex = 6;
			this.textBox3.Text = "";
			// 
			// lblParasal
			// 
			this.lblParasal.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblParasal.Location = new System.Drawing.Point(24, 120);
			this.lblParasal.Name = "lblParasal";
			this.lblParasal.TabIndex = 5;
			this.lblParasal.Text = "Parasal";
			// 
			// comboBox1
			// 
			this.comboBox1.BackColor = System.Drawing.Color.Gold;
			this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.comboBox1.Items.AddRange(new object[] {
														   "T�rkiye",
														   "USA",
														   "Deutschland",
														   "Fran�ais"});
			this.comboBox1.Location = new System.Drawing.Point(136, 16);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(176, 24);
			this.comboBox1.TabIndex = 7;
			// 
			// lblDil
			// 
			this.lblDil.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDil.Location = new System.Drawing.Point(24, 16);
			this.lblDil.Name = "lblDil";
			this.lblDil.TabIndex = 8;
			this.lblDil.Text = "Dil";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 181);
			this.Controls.Add(this.lblDil);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.lblParasal);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.lblSaat);
			this.Controls.Add(this.lblTarih);
			this.Name = "Form1";
			this.Text = "T�rk�e Dil";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Doldur()
		{
			this.textBox1.Text=DateTime.Today.ToLongDateString();
			this.textBox2.Text=DateTime.Now.ToLongTimeString();
			double sayi=121345.4565;
			this.textBox3.Text=sayi.ToString();
		}
		private void Form1_Load(object sender, System.EventArgs e)
		{
			Doldur();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			if(comboBox1.SelectedItem.ToString()=="USA")
			{
				Thread.CurrentThread.CurrentUICulture=new CultureInfo("en-US");
				Thread.CurrentThread.CurrentCulture=new CultureInfo("en-US");
			}
			else if(comboBox1.SelectedItem.ToString()=="T�rkiye")
			{
				Thread.CurrentThread.CurrentUICulture=new CultureInfo("tr-TR");
				Thread.CurrentThread.CurrentCulture=new CultureInfo("tr-TR");
			}	
			else if(comboBox1.SelectedItem.ToString()=="Fran�ais")
			{
				Thread.CurrentThread.CurrentUICulture=new CultureInfo("fr-FR");
				Thread.CurrentThread.CurrentCulture=new CultureInfo("fr-FR");
			}
			else if(comboBox1.SelectedItem.ToString()=="Deutschland")
			{
				Thread.CurrentThread.CurrentUICulture=new CultureInfo("de-DE");
				Thread.CurrentThread.CurrentCulture=new CultureInfo("de-DE");
			}

			ResourceManager resM=new ResourceManager("Languages.Resource1",Type.GetType("Languages.Form1").Assembly);
			this.Text=resM.GetString("T�rk�e Dil");
			this.lblDil.Text=resM.GetString("Dil");
			this.lblParasal.Text=resM.GetString("Parasal");
			this.lblSaat.Text=resM.GetString("Saat");
			this.lblTarih.Text=resM.GetString("Tarih");
			this.button1.Text=resM.GetString("G�ster");
			Doldur();
		}
	}
}
