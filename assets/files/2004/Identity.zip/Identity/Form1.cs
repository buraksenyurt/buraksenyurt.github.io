using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace IdentityBul
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnVeriCek;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox txtPersonelAd;
		private System.Windows.Forms.TextBox txtPersonelSoyad;
		private System.Windows.Forms.TextBox txtSaatUcreti;
		private System.Windows.Forms.TextBox txtCalismaSuresi;
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.Button btnEkle;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnSPileEkle;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnVeriCek = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.txtPersonelAd = new System.Windows.Forms.TextBox();
			this.txtPersonelSoyad = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtSaatUcreti = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtCalismaSuresi = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.btnEkle = new System.Windows.Forms.Button();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			this.btnSPileEkle = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
			this.SuspendLayout();
			// 
			// btnVeriCek
			// 
			this.btnVeriCek.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnVeriCek.Location = new System.Drawing.Point(16, 16);
			this.btnVeriCek.Name = "btnVeriCek";
			this.btnVeriCek.TabIndex = 0;
			this.btnVeriCek.Text = "Veri �ek";
			this.btnVeriCek.Click += new System.EventHandler(this.btnVeriCek_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(24, 48);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			this.label1.Text = "Ad";
			// 
			// txtPersonelAd
			// 
			this.txtPersonelAd.Location = new System.Drawing.Point(24, 72);
			this.txtPersonelAd.Name = "txtPersonelAd";
			this.txtPersonelAd.Size = new System.Drawing.Size(144, 23);
			this.txtPersonelAd.TabIndex = 2;
			this.txtPersonelAd.Text = "";
			// 
			// txtPersonelSoyad
			// 
			this.txtPersonelSoyad.Location = new System.Drawing.Point(24, 120);
			this.txtPersonelSoyad.Name = "txtPersonelSoyad";
			this.txtPersonelSoyad.Size = new System.Drawing.Size(144, 23);
			this.txtPersonelSoyad.TabIndex = 4;
			this.txtPersonelSoyad.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(24, 96);
			this.label2.Name = "label2";
			this.label2.TabIndex = 3;
			this.label2.Text = "Soyad";
			// 
			// txtSaatUcreti
			// 
			this.txtSaatUcreti.Location = new System.Drawing.Point(24, 176);
			this.txtSaatUcreti.Name = "txtSaatUcreti";
			this.txtSaatUcreti.Size = new System.Drawing.Size(144, 23);
			this.txtSaatUcreti.TabIndex = 6;
			this.txtSaatUcreti.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(24, 152);
			this.label3.Name = "label3";
			this.label3.TabIndex = 5;
			this.label3.Text = "Saat �creti";
			// 
			// txtCalismaSuresi
			// 
			this.txtCalismaSuresi.Location = new System.Drawing.Point(24, 232);
			this.txtCalismaSuresi.Name = "txtCalismaSuresi";
			this.txtCalismaSuresi.Size = new System.Drawing.Size(144, 23);
			this.txtCalismaSuresi.TabIndex = 8;
			this.txtCalismaSuresi.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(24, 208);
			this.label4.Name = "label4";
			this.label4.TabIndex = 7;
			this.label4.Text = "�alisma S�resi";
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.btnSPileEkle);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.btnEkle);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.txtCalismaSuresi);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.txtPersonelAd);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.txtPersonelSoyad);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.txtSaatUcreti);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.panel1.Location = new System.Drawing.Point(344, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(208, 302);
			this.panel1.TabIndex = 9;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.Firebrick;
			this.label5.Location = new System.Drawing.Point(32, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(144, 23);
			this.label5.TabIndex = 10;
			this.label5.Text = "Yeni Personel Girisi";
			// 
			// btnEkle
			// 
			this.btnEkle.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnEkle.Location = new System.Drawing.Point(24, 264);
			this.btnEkle.Name = "btnEkle";
			this.btnEkle.TabIndex = 9;
			this.btnEkle.Text = "Ekle";
			this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
			// 
			// dataGrid1
			// 
			this.dataGrid1.DataMember = "";
			this.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGrid1.Location = new System.Drawing.Point(16, 48);
			this.dataGrid1.Name = "dataGrid1";
			this.dataGrid1.Size = new System.Drawing.Size(320, 248);
			this.dataGrid1.TabIndex = 10;
			// 
			// btnSPileEkle
			// 
			this.btnSPileEkle.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnSPileEkle.Location = new System.Drawing.Point(104, 264);
			this.btnSPileEkle.Name = "btnSPileEkle";
			this.btnSPileEkle.Size = new System.Drawing.Size(88, 23);
			this.btnSPileEkle.TabIndex = 11;
			this.btnSPileEkle.Text = "SP Ile Ekle";
			this.btnSPileEkle.Click += new System.EventHandler(this.btnSPileEkle_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 16);
			this.ClientSize = new System.Drawing.Size(552, 302);
			this.Controls.Add(this.dataGrid1);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnVeriCek);
			this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "Identity";
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		SqlConnection con;
		SqlDataAdapter da;
		DataTable dt;

		private void btnVeriCek_Click(object sender, System.EventArgs e)
		{
			con=new SqlConnection("data source=localhost;initial catalog=Northwind;integrated security=SSPI");
			da=new SqlDataAdapter("SELECT * FROM PERSONEL",con);	
			dt=new DataTable("Personel");
			da.Fill(dt);
			dataGrid1.DataSource=dt;
			da.RowUpdated+=new SqlRowUpdatedEventHandler(da_RowUpdated);
		}

		private void btnEkle_Click(object sender, System.EventArgs e)
		{			
			DataRow dr;
			dr=dt.NewRow();
			dr[1]=txtPersonelAd.Text;
			dr[2]=txtPersonelSoyad.Text;
			dr[3]=txtSaatUcreti.Text;
			dr[4]=txtCalismaSuresi.Text;
			dt.Rows.Add(dr);

			SqlCommandBuilder cmb=new SqlCommandBuilder(da);
			da.Update(dt);
		}

		private void da_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
		{
			SqlCommand cmd=new SqlCommand("SELECT @@IDENTITY",con);
			if((e.Status==UpdateStatus.Continue) && (e.StatementType==StatementType.Insert))
			{
				e.Row["PersonelID"]=cmd.ExecuteScalar();
				e.Row.AcceptChanges();
			}
		}

		private void btnSPileEkle_Click(object sender, System.EventArgs e)
		{
			SqlCommand cmd=new SqlCommand("dbo.PersonelEkle",con);
			cmd.CommandType=CommandType.StoredProcedure;
			
			cmd.Parameters.Add("@PersonelID",SqlDbType.Int);
			cmd.Parameters.Add("@PersonelAd",SqlDbType.VarChar,50);			
			cmd.Parameters.Add("@PersonelSoyad",SqlDbType.VarChar,50);
			cmd.Parameters.Add("@SaatUcreti",SqlDbType.Decimal);			
			cmd.Parameters.Add("@CalismaSuresi",SqlDbType.Decimal);

			cmd.Parameters["@PersonelID"].Direction=ParameterDirection.Output;

			cmd.Parameters["@PersonelAd"].Value=txtPersonelAd.Text.ToString();
			cmd.Parameters["@PersonelSoyad"].Value=txtPersonelSoyad.Text.ToString();
			cmd.Parameters["@SaatUcreti"].Value=Convert.ToDecimal(txtSaatUcreti.Text);
			cmd.Parameters["@CalismaSuresi"].Value=Convert.ToDecimal(txtCalismaSuresi.Text);

			con.Open();
			cmd.ExecuteNonQuery();

			DataRow dr;
			dr=dt.NewRow();
			dr[0]=cmd.Parameters["@PersonelID"].Value;
			dr[1]=txtPersonelAd.Text;
			dr[2]=txtPersonelSoyad.Text;
			dr[3]=txtSaatUcreti.Text;
			dr[4]=txtCalismaSuresi.Text;
			dt.Rows.Add(dr);
			dt.AcceptChanges();
		}
	}
}
