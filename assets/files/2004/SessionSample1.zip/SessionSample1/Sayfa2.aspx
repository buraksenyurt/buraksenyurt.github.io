<%@ Page language="c#" Codebehind="Sayfa2.aspx.cs" AutoEventWireup="false" Inherits="SessionSample1.Sayfa2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Sayfa2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<asp:Label id="lblAdSoyad" style="Z-INDEX: 101; LEFT: 56px; POSITION: absolute; TOP: 56px"
				runat="server"></asp:Label>
			<asp:HyperLink id="hlDefault" style="Z-INDEX: 108; LEFT: 56px; POSITION: absolute; TOP: 144px"
				runat="server" NavigateUrl="default.aspx">default</asp:HyperLink>
			<asp:HyperLink id="hpSayfa2" style="Z-INDEX: 106; LEFT: 160px; POSITION: absolute; TOP: 144px"
				runat="server" NavigateUrl="Sayfa2.aspx">Sayfa2</asp:HyperLink>
			<asp:HyperLink id="hpSayfa3" style="Z-INDEX: 107; LEFT: 264px; POSITION: absolute; TOP: 144px"
				runat="server" NavigateUrl="Sayfa3.aspx">Sayfa3</asp:HyperLink>&nbsp;
		</form>
	</body>
</HTML>
