using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SessionSample1
{
	/// <summary>
	/// Summary description for Sayfa2.
	/// </summary>
	public class Sayfa2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.HyperLink hpSayfa3;
		protected System.Web.UI.WebControls.HyperLink hpSayfa2;
		protected System.Web.UI.WebControls.HyperLink hlDefault;
		protected System.Web.UI.WebControls.Label lblAdSoyad;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			lblAdSoyad.Text=Session["Kimlik"].ToString();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
