using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;

namespace SessionSample1 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{

		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{
			/*Uygulama seviyesinde bir degisken kullanmak istedigimizden Application nesnesini kullandik. Eger ilk kez oturum a�iliyor ise varsayilan degeri 1 olarak ayarliyoruz. Ilk kez a�ilmiyorsa var olan degeri 1 arttiriyoruz.*/
			if(Application["ToplamZiyaretci"]==null)
				Application["ToplamZiyaretci"]=1;
			else
			{
				int deger=(int)Application["ToplamZiyaretci"];
				deger+=1;
				Application["ToplamZiyaretci"]=deger;
			}
		}

		protected void Session_End(Object sender, EventArgs e)
		{
			/* Oturum kapatildiginda devereye giren bu olayda, uygulama seviyesindeki Application nesnesinde saklanan degeri 1- azaltiyoruz. B�ylece online ziyaret�i sayisini 1 azaltmis oluyoruz.*/
			int deger=(int)Application["ToplamZiyaretci"];
			deger-=1;
			Application["ToplamZiyaretci"]=deger;
		}
		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_Error(Object sender, EventArgs e)
		{

		}

		

		protected void Application_End(Object sender, EventArgs e)
		{

		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

