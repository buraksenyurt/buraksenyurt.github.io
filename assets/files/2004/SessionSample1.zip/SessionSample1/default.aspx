<%@ Page language="c#" Codebehind="default.aspx.cs" AutoEventWireup="false" Inherits="SessionSample1.WebForm1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
  <HEAD>
    <title>WebForm1</title>
    <meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
    <meta name="CODE_LANGUAGE" Content="C#">
    <meta name=vs_defaultClientScript content="JavaScript">
    <meta name=vs_targetSchema content="http://schemas.microsoft.com/intellisense/ie5">
  </HEAD>
  <body MS_POSITIONING="GridLayout">
	
    <form id="Form1" method="post" runat="server">
<asp:Label id=Label1 style="Z-INDEX: 101; LEFT: 56px; POSITION: absolute; TOP: 48px" runat="server">ASP.NET_SessionId</asp:Label>
<asp:Label id=lblAdSoyad style="Z-INDEX: 109; LEFT: 64px; POSITION: absolute; TOP: 192px" runat="server"></asp:Label>
<asp:Label id=lblSessionId style="Z-INDEX: 102; LEFT: 200px; POSITION: absolute; TOP: 48px" runat="server" ForeColor="#C00000" Font-Bold="True" Font-Size="14pt"></asp:Label>
<asp:TextBox id=txtBilgi style="Z-INDEX: 103; LEFT: 152px; POSITION: absolute; TOP: 88px" runat="server"></asp:TextBox>
<asp:Label id=Label2 style="Z-INDEX: 104; LEFT: 56px; POSITION: absolute; TOP: 88px" runat="server">Ad Soyad</asp:Label>
<asp:HyperLink id=hlDefault style="Z-INDEX: 105; LEFT: 64px; POSITION: absolute; TOP: 144px" runat="server" NavigateUrl="default.aspx">default</asp:HyperLink>
<asp:HyperLink id=hpSayfa2 style="Z-INDEX: 106; LEFT: 160px; POSITION: absolute; TOP: 144px" runat="server" NavigateUrl="Sayfa2.aspx">Sayfa2</asp:HyperLink>
<asp:HyperLink id=hpSayfa3 style="Z-INDEX: 107; LEFT: 264px; POSITION: absolute; TOP: 144px" runat="server" NavigateUrl="Sayfa3.aspx">Sayfa3</asp:HyperLink>
<asp:Button id=btnEkle style="Z-INDEX: 108; LEFT: 320px; POSITION: absolute; TOP: 88px" runat="server" Text="Session'a Ekle" Width="96px"></asp:Button>
<asp:Label id=Label3 style="Z-INDEX: 110; LEFT: 56px; POSITION: absolute; TOP: 16px" runat="server">Ziyaret�i Sayisi</asp:Label>
<asp:Label id=lblZS style="Z-INDEX: 111; LEFT: 168px; POSITION: absolute; TOP: 16px" runat="server">Label</asp:Label>

    </form>
	
  </body>
</HTML>
