<%@ Application Codebehind="Global.asax.cs" Inherits="SessionSample1.Global" %>
