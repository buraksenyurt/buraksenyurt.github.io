using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading;

namespace UzakNesne
{
	public class Musteriler:System.MarshalByRefObject
	{
		public double Alan(double yaricap)
		{
			Thread.Sleep(1500);
			return (yaricap*3.14)/2;
		}

		public string MusteriBul(string CustID)
		{
			SqlConnection con=new SqlConnection("data source=localhost;initial catalog=Northwind;integrated security=SSPI");
			SqlCommand cmd=new SqlCommand("SELECT * FROM Customers WHERE CustomerID='"+CustID+"'",con);
			con.Open();
			SqlDataReader dr=cmd.ExecuteReader();
			dr.Read();
			string Bulunan=dr["CompanyName"]+" "+dr["ContactName"]+" "+dr["Phone"];
			con.Close();
			return Bulunan;				
		}
	}
}