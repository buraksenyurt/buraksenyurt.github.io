using System;
using System.Runtime.Remoting;

namespace Sunucu
{
	public class SunucuDinler
	{
		public static void Main(string[] args)
		{
			RemotingConfiguration.Configure("Sunucu.config");
			Console.WriteLine("Dinlemeye baslandi...�ikmak i�in bir tusa basin");
			Console.ReadLine();			
		}
	}
}