using System;
using System.Threading;

namespace istemciUygulama
{
	public class Sinif
	{
		public double Hesapla(double a,double b)
		{
			Thread.Sleep(3500);
			return(a*a+b*b);
		}
	}

	public class istemci
	{
		private delegate double Temsilci(double d1,double d2);

		public static void Main(string[] args)
		{
			Sinif nesne=new Sinif();
			Temsilci t=new Temsilci(nesne.Hesapla);			
			IAsyncResult res=t.BeginInvoke(4,5,null,null);
			Console.WriteLine("Uygulama �alisiyor...");			
			res.AsyncWaitHandle.WaitOne();
			if(res.IsCompleted)
			{
				double sonuc=t.EndInvoke(res);
				Console.WriteLine(sonuc);
			}
			Console.ReadLine();
		}		
	}
}