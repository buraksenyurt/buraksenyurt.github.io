using System;
using System.Runtime.Remoting;

namespace istemciUygulama
{
	public class istemci
	{
		private delegate double Temsilci(double d);

		public static void Main(string[] args)
		{
			RemotingConfiguration.Configure("istemci.config");
			UzakNesne.Musteriler m=new UzakNesne.Musteriler();
			Temsilci t=new Temsilci(m.Alan);
			IAsyncResult res=t.BeginInvoke(3,null,null);			
			for(int i=1;i<=500;i++)
			{
				Console.Write(i.ToString()+" ");
			}
			Console.WriteLine("----");
			double alani=t.EndInvoke(res);
			Console.WriteLine(alani);		
			Console.WriteLine("Metodlarin Isleyisi Bitti");
			Console.ReadLine();
		}		
	}
}

#region Asenkron erisim hali
/*public class istemci
{
	private delegate double Temsilci(double d);

	public static void Main(string[] args)
	{
		RemotingConfiguration.Configure("istemci.config");
		UzakNesne.Musteriler m=new UzakNesne.Musteriler();
		string sonuc=m.MusteriBul("ALFKI");
		Console.WriteLine(sonuc);
			
		Temsilci t=new Temsilci(m.Alan);
		IAsyncResult res=t.BeginInvoke(3,null,null);
			
		for(int i=1;i<=500;i++)
		{
			Console.Write(i.ToString()+" ");
		}

		Console.WriteLine("----");
		res.AsyncWaitHandle.WaitOne();
		if(res.IsCompleted)
		{
			double alani=t.EndInvoke(res);
			Console.WriteLine(alani);
		}			
		Console.WriteLine("Metodlarin Isleyisi Bitti");
		Console.ReadLine();
	}		
}*/
#endregion

#region MusteriBul Metodunun �agirimi
/*
string sonuc=m.MusteriBul("ALFKI");
Console.WriteLine(sonuc);
*/
#endregion

#region Normal �agirim
/*public class istemci
{
	public static void Main(string[] args)
	{
		RemotingConfiguration.Configure("istemci.config");
		UzakNesne.Musteriler m=new UzakNesne.Musteriler();
		double alani=m.Alan(3);
		for(int i=1;i<=200;i++)
		{
			Console.Write(i.ToString()+" ");
		}
		Console.WriteLine("----");
		Console.WriteLine(alani);
		Console.WriteLine("Metodlarin Isleyisi Bitti");
		Console.ReadLine();
	}		
}*/
#endregion
