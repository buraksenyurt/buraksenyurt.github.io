﻿using System;
using System.Collections.Generic;

namespace EnumAndZeroConstant
{
    class Program
    {
        static void Main(string[] args)
        {
            //Information infoZero=new Information(0);
            Information infoZero1 = new Information((int)0);
            var zeroVar = 0;
            Information infoZero2=new Information(zeroVar);
            object zeroObj = 0;
            Information infoZero3 = new Information(zeroObj);
            int zeroInt = Convert.ToInt32("0");
            Information infoZero4 = new Information(zeroInt);
            double zeroDbl = 0.0;
            Information infoZero5 = new Information(zeroDbl);
            Information infoZero6 = new Information(0.0);
            var infoZero7 = new Information(0);

            List<Information> infos = new List<Information>()
                                          {
                                              //new Information("Hata mesajı"),
                                              //new Information(InformationType.Application),
                                              //                new Information(InformationType.Member),
                                              //                new Information(InformationType.System),
                                                              infoZero1,
                                                              infoZero2,
                                                              infoZero3,
                                                              infoZero4,
                                                              infoZero5,
                                                              infoZero6,
                                                              infoZero7
                                                              //new Information(1),
                                                              //new Information(2),
                                                              //new Information(3)
                                          };

            foreach (Information info in infos)
            {
                Console.WriteLine(info.SummaryMessage);
            }

        }
    }

    enum InformationType
    {
        System,
        Application,
        Member
    }

    class Information
    {
        public string SummaryMessage { get; private set; }

        public Information(int info)
        {
            SummaryMessage = info.ToString();
        }
        public Information(double info)
        {
            SummaryMessage = info.ToString();
        }
        public Information(object commonInformation)
        {
            SummaryMessage = commonInformation.ToString();
        }

        public Information(InformationType informationType)
        {
            switch (informationType)
            {
                case InformationType.Application:
                    SummaryMessage = "Uygulama bilgisi";
                    break;
                case InformationType.System:
                    SummaryMessage = "Sistem bilgisi";
                    break;
                case InformationType.Member:
                    SummaryMessage = "Üyeden";
                    break;
                default:
                    SummaryMessage = "Bilinmeyen kaynak";
                    break;
            }
        }
    }
}
