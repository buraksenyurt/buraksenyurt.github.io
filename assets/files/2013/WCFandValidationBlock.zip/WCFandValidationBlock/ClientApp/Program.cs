﻿using ClientApp.Company;
using Microsoft.Practices.EnterpriseLibrary.Validation.Integration.WCF;
using System;
using System.ServiceModel;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            PlayerServiceClient proxy = new PlayerServiceClient("PlayerServiceHttpEndpoint");

            try
            {
                Player newPlayer = proxy.AddPlayer(
                    nickname: "kısa"
                    , password: "şifre"
                    , country: null
                    , email: "deneme"
                    , score: -10
                    , notes: "kısa not"
                    );

                //Player newPlayer = proxy.AddPlayer(
                //        nickname: "burkicik"
                //        , password: "şifre"
                //        , country: "Birleşik Krallık"
                //        , email: "selim@buraksenyurt.com"
                //        , score: 128
                //        , notes: "oyuna yeni katılmış bir oyuncudur ve ilk seferinde turnayı gözünde vurmuştur"
                //        );

            }
            catch (FaultException<ValidationFault> excp)
            {
                foreach (ValidationDetail validationDetail in excp.Detail.Details)
                {
                    Console.WriteLine("{0} : {1}\n", validationDetail.Tag, validationDetail.Message);
                }
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
            }
            finally
            {
                if (proxy.State == CommunicationState.Opened)
                    proxy.Close();
            }
        }
    }
}
