﻿using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Integration.WCF;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;
using System.ServiceModel;

namespace MyCompanyServiceApp
{
    [ServiceContract]
    public interface IPlayerService
    {
        [OperationContract]
        [FaultContract(typeof(ValidationFault))]
        Player AddPlayer(

            [ValidatorComposition(CompositionType.And)]
            [StringLengthValidator(5, 10, MessageTemplate = "Nickname en az 5 en fazla 10 karakter olabilir")]            
            [NotNullValidator()]
            string nickname,

            string password,
            
            [ValidatorComposition(CompositionType.And)]
            [StringLengthValidator(3, 30, MessageTemplate = "Ülke bilgisi en az 3 en fazla 30 karakter olabilir")]
            [NotNullValidator()]
            string country,

            [RegexValidator(@"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$")]
            string email,

            [RangeValidator(0, RangeBoundaryType.Inclusive, 1000, RangeBoundaryType.Inclusive, MessageTemplate = "Score bilgisi 0 ile 1000 arasında olabilir")]                
            int score,  

            [StringLengthValidator(
                10
                , 100
                , MessageTemplate = "Notlar en az 10 en fazla 100 karakter uzunluğunda olabilir"
                , ErrorMessageResourceName="Notes"
                ,ErrorMessageResourceType=typeof(string)
                )]
            string notes
            );
    }
}
