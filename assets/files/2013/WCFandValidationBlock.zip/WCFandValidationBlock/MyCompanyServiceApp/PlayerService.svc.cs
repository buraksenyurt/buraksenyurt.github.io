﻿using System;

namespace MyCompanyServiceApp
{
    public class PlayerService 
        : IPlayerService
    {
        public Player AddPlayer(
            string nickname,
            string country,
            string password,
            string email,
            int score,            
            string notes)
        {
            Random rnd = new Random();
            return new Player
            {
                PlayerId=rnd.Next(1,100),
                Nickname=nickname,
                Password=password,
                EMail = email,
                Score=score,
                Country=country
            };
        }
    }
}
