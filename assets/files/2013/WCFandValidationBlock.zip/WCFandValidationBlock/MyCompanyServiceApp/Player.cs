﻿using System.Runtime.Serialization;

namespace MyCompanyServiceApp
{
    [DataContract]
    public class Player
    {
        [DataMember]        
        public int PlayerId { get; set; }
        
        [DataMember]                
        public string Nickname { get; set; }

        [DataMember]
        public string Password { get; set; }

        [DataMember]        
        public string Country { get; set; }
        
        [DataMember]
        public string EMail{ get; set; }

        [DataMember]        
        public int Score{ get; set; }
    }
}
