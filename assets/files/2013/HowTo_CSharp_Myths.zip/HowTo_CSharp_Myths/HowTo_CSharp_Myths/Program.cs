﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace HowTo_CSharp_Myths
{
    class Program
    {
        #region Case 3 : static alanların sırası önemli midir?

        //static double r1 = Math.PI;
        //static double r2 = r1;

        //// Sırayı değiştirdik
        //static double r2 = r1;
        //static double r1 = Math.PI;

        //// static olmasalardı aşağıdaki sıralama için derleme zamanı hatası alırdık.
        //double r2 = r1;
        //double r1 = Math.PI;

        #endregion

        static void Main(string[] args)
        {
            #region Case 1 Test (Private Fields)

            //Vehicle v1 = new Vehicle();
            //Vehicle v2 = new Vehicle();
            //Console.WriteLine(v1.IsEqual(v2));

            #endregion

            #region Case 2 Test (Enum Extensions)

            //VehicleType vType = VehicleType.Artillary;
            //Console.WriteLine(vType.GetDescription());
            //vType = VehicleType.HeavyAnrtillary;
            //Console.WriteLine(vType.GetDescription());

            #endregion
            
            #region Case 3 Test (static Field order)

            //Console.WriteLine(r2.ToString()); 

            #endregion

            #region Case 4 (Indeksleyicilerde params kullanımı)

            //Company company = new Company();

            //company[0] = new Person { PersonId = 1, Nickname = "Şimşir mek cin" };
            //company[1] = new Person { PersonId = 3, Nickname = "Sir Axelroad" };
            //company[2] = new Person { PersonId = 4, Nickname = "Raul Şarul" };
            //company[3] = new Person { PersonId = 2, Nickname = "William" };
            //company[4] = new Person { PersonId = 6, Nickname = "Meytır" };


            //var subSet = company[1, 3, 4]; // params kullanılan indeksleyici çağırılır
            //foreach (var person in subSet)
            //{
            //    Console.WriteLine(person.ToString());
            //}

            //var singlePerson = company[6]; // params kullanılmayan indeksleyici çağırılır
            //Console.WriteLine(singlePerson.ToString());

            #endregion

            #region Case 5 - String.Intern ve String.IsInterned ile havuzdan getirmek

            //string name1 = "burak"; // name1 Intern Pool içerisinde set edildi
            //string name2 = String.Intern("burak");

            //if(name1==name2)
            //    Console.WriteLine(true);
            //else
            //    Console.WriteLine(false);

            //string name3 = String.Intern("burak s.");
            //if(name2==name3)
            //    Console.WriteLine(true);
            //else
            //    Console.WriteLine(false);

            //string name4 = new string(new char[]{'s', 'e', 'l', 'i', 'm'});
            //Console.WriteLine("selim pool {0}",String.IsInterned(name4)==null?"da değil":"da");
            //String.Intern(name4);
            //Console.WriteLine("Intern çağrısı sonrası. selim pool {0}", String.IsInterned(name4) == null ? "da değil" : "da");

            #endregion
        }
    }

    #region Case 1 : Private sınıf üyelerine başka bir sınıf örneğinden erişilebilinir mi?

    class Vehicle
    {
        // private üyeleri hep şöyle bilirdik. Tanımlandıkları sınıf dışından kimse erişemez. Aslında doğru ama şöyle de denebilir; private tanımlanmış bir üyeye sadece tanımlandığı sınıfa ait örnekler(Instance) erişebilir.
        private Guid _vehicleId; 

        public Vehicle()
        {
            _vehicleId = Guid.NewGuid();
        }

        public bool IsEqual(Vehicle vehicle)
        {
            return _vehicleId == vehicle._vehicleId;
        }
    }

    #endregion

    #region Case 2 : Enum sabitleri de extension metodlara sahip olabilir

    enum VehicleType
    {
        Tank,
        MLRS,
        Artillary,
        Hummvy,
        HeavyAnrtillary,
        Destroyer,
        Carrier
    }

    // Pek çoğumuzun aklına bir Enum sabitini genişletmek gelmez. Ama bu mümkündür.
    static class EnumExtensions
    {
        public static string GetDescription(this VehicleType vType)
        {
            string result = String.Empty;

            switch (vType)
            {
                case VehicleType.Tank:
                    result= "Paletli zırhlı tank. 135mm top";
                    break;
                case VehicleType.MLRS:
                    result = "Kundağı motorlu çoklu roket atar sistemi";
                    break;
                case VehicleType.Artillary:
                    result = "75mm - 205mm arası hafif topçu";
                    break;
                case VehicleType.Hummvy:
                    result = "Hummer jeep";
                    break;
                case VehicleType.HeavyAnrtillary:
                    result = "205mm üstü ağır kara topçusu";
                    break;
                case VehicleType.Destroyer:
                    result = "Güneş sınıfı yeni nesil zırhlı destroyer";
                    break;
                case VehicleType.Carrier:
                    result = "Nimitz sınıfı nükleer Uçak gemisi";
                    break;
            }

            return result;
        }
    }

    #endregion

    #region Case 4 : Indeksleyiciler de params kullanımı

    class Company
    {
        private List<Person> _workers = new List<Person>(8);

        public Person this[int id]
        {
            get { 
                return 
                    _workers
                    .Where(p=>p.PersonId==id)
                    .FirstOrDefault(); 
            }
            set { 
                _workers.Add(value); 
            }
        }

        public IQueryable<Person> this[params int[] workerIds]
        {
            get
            {
                return workerIds
                    .Select(id => _workers.Where(p=>p.PersonId==id).FirstOrDefault())
                    .AsQueryable();
            }
        }
    }

    class Person
    {
        public int PersonId { get; set; }
        public string Nickname { get; set; }

        public override string ToString()
        {
            return string.Format("[{0}]-{1}", PersonId.ToString(), Nickname);
        }
    }

    #endregion
}
