﻿using Microsoft.Office.Tools.Word;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;

namespace HowTo_TFSandWord
{
    public partial class ThisDocument
    {
        #region Global değişkenler

        Uri tfsAddress = new Uri("http://tfsserver:8080/tfs/defaultcollection");
        TfsTeamProjectCollection collection = null;
        WorkItemStore store = null;
        Project argeProject = null;
        WorkItemType witBacklogItem = null;
        WorkItemType witTask = null;
        WorkItemLinkTypeEnd linkTypeEnd = null;

        #endregion Global değişkenler

        private void InitializeTFSComponents()
        {
            collection = new TfsTeamProjectCollection(tfsAddress);
            store = collection.GetService<WorkItemStore>();
            argeProject = store.Projects["ARGE"];
            witBacklogItem = argeProject.WorkItemTypes["Product Backlog Item"];
            witTask = argeProject.WorkItemTypes["Task"];
            linkTypeEnd = store.WorkItemLinkTypes.LinkTypeEnds["Parent"];
        }

        void ThisDocument_BeforeSave(object sender, SaveEventArgs e)
        {
            #region Yeni Bir Product Backlog Item Oluşturmak

            int createdBacklogItemId=CreateBacklogItem(
                textBacklogTitle.Text
                ,textBacklogDescription.Text);
            CreateTask(
                createdBacklogItemId
                , textTask1Title.Text
                , textTask1Description.Text);
            CreateTask(
                createdBacklogItemId
                , textTask2Title.Text
                , textTask2Description.Text);

            #endregion Yeni Bir Product Backlog Item Oluşturmak
        }

        private int CreateBacklogItem(string title,string description)
        {
            WorkItem newBacklogItem = new WorkItem(witBacklogItem);
            newBacklogItem.Title = title;
            newBacklogItem.Description = description;
            newBacklogItem.Save();
            return newBacklogItem.Id;
        }

        private void CreateTask(int createdBacklogItemId,string title,string description)
        {   
            WorkItem newTask = new WorkItem(witTask);
            newTask.Title = title;
            newTask.Description = description;            
            newTask.WorkItemLinks.Add(new WorkItemLink(linkTypeEnd, createdBacklogItemId));
            newTask.Save();
        }

        #region VSTO Designer generated code
        
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisDocument_Startup);
            this.Shutdown += new System.EventHandler(ThisDocument_Shutdown);
            this.BeforeSave += ThisDocument_BeforeSave;
            InitializeTFSComponents();
        }

        #endregion

        private void ThisDocument_Startup(object sender, System.EventArgs e)
        {

        }

        private void ThisDocument_Shutdown(object sender, System.EventArgs e)
        {
        }
    }
}
