﻿using NorthwindLibrary;
using System.Linq;

namespace HowTo_ExcelWithEF
{
    public partial class Sheet1
    {
        private void Sheet1_Startup(object sender, System.EventArgs e)
        {
            using(NorthwindEntities context=new NorthwindEntities())
            {
                var categoryBasedSales = from s in context.Category_Sales_for_1997
                            orderby s.CategorySales descending
                            select new { 
                                s.CategoryName, s.CategorySales 
                            };

                int rowIndex = 1;
                
                Cells[rowIndex, 1] = "Kategori";
                Cells[rowIndex, 2]= "Satışlar";

                Cells[rowIndex, 1].Font.Bold = true;
                Cells[rowIndex, 2].Font.Bold = true;

                foreach (var sale in categoryBasedSales)
                {
                    rowIndex++;
                    Cells[rowIndex, 1]= sale.CategoryName;
                    Cells[rowIndex, 2]= sale.CategorySales;
                }
            }
        }

        private void Sheet1_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(Sheet1_Startup);
            this.Shutdown += new System.EventHandler(Sheet1_Shutdown);
        }

        #endregion

    }
}
