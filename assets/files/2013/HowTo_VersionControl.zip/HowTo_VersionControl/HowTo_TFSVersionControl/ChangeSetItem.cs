﻿using Microsoft.TeamFoundation.VersionControl.Client;

namespace HowTo_TFSVersionControl
{
    public class ChangeSetItem
    {
        public ItemType ItemType { get; set; }
        public string ServerItem { get; set; }
        public int ItemId { get; set; }
        public int ChangeSetId { get; set; }

        public override string ToString()
        {
            return string.Format("[{0}]-[{1}]-{2}"
                , ChangeSetId.ToString()
                , ItemId.ToString()
                , ServerItem);
        }
    }
}
