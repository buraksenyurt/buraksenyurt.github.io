﻿using System;

namespace HowTo_TFSVersionControl
{
    public class TeamCollection
    {
        public string DisplayName { get; set; }
        public Guid Id { get; set; }

        public override string ToString()
        {
            return string.Format("[{0}]-{1}", Id.ToString(), DisplayName);
        }
    }
}
