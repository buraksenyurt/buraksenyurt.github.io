﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Framework.Client;
using Microsoft.TeamFoundation.Framework.Common;
using Microsoft.TeamFoundation.VersionControl.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Windows.Forms;

namespace HowTo_TFSVersionControl
{
    public partial class Form1 
        : Form
    {
        #region Common Fields

        TfsTeamProjectCollection tfs = null;
        VersionControlServer vcServer = null;
        ItemSet itemSet = null;
        List<ChangeSetItem> csitems = null;
        IReadOnlyCollection<CatalogNode> teamCollectionNodes = null;
        TfsTeamProjectCollection selectedCollection = null;

        #endregion Common Fields        

        public Form1()
        {
            InitializeComponent();

            cmbFileTypes.Items.Add("cs|C# Files");
            cmbFileTypes.Items.Add("vb|Visual Basic Files");
            cmbFileTypes.Items.Add("xaml|XAML Files");
            
            txtTFSAddress.Text = ConfigurationManager.AppSettings["TfsAddress"];
            FillTeamCollections();
        }

        private void FillTeamCollections()
        {
            tfs = new TfsTeamProjectCollection(new Uri(txtTFSAddress.Text));

            teamCollectionNodes=tfs.ConfigurationServer.CatalogNode.QueryChildren(
                new[] {CatalogResourceTypes.ProjectCollection }, 
                false, 
                CatalogQueryOptions.None);

            foreach (var teamCollectionNode in teamCollectionNodes)
            {
                TeamCollection teamCollection = new TeamCollection();
                teamCollection.DisplayName= teamCollectionNode.Resource.DisplayName;
                teamCollection.Id = Guid.Parse(teamCollectionNode.Resource.Properties["InstanceId"]);

                cmbTeamCollections.Items.Add(teamCollection);                
            }
        }

        private void lstItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangeSetItem selectedChangeSetItem=lstItems.SelectedItem as ChangeSetItem;
            Item item=vcServer.GetItem(selectedChangeSetItem.ItemId, selectedChangeSetItem.ChangeSetId);

            using(Stream stream = item.DownloadFile())
            {
                using(StreamReader reader = new StreamReader(stream))
                {
                    txtItemContent.Text=reader.ReadToEnd();
                }
            }
        }

        private void cmbTeamCollections_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbTeamProjects.Items.Clear();
            lstItems.Items.Clear();
            TeamCollection selectedTeamCollection=cmbTeamCollections.SelectedItem as TeamCollection;
            selectedCollection=tfs.ConfigurationServer.GetTeamProjectCollection(selectedTeamCollection.Id);
            var teamProjectNodes=selectedCollection.CatalogNode.QueryChildren(
                new[] { CatalogResourceTypes.TeamProject },
                false, CatalogQueryOptions.None);
            
            foreach (var teamProjectNode in teamProjectNodes)
            {
                cmbTeamProjects.Items.Add(teamProjectNode.Resource.DisplayName);
            }           
        }

        private void cmbTeamProjects_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstItems.Items.Clear();
            txtItemContent.Clear();

            vcServer=selectedCollection.GetService<VersionControlServer>();
            string itemPath = string.Format("$/{0}/*.{1}"
                , cmbTeamProjects.SelectedItem
                ,cmbFileTypes.SelectedItem.ToString().Split('|')[0]);
            itemSet = vcServer.GetItems(itemPath, RecursionType.Full);
            csitems = new List<ChangeSetItem>();

            foreach (Item item in itemSet.Items)
            {
                ChangeSetItem csi = new ChangeSetItem();

                csi.ItemId = item.ItemId;
                csi.ChangeSetId = item.ChangesetId;
                csi.ItemType = item.ItemType;
                csi.ServerItem = item.ServerItem;

                lstItems.Items.Add(csi);
            }

            lblStatus.Text = itemSet.Items.Length.ToString();
        }
    }
}
