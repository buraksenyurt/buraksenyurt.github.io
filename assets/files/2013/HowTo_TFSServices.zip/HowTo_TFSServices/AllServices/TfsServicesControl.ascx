﻿<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="TfsServicesControl.ascx.cs" Inherits="AllServices.TfsServicesControl" %>
<div runat="server" id="divLinks">

</div>
