﻿using System.Collections.Generic;
using System.IO;
using System.Web.UI.WebControls;

namespace AllServices
{
    public static class Utility
    {
        public static List<HyperLink> GetServiceLinks(string textFilePath)
        {
            List<HyperLink> links = new List<HyperLink>();

            string[] lines = File.ReadAllLines(textFilePath);
            foreach (string line in lines)
            {
                if (line.StartsWith("http://"))
                {
                    HyperLink link = new HyperLink
                    {
                        Text = line.Substring(line.LastIndexOf("tfs")),
                        NavigateUrl = line
                    };
                    links.Add(link);
                }                
            }

            return links;
        }
    }
}