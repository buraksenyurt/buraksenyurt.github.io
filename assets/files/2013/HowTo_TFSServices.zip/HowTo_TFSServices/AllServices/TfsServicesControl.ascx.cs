﻿using System;
using System.Web.UI.WebControls;

namespace AllServices
{
    public partial class TfsServicesControl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var serviceLinks=Utility.GetServiceLinks(Server.MapPath("~/Services.txt"));
            foreach (var serviceLink in serviceLinks)
            {
                divLinks.Controls.Add(serviceLink);
                divLinks.Controls.Add(new Literal { Text = "<br/><br/>" });
            }
        }
    }
}