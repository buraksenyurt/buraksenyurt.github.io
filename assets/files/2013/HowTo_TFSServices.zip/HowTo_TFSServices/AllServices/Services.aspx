﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Services.aspx.cs" Inherits="AllServices.Services" %>

<%@ Register Src="~/TfsServicesControl.ascx" TagPrefix="uc1" TagName="TfsServicesControl" %>


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
     <table style="font-size:x-small">
         <tr>
             <td>
                 TFS Services
             </td>
         </tr>
         <tr>
             <td>
                 <uc1:TfsServicesControl runat="server" ID="TfsServicesControl" />
             </td>
         </tr>
     </table>
    </form>
</body>
</html>
