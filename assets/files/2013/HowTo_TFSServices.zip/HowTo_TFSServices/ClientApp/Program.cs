﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Server;
using System;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            TfsTeamProjectCollection collection = TfsTeamProjectCollectionFactory
                .GetTeamProjectCollection(new Uri("http://dc2vmtfstweb01:8080/tfs/defaultcollection"));

            #region Bazı servislerin çekilmesi

            ICommonStructureService4 commonStructureService = (ICommonStructureService4)collection
                .GetService(typeof(ICommonStructureService4));

            IProcessTemplates processTemplateService = (IProcessTemplates)collection.GetService<IProcessTemplates>();

            #endregion Bazı servislerin çekilmesi

            #region Bir Team Project adı üzerinden temel proje bilgisinin çekilmesi

            ProjectInfo argeInfo = commonStructureService.GetProjectFromName("ARGE");
            Console.WriteLine("Proje\t\t\t{0}\nDurumu\t\t\t{1}\nTemplate Id\t\t{2}"
                , argeInfo.Name
                , argeInfo.Status
                , argeInfo.Uri.ToString()
                );

            string name;
            string state;
            int templateId;
            ProjectProperty[] projectProperties;

            // Tüm Proje özelliklerinin çekilmesi
            commonStructureService.GetProjectProperties(
                argeInfo.Uri.ToString()
                , out name
                , out state
                , out templateId
                , out projectProperties);
            Console.WriteLine("\nProje Özellikleri\n");
            foreach (var projectProperty in projectProperties)
                Console.WriteLine("Proje Özelliği\t\t{0}\nDeğeri\t\t\t{1}", projectProperty.Name, projectProperty.Value);

            #endregion Bir Team Project adı üzerinden temel proje bilgisinin çekilmesi

            #region Sunucuda yüklü Process Template' lerin bilgilerinin elde edilmesi

            Console.WriteLine("\nProcess Templates\n");
            TemplateHeader[] templateHeaders = processTemplateService.TemplateHeaders();
            foreach (TemplateHeader templateHeader in templateHeaders)
            {
                Console.WriteLine("Template Id\t{0}\nAdı\t\t{1}\nRank\t\t{2}\nDurumu\t\t{3}\nMetadata\t{4}\nAçıklama\t{5}\n",
                    templateHeader.TemplateId,
                    templateHeader.Name,
                    templateHeader.Rank,
                    templateHeader.State,
                    templateHeader.Metadata,
                    templateHeader.Description
                    );
            }

            #endregion Sunucuda yüklü Process Template' lerin bilgilerinin elde edilmesi           
        }
    }
}

