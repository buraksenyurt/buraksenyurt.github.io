﻿using Db4objects.Db4o;
using Db4objects.Db4o.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace HelloDb4o
{
    class Program
    {
        static string fileName = ConfigurationManager.AppSettings["db4oFileName"];

        static void Main(string[] args)
        {
            //AddSomeObjects();

            //ReadSomeObjects();

            //UpdateSomeObject();
            
            DeleteSomeObjects();
            ReadSomeObjects();

            
        }

        private static void DeleteSomeObjects()
        {
            using (IObjectContainer container = Db4oEmbedded.OpenFile(fileName))
            {
                Product product = (from Product p in container.AsQueryable<Product>()
                                   where p.ProductId == 100
                                   select p).FirstOrDefault();
                if (product != null)
                    container.Delete(product);
            }
        }

        private static void ReadSomeObjects()
        {
            using (IObjectContainer container = Db4oEmbedded.OpenFile(fileName))
            {
                #region Bir nesne örneği yardımıyla sorgulamak

                // Özellikleri varsayılan değerlere atanmış bir nesne örneği QBE tekniğine göre sorgulama için kullanılabilir
                Product refProd = new Product();
                // QueryByExample metodu IObjectSet tarafından taşınabilir bir içerik döndürmektedir.
                // Ancak içerik object tipinden döndüğünden, iterasyon sırasında ilerlenirken nesne örneğinin belirgin özelliklerine erişilemez.
                IObjectSet resultSet = container.QueryByExample(refProd);
                foreach (var r in resultSet)
                    Console.WriteLine(r.ToString());

                #endregion

                #region Bir nesnenin tipinden yararlanarak sorgulamak

                Console.WriteLine("\nTüm kategoriler\n");

                // Query<T> metoduna parametre olarak bir nesne tipi verilerek, Storage içerisinde o tipe ait nesne örneklerinin sorgulanması sağlanabilir
                // Üstelik Query metodu geriye IList<T> döneceğinden, sonuç kümesinde gezinirken T tipinin özelliklerine erişebilmek te mümkündür.
                IList<Category> categories = container.Query<Category>(typeof(Category));
                foreach (var r in categories)
                    Console.WriteLine(r.Title);

                #endregion Bir nesnenin tipinden yararlanarak sorgulamak

                #region Nesnenin bir özelliğinin belirgin bir değerine göre sorgulamak
                Console.WriteLine("\nKategorisi 2 olan ürünler\n");

                // Böyle bir durumda QBE tekniği kullanılacaksa bir nesne örneği oluşturulmalı ve ilgili kritere konu olan özelliğin/özelliklerin değerleri atanmalıdır
                resultSet = container.QueryByExample(new Product { CategoryId = 2 });
                foreach (var r in resultSet)
                    Console.WriteLine(r.ToString());

                #endregion Nesnenin bir özelliğinin belirgin bir değerine göre sorgulamak

                #region LINQ sorgusu kullanmak

                Console.WriteLine("\nStok değeri 12 birim ve altında olan ürünler\n");
                // Dikkat edilmesi gereken noktalardan birisi de Db4Objects.Db4o.Linq assembly' ının referans edilmesi gerekliliğidir.
                // Diğer yandan using kımsında System.Linq satırının da kaldırılmaması gerekir.
                var products = from Product p in container.AsQueryable<Product>()    
                               where p.StockSize<=12
                               select p;
                foreach (var product in products)
                    Console.WriteLine(product.ToString());

                #endregion LINQ sorgusu kullanmak
            }
        }

        private static void AddSomeObjects()
        {
            // Pek çok NoSQL sisteminde olduğu gibi, bir context nesnesine ihtiyaç vardır.
            // OpenFile metodu eğer dosya yoksa üretecek var ise sadece açacaktır
            // container nesne örneğinin içeriği IObjectContainer arayüzü(interface) tarafından taşınabilmektedir
            using (IObjectContainer container = Db4oEmbedded.OpenFile(fileName))
            {
                // bir kaç nesne örneği ilave edelim.
                Product mouse = new Product
                {
                    ProductId = 100,
                    Title = "Optik fare",
                    CategoryId = 1,
                    ListPrice = 40,
                    StockSize = 12
                };
                container.Store(mouse); // Store metodu object tipi ile çalışmaktadır. Dolayısıyla herhangibir nesneyi ilave edebiliriz.

                container.Store(new Product
                {
                    ProductId = 101,
                    Title = "Optik Klavye",
                    CategoryId = 1,
                    ListPrice = 34,
                    StockSize = 16
                }
                );

                container.Store(new Product
                {
                    ProductId = 102,
                    Title = "LCD Monitor 22inch",
                    CategoryId = 2,
                    ListPrice = 155,
                    StockSize = 24
                }
                );

                container.Store(new Category
                {
                     CategoryId=1,
                     Title="Çevre üniteleri"
                }
                );

                container.Store(new Category
                {
                    CategoryId = 2,
                    Title = "Monitorler"
                }
                );

                //container.Commit(); // Ekleme işlemlerinin onaylanması için Commit metoduna başvurulur. Transaction kullanılan durumlar için ele alınabilir.
            }
        }

        private static void UpdateSomeObject()
        {
            using (IObjectContainer container = Db4oEmbedded.OpenFile(fileName))
            {
                #region tüm ürünlerin fiyatlarını %10 arttıralım

                // Güncelleme işlemi için öncelikle güncellenecek nesne örneği/ örnekleri bulunmalıdır
                var products = from Product p in container.AsQueryable<Product>()
                               select p;
                foreach (var product in products)
                {
                    product.ListPrice *= 1.10M;
                    // Değişiklik sonrası güncellemenin depolama alanına da yansıması için yine Store metodundan yararlanılabilir
                    container.Store(product);
                }

                #endregion tüm ürünlerin fiyatlarını %10 arttıralım
            }
        }
    }

    class Product
    {
        public int ProductId { get; set; }
        public string Title { get; set; }
        public decimal ListPrice { get; set; }
        public int CategoryId { get; set; }
        public int StockSize { get; set; }

        public override string ToString()
        {
            return string.Format("[{0}]-{1} {2} {3} {4}", ProductId, Title, ListPrice, StockSize, CategoryId);
        }
    }

    class Category
    {
        public int CategoryId { get; set; }
        public string Title { get; set; }

        public override string ToString()
        {
            return string.Format("[{0}]-{1}", CategoryId, Title);
        }
    }
}
