﻿using System.ComponentModel.DataAnnotations.Schema;

namespace HowTo_CalculatedFields
{
    public class Product
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductId { get; set; }
        public string Name { get; set; }
        public int ListPrice { get; set; }
        public int Quantity { get; set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public int TotalPrice
        {
            get
            {
                return ListPrice * Quantity;
            }
            private set // get bloğunu açtığımız için aşağıdaki bloğu boş olsa bile açmak mecburiyetindeyiz.
            {
            }
        }
    }
}
