namespace HowTo_CalculatedFields.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddTotalPriceCalculatedFields : DbMigration
    {
        public override void Up()
        {
            DropTable("dbo.Products");

            CreateTable(
                "dbo.Products",
                c => new
                {
                    ProductId = c.Int(nullable: false, identity: true),
                    Name = c.String(maxLength:50),
                    ListPrice = c.Int(nullable: false),
                    Quantity = c.Int(nullable: false)
                })
                .PrimaryKey(t => t.ProductId);

            Sql("ALTER TABLE dbo.Products ADD [TotalPrice] as ([ListPrice] * [Quantity])");
        }

        public override void Down()
        {
            DropTable("dbo.Products");
        }
    }
}
