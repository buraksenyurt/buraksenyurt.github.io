﻿using System;
using System.Linq;

namespace HowTo_CalculatedFields
{
    class Program
    {
        static void Main(string[] args)
        {
            using (Shop context = new Shop())
            {
                Product hpKeyboard = new Product
                {
                     Name="HP 102 Tuş Kablosuz Klavye",
                     ListPrice=35,
                     Quantity=125
                };

                context.Products.Add(hpKeyboard);
                context.SaveChanges();

                var finded = (from k in context.Products 
                              where k.Name == "HP 102 Tuş Kablosuz Klavye" 
                              select k)
                    .FirstOrDefault();
                
                Console.WriteLine(finded.TotalPrice);
                
                finded.Quantity += 10;

                Console.WriteLine(finded.TotalPrice);                
            }
        }
    }
}
