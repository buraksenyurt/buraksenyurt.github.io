﻿using System.Data.Entity;

namespace HowTo_CalculatedFields
{
    public class Shop
        :DbContext
    {
        public DbSet<Product> Products{ get; set; }
    }
}
