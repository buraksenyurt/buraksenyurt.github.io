﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace FindLineCountsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Satır sayısı hesap edilecek olan dosya adresi alınır
            string file = Path.Combine(Environment.CurrentDirectory, "Content.txt");

            // Hesaplama işlemlerini üstlenen tipimiz
            FileProcessor prcsr=new FileProcessor(file);

            // Reflection' dan yararlanarak, FileProcessor tipi içerisinde LineTest niteliği ile işaretlenmiş ne kadar metod varsa çağırıyor ve her birinin hesaplama sürelerini buluyoruz.
            Type t = prcsr.GetType();
            foreach (var method in t.GetMethods())
            {
                if (method.GetCustomAttributes(false).Length == 1)
                {
                    var lAttr = (method.GetCustomAttributes(false)[0]) as LineTestAttribute;
                    if (lAttr != null)
                    {
                        // Kronometremizi her metod çağrısı içerisinde oluşturuyoruz
                        Stopwatch watcher = new Stopwatch();
                        watcher.Start(); // Kronometre start
                        var result = method.Invoke(prcsr, BindingFlags.InvokeMethod, null, null, null);
                            // Metod çağırılıyor
                        watcher.Stop(); // Kronometre stop
                        Console.WriteLine("Method {0}\tLineCount {1}\tDuration {2} milisaniye", method.Name,
                                          result.ToString(), watcher.ElapsedMilliseconds.ToString());
                    }
                }
            }
        }
    }

    class FileProcessor
    {
        private string _fileName;

        public FileProcessor(string fileName)
        {
            _fileName = fileName;
        }

        // Hesaplama metodlarımızdan birisi File tipinin ReadAllLines metodunu kullanarak dönen dizinin uzunluğuna bakar
        [LineTest]
        public int Compute1()
        {
            int lineCount = 0;

            lineCount=File.ReadAllLines(_fileName).Length;

            return lineCount;
        }
        // Dosya baştan sona okunurken Alt Satıra geçme karakteri araştırılır '\n' bu -1 olmadığı sürece yani dosya sonuna gelinmediği sürece satır sayısı ve pozisyon arttırılarak devam edilir.
        //[LineTest]
        public int Compute2()
        {
            int lineCount = 0;
            int position = 0;
            while ((position = File.ReadAllText(_fileName).IndexOf('\n', position)) != -1)
            {
                lineCount++;
                position++;
            }
            return lineCount+1;
        }

        // RegEx ifadesinden yararlanılarak \n' lerin sayısı hesaplanır.
        [LineTest]
        public int Compute3()
        {
            int lineCount = 0;

            Regex regEx = new Regex("\n", RegexOptions.Multiline);
            MatchCollection matchCollection = regEx.Matches(File.ReadAllText(_fileName));
            lineCount=matchCollection.Count;

            return lineCount+1;
        }

        // Bu sefer \n karakterlerinin tespiti için Linq sorgusundan yararlanılmaktadır.
        [LineTest]
        public int Compute4()
        {
            int lineCount = 0;

            lineCount=(from ch in File.ReadAllText(_fileName)
             where ch == '\n'
             select ch).Count();


            return lineCount+1;
        }

        // Bu kez dosya içeriği bir char dizisine atanır ve tüm dizide dönülerek \n' lerin toplam sayısı bulunur
        [LineTest]
        public int Compute5()
        {
            int lineCount = 0;
            string text = File.ReadAllText(_fileName);
            int posMax = text.Length;
            char[] a = text.ToCharArray();

            for (int position = 0; position < posMax; )
                if (a[position++] == '\n')
                    lineCount++;
            
            return lineCount+1;
        }

        // Bu seferki metodumuzda dosyanın uzunluğundan, dosya içerisinde new line karakterlerinin kaldırılması sonucu oluşan içeriğin uzunluğunu çıkartarak hesaplama yaptırıyoruz
        [LineTest]
        public int Compute6()
        {
            int lineCount = 0;

            string text = File.ReadAllText(_fileName);
            lineCount=text.Length - text.Replace("\n", "").Length;

            return lineCount+1;
        }

        // Count Extension Method' unun kullanılması ve new line' ların sayılarının bulunarak satır sayısının hesap edilmesi işlemini üstlenir
        [LineTest]
        public int Compute7()
        {
            int lineCount = 0;

            lineCount=File.ReadAllText(_fileName).Count(c => (c == '\n'));

            return lineCount+1;
        }

        // Bu sefer dosyanın her bir karekteri foreach döngüsü ile dolaşılıyor ve new line karakterlerinin sayısı hesap ediliyor
        [LineTest]
        public int Compute8()
        {
            int lineCount = 0;

            foreach (char c in File.ReadAllText(_fileName))
                if (c == '\n')
                    lineCount++;

            return lineCount+1;
        }
    }

    // Satır sayısını hesaplama ile ilişkili test metodlarımızı belirtmek amacıyla basit bir attribute tanımlıyoruz
    [AttributeUsage(AttributeTargets.Method)]
    class LineTestAttribute
        :Attribute
    {
        
    }
}
