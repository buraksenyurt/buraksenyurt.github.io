﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HowTo_EasyRouting
{
    public partial class Kategori 
        : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                using (NorthwindEntities context = new NorthwindEntities())
                {
                    var categories = from c in context.Categories
                                     orderby c.CategoryName
                                     select new
                                     {
                                         c.CategoryID,
                                         c.CategoryName
                                     };

                    foreach (var category in categories)
                    {
                        HyperLink categoryLink = new HyperLink();
                        categoryLink.NavigateUrl = GetRouteUrl("KategoriBazliUrunler", new { CategoryName = category.CategoryName });
                        categoryLink.Text = string.Format("[{0}]-{1}<br/>", category.CategoryID.ToString(), category.CategoryName);
                        divCategories.Controls.Add(categoryLink);
                    }
                }
            }
        }
    }
}