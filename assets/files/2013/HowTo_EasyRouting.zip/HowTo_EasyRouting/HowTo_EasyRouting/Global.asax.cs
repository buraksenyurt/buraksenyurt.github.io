﻿using System;
using System.Web;
using System.Web.Routing;

namespace HowTo_EasyRouting
{
    public class Global 
        : HttpApplication
    {
        private void SetRouteMaps()
        {
            RouteTable.Routes.MapPageRoute("Varsayilan", "", "~/kategori.aspx");
            RouteTable.Routes.MapPageRoute("Kategoriler", "kategoriler", "~/kategori.aspx");
            RouteTable.Routes.MapPageRoute("KategoriBazliUrunler","urunler/{CategoryName}","~/urun.aspx");
            RouteTable.Routes.MapPageRoute("SehirBazliSiraliMusteriler", "musteriler/{City}$orderby={FieldName}", "~/musteri.aspx");
            RouteTable.Routes.MapPageRoute("SehirBazliSiparisler", "siparisler/{ShipCity}", "~/siparis.aspx");
        }

        protected void Application_Start(object sender, EventArgs e)
        {
            SetRouteMaps();
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}