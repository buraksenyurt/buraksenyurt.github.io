﻿using System;
using System.Linq;
using System.Web.UI;

namespace HowTo_EasyRouting
{
    public partial class Urun 
        : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (RouteData.Values["CategoryName"] != null)
            {
                string categoryName = RouteData.Values["CategoryName"].ToString();
                using (NorthwindEntities context = new NorthwindEntities())
                {
                    var products = from p in context.Products.Include("Product")
                                   where p.Category.CategoryName == categoryName
                                   orderby p.ProductName
                                   select new
                                   {
                                       p.ProductID,
                                       p.ProductName,
                                       p.UnitPrice
                                   };

                    grdUrunler.DataSource = products.ToList();
                    grdUrunler.DataBind();
                }
            }
            else
                Response.Redirect(GetRouteUrl("Kategoriler", null));
        }
    }
}