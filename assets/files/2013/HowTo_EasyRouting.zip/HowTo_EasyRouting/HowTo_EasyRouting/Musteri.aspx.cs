﻿using System;
using System.Linq;
using System.Reflection;
using System.Web.Routing;

namespace HowTo_EasyRouting
{
    public partial class Musteri : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(RouteData.Values["City"]!=null 
                || RouteData.Values["FieldName"]!=null)
            {
                string cityName=RouteData.Values["City"].ToString();
                string fieldName=RouteData.Values["FieldName"].ToString();
                
                using(NorthwindEntities context=new NorthwindEntities())
                {
                    var customers = context
                        .Customers
                        .Where(c => c.City == cityName)
                        .OrderBy(GetField<Customer>(fieldName))
                        .Select(c => new 
                        { 
                            ID=c.CustomerID,
                            Title=c.ContactTitle,                          
                            Contact=c.ContactName,
                            Company=c.CompanyName,
                            c.City
                        });
                        
                    grdCustomer.DataSource = customers.ToList();
                    grdCustomer.DataBind();
                }
            }
        }

        public static Func<T, string> GetField<T>(string fieldName)
        {
            PropertyInfo pInfo=typeof(T).GetProperty(fieldName);
            if (pInfo == null)
                pInfo = typeof(T).GetProperty("CustomerID");

            return o => Convert.ToString(pInfo.GetValue(o, null));         
        }
    }
}