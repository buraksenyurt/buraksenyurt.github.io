﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Urun.aspx.cs" Inherits="HowTo_EasyRouting.Urun" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
        <h1 style="color:purple"><asp:Label ID="lblCategoryName" runat="server" /></h1>
        <br />
        <asp:GridView ID="grdUrunler" runat="server" />
    </div>
    </form>
</body>
</html>
