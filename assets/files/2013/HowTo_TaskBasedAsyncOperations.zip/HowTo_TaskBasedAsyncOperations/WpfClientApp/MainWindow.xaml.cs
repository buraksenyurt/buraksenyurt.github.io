﻿using System.Windows;
using WpfClientApp.AzonReference;

namespace WpfClientApp
{
    public partial class MainWindow : Window
    {
        OptimizationServiceClient proxy = new OptimizationServiceClient();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void btnGetRoot_Click_1(object sender, RoutedEventArgs e)
        {
            lblStatus.Content = "Bilgiler çekiliyor...";
            Root[] roots = await proxy.GetBestRootAsync(
                new Location { 
                    LocationId = 1
                    , Title = "Hasanpaşa" 
                }
                );
            grdRoots.DataContext = roots;
            lblStatus.Content = "Bilgiler çekildi...";
        }
    }
}
