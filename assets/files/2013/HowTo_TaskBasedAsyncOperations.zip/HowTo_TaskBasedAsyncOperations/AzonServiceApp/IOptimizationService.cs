﻿using System.Collections.Generic;
using System.ServiceModel;

namespace AzonServiceApp
{
    [ServiceContract]
    public interface IOptimizationService
    {
        [OperationContract]
        List<Root> GetBestRoot(Location yourLocation);
    }
}
