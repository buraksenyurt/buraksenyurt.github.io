﻿using System.Runtime.Serialization;

namespace AzonServiceApp
{
    [DataContract]
    public class Location
    {
        [DataMember]
        public int LocationId { get; set; }
        [DataMember]
        public string Title { get; set; }
    }
}
