﻿using System.Runtime.Serialization;

namespace AzonServiceApp
{
    [DataContract]
    public class Root
    {
        [DataMember]
        public double Altitude { get; set; }
        [DataMember]
        public double Longitude { get; set; }
        [DataMember]
        public double Latitude { get; set; }
        [DataMember]
        public int RootId { get; set; }
        [DataMember]
        public string Title { get; set; }
    }
}
