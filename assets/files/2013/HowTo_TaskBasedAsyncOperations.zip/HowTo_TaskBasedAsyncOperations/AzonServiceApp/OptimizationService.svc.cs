﻿using System.Collections.Generic;
using System.Threading;

namespace AzonServiceApp
{
    public class OptimizationService 
        : IOptimizationService
    {
        public List<Root> GetBestRoot(Location yourLocation)
        {
            List<Root> roots=FindBestRoot(yourLocation);
            return roots;
        }

        private List<Root> FindBestRoot(Location yourLocation)
        {
            Thread.Sleep(10000);

            return new List<Root>{
                new Root{RootId=1,Latitude=34.5,Longitude=43.2,Altitude=500.50,Title="4ncü cadde batı köşesi"},
                new Root{RootId=2,Latitude=34.85,Longitude=43.2,Altitude=450,Title="moda sahil yolu"},
                new Root{RootId=3,Latitude=22.5,Longitude=43.2,Altitude=100,Title="iskele caddesi durağı"},
                new Root{RootId=4,Latitude=44.90,Longitude=12.90,Altitude=0,Title="iskelenin kendisi"}
            };
        }
    }
}
