﻿using AzonClientApp.AzonReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AzonClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            GetRootList(new Location { LocationId = 2, Title = "Hasanpaşa" });
            
        }

        static async void GetRootList(Location location)
        {
            Console.WriteLine("En iyi yol bilgisi talep edildi");
            OptimizationServiceClient proxy = new OptimizationServiceClient("BasicHttpBinding_IOptimizationService");
            var rootList = await proxy.GetBestRootAsync(location);
            Console.WriteLine(rootList.Count());
            Console.WriteLine("En iyi yol bilgisi alındı");
        }
    }
}
