﻿using Enyim.Caching;
using Enyim.Caching.Memcached;
using System;

namespace HowTo_Memcached
{
    class Program
    {
        static void Main(string[] args)
        {
            Player burki = new Player
            {
                 PlayerId=1,
                 Nickname="burki",
                 TotalScore=10
            };

            using(MemcachedClient client=new MemcachedClient()) // Default Constructor varsayılan olarak config dosyasında enyim.com/memcached sekmesini arar.
            {
                client.Store(StoreMode.Set, "burki", burki); // ikinci parametre key değeri iken son parametre value' dur(object tipindendir)                
                object value=null;
                
                if(client.TryGet("burki", out value))
                {
                    Player cachedPlayer = value as Player;
                    if(cachedPlayer!=null)
                    {
                        Console.WriteLine(cachedPlayer.ToString());
                    }
                }
            }
        }
    }

    [Serializable] // Veriyi binary modda transfer edeceğimizi belirttiğimiziden POCO' nun Binary formatta serileştirilebilir olması gerekmektedir.
    public class Player
    {
        public int PlayerId { get; set; }
        public string Nickname { get; set; }
        public int TotalScore { get; set; }

        public override string ToString()
        {
            return string.Format("[{0}]-{1} {2}"
                , PlayerId.ToString()
                , Nickname
                , TotalScore.ToString());
        }
    }
}
