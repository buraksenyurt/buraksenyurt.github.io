﻿using System;
using System.Collections.Generic;

namespace NewIOFunctions
{
    public static class GameCreator
    {
        // Test verileri için örnek bir küme
        // Savaş alanına yerleştireceğimiz aktörler
        static string[] actors = { "Archer", "Footman", "Knight", "Castle", "Rider", "Catapult" };
        // Bu aktörlerin güçlerini temsil eden değerler.
        static int[] forceValues = { 100, 200, 300, 400 };
        // Bu yerleştirilen aktörlerin hangi tipten olduğunu belirtecek taraf bilgileri(Ghost enteresan bir karakterdir. Yeri gelince Human yeri gelince Computer tarafında oluyor :)
        static string[] types = { "Human", "Computer", "Ghost" };
        static string[] mainlands = { "Mordor", "Middle Earth", "Other Side", "Wrong Side", "Red Zone", "Deadly Land", "Kolburg" };

        public static List<GameElement> CreateRandomElements(int size)
        {
            List<GameElement> elements = new List<GameElement>(size);
            Random randomizer = new Random();
            for (int i = 0; i < size-1; i++)
            {
                GameElement element = new GameElement();
                element.Id = i;
                element.Actor = actors[randomizer.Next(0, actors.Length - 1)];
                element.Force=forceValues[randomizer.Next(0, forceValues.Length - 1)];
                element.Type = types[randomizer.Next(0, types.Length - 1)];
                element.MainLand = mainlands[randomizer.Next(0, mainlands.Length - 1)];
                element.X = randomizer.Next(-90, 90);
                element.Y = randomizer.Next(-90, 90);
                elements.Add(element);
            }
            return elements;
        }
    }
}
