﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NewIOFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            //10 milyonluk bir test kümesi üretiyoruz. Bunu asenkron geliştirmediğimizden biraz zaman alacaktır.
            var gameZone = GameCreator.CreateRandomElements(10000000);
            var r=WriteTo10File(gameZone);
            Console.WriteLine("İşlemler devam ediyor...Lütfen bekleyiniz");
            r.Wait();
            Console.WriteLine("Program sonlandırılıyor");

            //var taskResult = WriteFileAsync(gameZone, Path.Combine(Environment.CurrentDirectory, "GameZone.txt"));
            //Console.WriteLine("İşlemler devam ediyor...");
            //// Dosya yazma ile ilişkili işlemlerin tamamlanması için uygulamayı bekletiyoruz.
            //taskResult.Wait();
            //Console.WriteLine("{0} adet satır yazıldığı bilgisi geldi.", taskResult.Result.ToString());

            //var readTaskResult = ReadFileLineByLineAsync(Path.Combine(Environment.CurrentDirectory, "GameZone.txt"));
            //Console.WriteLine("İşlemler devam ediyor...");
            //readTaskResult.Wait();
            //Console.WriteLine("Sonuçlar");
            //for (int i = 0; i < 10; i++)
            //{
            //    Console.WriteLine(readTaskResult.Result[i].ToString());
            //}
        }

        // async olarak işaretlenmiş metodlar ref veya out tipli parametreler içeremezler
        private static async Task<List<GameElement>> ReadFileLineByLineAsync(string file)
        {
            Console.WriteLine("Okuma işlemi başlatıldı.");
            List<GameElement> elements = new List<GameElement>();
            Stopwatch watcher = new Stopwatch();
            watcher.Start();

            using (StreamReader reader = new StreamReader(file))
            {
                
                string line;
                while (!String.IsNullOrEmpty(line = await reader.ReadLineAsync()))
                {
                    string[] columns=line.Split('|');
                    elements.Add(new GameElement
                    {
                        Id=Convert.ToInt32(columns[0]),
                        Actor=columns[1],
                        Force=Convert.ToInt32(columns[2]),
                        Type=columns[3],
                        MainLand=columns[4],
                        X=Convert.ToInt32(columns[5].Split(';')[0].TrimStart('(')),
                        Y = Convert.ToInt32(columns[5].Split(';')[1].TrimEnd(')'))
                    }
                    );
                }
            }

            watcher.Stop();
            Console.WriteLine("Okuma işlemi tamamlandı. Toplam süre {0} milisaniye.", watcher.ElapsedMilliseconds.ToString());

            return elements;
        }

        private static async Task WriteTo10File(List<GameElement> elements)
        {
            for (int i = 1; i <= 10; i++)
            {
                string fileName = Path.Combine(Environment.CurrentDirectory, "GameZone_" + i.ToString() + ".txt");
                await WriteFileAsyncV2(elements.Skip((i-1)*1000000).Take(1000000).ToList(), fileName);
            }
            Console.WriteLine("Tüm dosya yazma işlemleri tamamlandı.");
        }

        private static async Task WriteFileAsyncV2(List<GameElement> elements, string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (var element in elements)
                {
                    // Awaitable olan WriteLineAsync metodunu çağırıyor ve içeriği yazdırıyoruz.
                    await writer.WriteLineAsync(element.ToString());
                }
                Console.WriteLine("{0} için işlemler tamamlandı.",filePath);
            }
        }

        // WriteFileAsync metodundan geriye bilinçli olarak bir Task tipi döndürdük. Böylece burayı çağırdığımız Main metodu sonuna gelindiğinde ilgili Task' ın tamamlanıp tamamlanmadığını kontrol edebiliriz.
        private static async Task<int> WriteFileAsync(List<GameElement> elements, string filePath)
        {
            Console.WriteLine("Yazma işlemi başlatıldı.");

            Stopwatch watcher = new Stopwatch();
            watcher.Start();

            // StreamWriter tipini üretiyoruz ve parametre olarak veriyi yazacağımız dosya adresini belirtiyoruz
            using (StreamWriter writer = new StreamWriter(filePath))
            {                
                foreach (var element in elements)
                {
                    // Awaitable olan WriteLineAsync metodunu çağırıyor ve içeriği yazdırıyoruz.
                    await writer.WriteLineAsync(element.ToString());
                }
            }
            
            watcher.Stop();
            Console.WriteLine("Yazma işlemi tamamlandı. Toplam süre {0} milisaniye.",watcher.ElapsedMilliseconds.ToString());

            return elements.Count;
        }
    }
}

