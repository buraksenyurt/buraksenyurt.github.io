﻿using System;

namespace HowTo_AsyncModules
{
    public class RequestLogInfo
    {
        public string IpAddress { get; set; }
        public DateTime Time { get; set; }
        public bool IsAuthenticated { get; set; }
        public string User { get; set; }
        public string RequestType { get; set; }
        public Uri Url { get; set; }

        public override string ToString()
        {
            return string.Format("{0}|{1}|{2}|{3}|{4}|{5}"
                ,Time.ToLongTimeString()
                ,IpAddress
                ,IsAuthenticated.ToString()
                ,User
                ,RequestType
                ,Url.ToString()
                );
        }
    }
}
