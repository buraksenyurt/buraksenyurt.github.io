﻿using System;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;
using System.Web;

namespace HowTo_AsyncModules
{
    public class AsyncHttpLogModule
        :IHttpModule
    {
        public void Dispose()
        {
         // Do Something   
        }

        public void Init(HttpApplication context)
        {
            EventHandlerTaskAsyncHelper eventHandler =new EventHandlerTaskAsyncHelper(WriteLogToTextFile);
            context.AddOnPostAuthorizeRequestAsync(
                eventHandler.BeginEventHandler
                , eventHandler.EndEventHandler
                );
        }

        private async Task WriteLogToTextFile(object sender, EventArgs e)
        {
            var context = HttpContext.Current;
            string filePath = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["LogFileAddress"]);

            RequestLogInfo requestLog = new RequestLogInfo()
            {
                Time = DateTime.Now,
                IpAddress = context.Request["REMOTE_ADDR"],
                User = context.User.Identity.Name,
                IsAuthenticated = context.User.Identity.IsAuthenticated,
                RequestType = context.Request.RequestType,
                Url = context.Request.Url
            };
            using (StreamWriter streamWriter = File.AppendText(filePath))
            {
                await streamWriter.WriteLineAsync(requestLog.ToString());
            }
        }
    }
}