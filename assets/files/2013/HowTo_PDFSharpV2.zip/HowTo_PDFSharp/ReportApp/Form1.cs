﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace ReportApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Northwind veritabanında yer alan View isimleri ComboBox kontrolüne basıyoruz.
            cmbViews.DataSource = Utility.GetNorthwindViews();
        }

        private void btnCreatePDF_Click(object sender, EventArgs e)
        {
            // Kullanıcıdan bir PDF dosya adı istiyoruz
            if(sfdReportFile.ShowDialog()== DialogResult.OK)
            {                
                // Dosyanın var olması halinde kullanıcının tepkisini bekliyoruz. Yes düğmesine basarsa üzerine yazacak
                if(sfdReportFile.CheckFileExists==true)
                        return;

                string pdfFileName = sfdReportFile.FileName;
                // PDF oluşturma işlemini üstlenen Utility tipini çağırıyoruz.
                Utility.CreatePDFReportFile(pdfFileName, cmbViews.SelectedValue.ToString());

                // Üretilen PDF dosyasını sistemde PDF Read edebileceğimiz bir uygulama olduğunu var sayarak Process tipi yardımıyla açtırıyoruz.
                // Bu sayede üretilen raporu da görebiliriz.
                Process.Start(pdfFileName);               
            }
        }

        private void btnCreateChart_Click(object sender, EventArgs e)
        {
            if (sfdReportFile.ShowDialog() == DialogResult.OK)
            {
                if (sfdReportFile.CheckFileExists == true)
                    return;

                string pdfFileName = sfdReportFile.FileName;
                Utility.CreateChart(pdfFileName);

                Process.Start(pdfFileName);
            }
        }
    }
}
