﻿using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Shapes;
using MigraDoc.DocumentObjectModel.Shapes.Charts;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace ReportApp
{
    public static class Utility
    {
        #region Genel değişkenler

        static Document document = null;
        static Table table = null;

        #endregion Genel değişkenler

        // Hazır bir SqlConnection nesnesini bize verecek olan private fonksiyonumuz
        static SqlConnection GetConnection()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString);
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            return conn;
        }

        // Rapor almak için kullanacağımız View bilgilerini çektiğimiz fonksiyon
        public static List<string> GetNorthwindViews()
        {
            List<string> viewNames = new List<string>();

            string query = "Select name from sys.views order by name";
            using(SqlConnection conn=GetConnection())
            {
                using(SqlCommand cmd=new SqlCommand(query,conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        viewNames.Add(reader["name"].ToString());
                    }
                    reader.Close();
                }
            }

            return viewNames;
        }

        // PDF Dosyasını oluşturacak olan metodumuz
        public static bool CreatePDFReportFile(string fileName,string viewName)
        {
            bool result = false;
            document = new Document();
            DataTable dataContent=GetViewContent(viewName);

            CreateDefaultStyles();
            CreatePDFSection(viewName,fileName, dataContent);
            FillDataToContent(dataContent);
            SavePdfFile(fileName);

            result = true;

            return result;
        }

        public static bool CreateChart(string fileName)
        {
            bool result=false;

            document = new Document();
            document.DefaultPageSetup.Orientation = Orientation.Landscape;

            DataTable dataContent = GetViewContent("Total Sales By Category");
            DrawChart(dataContent);
            SavePdfFile(fileName);

            result = true;
            return result;
        }

        private static void DrawChart(DataTable dataTable)
        {
            List<double> serieValues = new List<double>();
            List<string> xAxisValues = new List<string>();

            Section section = document.AddSection();
            Chart chart = new Chart();
            chart.Left = 0;
            chart.Width = Unit.FromCentimeter(24);
            chart.Height = Unit.FromCentimeter(16);
            Series series = chart.SeriesCollection.AddSeries();
            series.ChartType = ChartType.Line;

            foreach (DataRow row in dataTable.Rows)
            {
                serieValues.Add(Convert.ToDouble(row["Total"]));
                xAxisValues.Add(row["CategoryName"].ToString());
            }
            series.Add(serieValues.ToArray());

            XSeries xSeries = chart.XValues.AddXSeries();
            xSeries.Add(xAxisValues.ToArray());
            chart.XAxis.Title.Caption = "Kategori";
            chart.XAxis.HasMajorGridlines = true;
            chart.YAxis.Title.Caption = "Toplam Satış";
            chart.YAxis.HasMajorGridlines = true;            
            chart.PlotArea.FillFormat.Color = Colors.SandyBrown;
            chart.PlotArea.LineFormat.Width = 3;

            section.Add(chart);
        }

        // İlgili View içeriğini bir DataTable nesnesi olarak geriye döndüren private metodumuz
        static DataTable GetViewContent(string viewName)
        {
            string query = string.Format("select * from [{0}]", viewName);
            DataTable table = new DataTable();
            using (SqlConnection conn = GetConnection())
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                {
                    adapter.Fill(table);
                }
            }

            return table;
        }

        // PDF içeriğinde kullanılacak olan stiller belirlenir. Bu Style tiplerini HTML içeriğindeki style kavramına benzetebiliriz.
        static void CreateDefaultStyles()
        {
            Style style = document.Styles["Normal"];
            style.Font.Name = "Calibri";
            style = document.Styles[StyleNames.Header];
            style.ParagraphFormat.AddTabStop("12cm", TabAlignment.Right);
            style = document.Styles[StyleNames.Footer];
            style.ParagraphFormat.AddTabStop("8cm", TabAlignment.Center);

            // Table isimli bir style oluşturuyoruz. Normal isimli Style' dan türemekte
            style = document.Styles.AddStyle("Table", "Normal");
            style.Font.Name = "Calibri";
            style.Font.Size = 9;

            // Normal isimli Style' ı baz alan Reference isimli bir Style oluşturuyoruz
            style = document.Styles.AddStyle("Reference", "Normal");
            style.ParagraphFormat.SpaceBefore = "3mm";
            style.ParagraphFormat.SpaceAfter = "3mm";
            style.ParagraphFormat.TabStops.AddTabStop("12cm", TabAlignment.Right);
        }

        // PDF Sayfası üretilir.
        static void CreatePDFSection(string viewName,string filePath,DataTable dataTable)
        {
            string info = string.Format("{0} raporu - Northwind Tarafından Üretilmiştir - Her Hakkı Saklıdır {1}"
                , viewName
                , DateTime.Now.Year);

            // Landscape olacak şekilde dokümanın yönünü belirliyoruz
            document.DefaultPageSetup.Orientation = Orientation.Landscape;
            // İçeriğimizi koyacağımız bir Section oluşturuyoruz
            Section section = document.AddSection();

            #region Firma Logosunun Eklenmesi

            Image image = section.AddImage(Path.Combine(Environment.CurrentDirectory, "northwind.jpg"));            
            image.Top = ShapePosition.Top;
            image.Left = ShapePosition.Left;                        

            #endregion Firma Logosunun Eklenmesi

            #region Header kısmı

            Paragraph paragraph = section.Headers.Primary.AddParagraph();
            paragraph.AddText(info);
            paragraph.Format.Font.Size = 10;
            paragraph.Format.Font.Color = Colors.LightGray;
            paragraph.Format.Alignment = ParagraphAlignment.Left;

            #endregion Header kısmı

            #region Footer kısmı

            paragraph = section.Footers.Primary.AddParagraph();
            paragraph.AddText(info);
            paragraph.Format.Font.Size = 10;
            paragraph.Format.Font.Color = Colors.LightGray;
            paragraph.Format.Alignment = ParagraphAlignment.Left;

            #endregion Footer kısmı

            #region Adres bildirimi
                        
            paragraph = section.AddParagraph();
            paragraph.Format.SpaceBefore = "3cm";
            paragraph.Style = "Reference";
            paragraph.AddFormattedText(viewName, TextFormat.Italic);
            paragraph.AddTab();
            paragraph.AddText("Rapor Tarihi, ");
            paragraph.AddDateField("dd.MM.yyyy");
            paragraph.AddLineBreak();
            paragraph.AddText("Rapor, Migra Document API ile üretilmiştir");
            paragraph.AddLineBreak();
            Hyperlink link = paragraph.AddHyperlink("http://www.buraksenyurt.com");
            link.Type = HyperlinkType.Url;
            link.Font.Underline = Underline.Single;
            link.AddText("Detaylı Bilgi burada");

            #endregion Adres bildirimi

            #region View içeriğinin basılacağı Table ve öğelerinin üretimi

            table = section.AddTable();
            table.Style = "Table";
            table.Borders.Color = Colors.LightYellow;
            table.Borders.Width = 0.25;
            table.Borders.Left.Width = 0.5;
            table.Borders.Right.Width = 0.5;
            table.Rows.LeftIndent = 0;

            Column column;
            foreach (DataColumn col in dataTable.Columns)
            {
                column = table.AddColumn(Unit.FromCentimeter(2.5));
                column.Format.Alignment = ParagraphAlignment.Center;
            }

            // Tablonun Header kısmı üretiliyor
            Row row = table.AddRow();
            row.HeadingFormat = true;
            row.Format.Alignment = ParagraphAlignment.Center;
            row.Format.Font.Bold = true;

            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                row.Cells[i].AddParagraph(dataTable.Columns[i].ColumnName);
                row.Cells[i].Format.Font.Color = Colors.White;
                row.Cells[i].Format.Shading.Color = Colors.Black;
                row.Cells[i].Format.Font.Bold = true;
                row.Cells[i].Format.Alignment = ParagraphAlignment.Left;
                row.Cells[i].VerticalAlignment = VerticalAlignment.Bottom;
            }
            table.SetEdge(0, 0, dataTable.Columns.Count, 1, Edge.Box, BorderStyle.Single, 0.75, Color.Empty);

            #endregion View içeriğinin basılacağı Table ve öğelerinin üretimi
        }

        // Sayfa içeriği parametre olarak gelen DataTable içeriğine göre doldurulur
        static void FillDataToContent(DataTable dataTable)
        {
            Row newRow;
            for (int i = 0; i < dataTable.Rows.Count; i++)
            {
                newRow = table.AddRow();
                newRow.TopPadding = 1.5;
                for (int j = 0; j < dataTable.Columns.Count; j++)
                {
                    newRow.Cells[j].Shading.Color = Colors.Gold;
                    newRow.Cells[j].VerticalAlignment = VerticalAlignment.Center;
                    newRow.Cells[j].Format.Alignment = ParagraphAlignment.Left;
                    newRow.Cells[j].Format.FirstLineIndent = 1;
                    newRow.Cells[j].AddParagraph(dataTable.Rows[i][j].ToString());
                    table.SetEdge(0, table.Rows.Count - 2, dataTable.Columns.Count, 1, Edge.Box, BorderStyle.Single, 0.75);
                }
            }
        }

        // PDF Dosyası parametre olarak belirtilen adrese kayıt edilir
        static void SavePdfFile(string fileName)
        {
            PdfDocumentRenderer pdfRenderer = new PdfDocumentRenderer(true);            
            pdfRenderer.Document = document;
            pdfRenderer.RenderDocument();
            pdfRenderer.Save(fileName);                       
        }
    }
}
