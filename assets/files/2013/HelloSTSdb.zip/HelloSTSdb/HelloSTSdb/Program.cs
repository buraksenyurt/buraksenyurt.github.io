﻿using STSdb.Data;
using System;
using System.Linq;

namespace HelloSTSdb
{
    class Program
    {
        static void Main(string[] args)
        {
            //Add();

            Read();
        }

        private static void Add()
        {
            var index1 = new XKey<byte[], string>(Guid.NewGuid().ToByteArray(), "Kadillak STS");
            var index2 = new XKey<byte[], string>(Guid.NewGuid().ToByteArray(), "Lamborjini Diyablo");
            var index3 = new XKey<byte[], string>(Guid.NewGuid().ToByteArray(), "Ferrarriim");
            var index4 = new XKey<byte[], string>(Guid.NewGuid().ToByteArray(), "Doğanım");

            #region Örnek veri kümesi oluşturulması

            using (StorageEngine sEngine = StorageEngine.FromFile("gm.stsdb"))
            {
                var table = sEngine.Scheme
                    .CreateOrOpenXTable<XKey<byte[], string>, AutoMobile>(new Locator("Automobile"));
                table.KeyMap = new XKeyMap<byte[], string>(null, 16, null, 512);

                sEngine.Scheme.Commit();

                table[index1] = new AutoMobile
                {
                    Manufacturer = "Ceneral Motor Kampani",
                    Model = "STS Turbo CRDI AK/S",
                    Price = 90000,
                    ProductionDate = "2005"
                };
                table[index2] = new AutoMobile
                {
                    Manufacturer = "İtalyan cob",
                    Model = "Diablo III",
                    Price = 250000,
                    ProductionDate = "2008"
                };
                table[index3] = new AutoMobile
                {
                    Manufacturer = "Ferrari",
                    Model = "799",
                    Price = 350000,
                    ProductionDate = "2013"
                };
                table[index4] = new AutoMobile
                {
                    Manufacturer = "Türk işi",
                    Model = "Doğan SLX/AK 8 ileri",
                    Price = 450,
                    ProductionDate = "2014"
                };

                table.Commit();
                table.Close();
            }

            #endregion
        }

        private static void Read()
        {
            #region Veri okunması

            using (StorageEngine sEngine = StorageEngine.FromFile("gm.stsdb"))
            {
                var table = sEngine.Scheme
                    .OpenXTable<XKey<byte[], string>, AutoMobile>(new Locator("Automobile"));

                foreach (var row in table.Where(r => r.Record.Price > 100000))
                {
                    Console.WriteLine("{0}\n{1}\n"
                        , row.Key.ToString()
                        , row.Record.ToString()
                        );
                }

                Console.WriteLine("\nTüm Kayıtlar\n");
                foreach (var row in table)
                {
                    Console.WriteLine("{0}-{1}\n{2}\n"
                        , (new Guid(row.Key.SubKey0)).ToString()
                        , row.Key.SubKey1
                        , row.Record.ToString()
                        );
                }

                table.Close();
            }

            #endregion Veri okunması
        }
    }

    public class AutoMobile
    {
        public string Model { get; set; }
        public string Manufacturer { get; set; }
        public string ProductionDate { get; set; }
        public decimal Price { get; set; }

        public override string ToString()
        {
            return string.Format("{0} {1}({2}) by {3}", ProductionDate, Model, Price, Manufacturer);
        }
    }
}
