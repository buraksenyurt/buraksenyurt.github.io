﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EnKisaCumle
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] words = { "Paket", "KETEN", "EngiNar", "arPA","DEMİR" };

            Creator graph = new Creator(new List<string>(words));
            Console.WriteLine(graph.CompressWords());
        }
    }

    // Yardımcı olacak genişletme metodlarımız
    public static class Extensions
    {
        // İki kelimeyi ağırlıkları mertebesinde birleştirir.
        public static string Combine(this string LeftWord, string RightWord)
        {
            int weight = FindWeight(LeftWord, RightWord);
            string result = string.Format("{0}{1}", LeftWord, RightWord.Substring(weight, RightWord.Length - weight));
            return result;
        }

        // İki kelimenin birleşme ağırlık değerini hesaplar
        public static int FindWeight(this string LeftWord, string RightWord)
        {
            int maxLength = LeftWord.Length < RightWord.Length ? LeftWord.Length : RightWord.Length;
            for (int i = 0; i <= maxLength; i++)
            {
                if (LeftWord.EndsWith(RightWord.Substring(0, maxLength - i), true, null)) // büyük küçük harf ayrımı yapmasın
                {
                    return maxLength - i;
                }
            }
            return 0;
        }

        // Belirtilen Sequence koleksionu üzerindeki her bir elemanda Action temsilcisi ile belirtilen fonksiyonelliğin çalıştırılmasını sağlar
        public static void Run<T>(this IEnumerable<T> Sequence, Action<T> Action)
        {
            foreach (var item in Sequence)
                Action(item);
        }

        // Reduce metodu içerisinde devreye girer
        public static IEnumerable<T> With<T>(this IEnumerable<T> Sequence, T Item)
        {
            foreach (var t in Sequence)
                yield return t;
            
            yield return Item;
        }

        // Bir kelime kombinasyonu içerisindeki Node ve Parent' ı arasındaki birleşimi üretir ve yeni bir Node olarak elde etmemizi sağlar
        public static Node<string, int> Combine(this Combination<string, int> Combination)
        {
            return new Node<string, int>(Combination.Parent.Value.Combine(Combination.Node.Value));
        }
    }


    // Bir kelime ve bu kelime ile diğerleri arasındaki ilişkiler ile ağırlıkları tutan temel tipimizdir
    public class Node<T, W> 
    {
        private List<Combination<T, W>> combinations = new List<Combination<T, W>>();
        Func<Node<T, W>, Node<T, W>, W> weightCalculator;

        public Func<Node<T, W>, Node<T, W>, W> WeightCalculator
        {
            get
            {
                if (weightCalculator == null)
                    weightCalculator = (n1, n2) => default(W);
                return weightCalculator;
            }
            set
            {
                weightCalculator = value;
            }
        }
        public List<Combination<T, W>> Combinations
        {
            get
            {
                return combinations;
            }
            set
            {
                combinations = new List<Combination<T, W>>(value);
            }
        }
        public T Value { get; private set; }
        public Node(T value)
        {
            Value = value;
        }

        public void Add(Node<T, W> node)
        {
            var combination = new Combination<T, W>(this, node, WeightCalculator(this, node));
            combinations.Add(combination);
        }
    }

    // Kelime kombinasyonlarını Parent ve Current Node bazında ağırlıkları ile birlikte saklar.
    public class Combination<T, W>
    {
        public Node<T, W> Parent { get; private set; }
        public Node<T, W> Node { get; private set; }
        public W Weight { get; private set; }

        public Combination(Node<T, W> Parent, Node<T, W> Node, W Weight)
        {
            this.Parent = Parent;
            this.Node = Node;
            this.Weight = Weight;
        }
    }


    // Asıl işlemleri üstlenen tipimiz. Kelimelere ait node listesine yeni örnekler eklenmesi, sıkıştırma yapılması, olası kombinasyonların azaltılması gibi fonksiyonellikleri üstlenir.
    public class Creator
    {
        List<Node<string, int>> nodes = new List<Node<string, int>>();
        Func<Node<string, int>, Node<string, int>, int> weightCalculator;

        public Creator()
        {
            weightCalculator = (node, newNode) =>
            {
                return node.Value.FindWeight(newNode.Value);
            };
        }

        public Creator(List<string> Words)
        {
            Words.Run(Add);
        }

        public List<Node<string, int>> Nodes
        {
            get
            {
                return nodes;
            }
            set
            {
                nodes = new List<Node<string, int>>(value);
            }
        }

        public void Add(string Value)
        {
            if (!nodes.Exists(n => n.Value == Value))
            {
                var newNode = new Node<string, int>(Value)
                {
                    WeightCalculator = weightCalculator
                };

                nodes.Run(node =>
                {
                    newNode.Add(node);
                    node.Add(newNode);
                });

                nodes.Add(newNode);
            }
        }

        public Creator With(string value)
        {
            Add(value);
            return this;
        }

        public Creator Reduce()
        {
            if (nodes.Count <= 1)
                return this;

            var combinations = from n in nodes
                        from e in n.Combinations
                        select e;
            var combination = combinations.First(n => n.Weight == combinations.Max(e => e.Weight));

            return new Creator(nodes.Select(n => n.Value)
                                        .Where(str => str != combination.Parent.Value && str != combination.Node.Value)
                                        .With(combination.Combine().Value).ToList());
        }

        public string CompressWords()
        {
            Creator graph = this;
            while (graph.nodes.Count > 1)
            {
                graph = graph.Reduce();
            }

            return graph.nodes[0].Value;
        }
    }
}