﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Product Document Form Wizard")]
[assembly: AssemblyDescription("Product ekleme işlemlerini kolaylaştırır Form.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Burak Senyurt")]
[assembly: AssemblyProduct("Product Document")]
[assembly: AssemblyCopyright("2013")]
[assembly: AssemblyTrademark("http://www.buraksenyurt.com")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("79acacdd-7540-441a-aa04-2b8c538fb9ec")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

