﻿// Default code generation is disabled for model 'd:\users\bsenyurt\documents\visual studio 2012\Projects\HowTo_Word\AzonEntityLibrary\DepomuzModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.