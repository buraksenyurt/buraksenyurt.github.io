﻿using com.sparsity.dex.gdb;
using System;
using System.Linq;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Veritabanı Oluşturma

            Database database = null;
            DexConfig cfg = new DexConfig();
            cfg.SetLogFile("Azon.log");
            cfg.SetCacheMaxSize(1024);
            //cfg.SetLicense("lisans numarası");
            Dex dexter = new Dex(cfg);
            database = dexter.Create("AzonGraphDb.dex", "Azon");

            #endregion

            #region oturum açılması ve Graph nesnesinin elde edilmesi

            Session session= database.NewSession();
            Graph g = session.GetGraph();

            #endregion

            #region Schema' nın Oluşturulması

            int teamType = g.NewNodeType("Takim");
            int teamIdType = g.NewAttribute(teamType, "TakimId", DataType.Long, AttributeKind.Unique);
            int teamNameType = g.NewAttribute(teamType, "Ad", DataType.String, AttributeKind.Indexed);
            int teamCountryType = g.NewAttribute(teamType, "Ulke", DataType.String, AttributeKind.Indexed);

            int staffType = g.NewNodeType("Eleman");
            int staffIdType = g.NewAttribute(staffType, "ElemanId", DataType.Long, AttributeKind.Unique);
            int staffNameType = g.NewAttribute(staffType, "Ad", DataType.String, AttributeKind.Indexed);
            int staffTitleType = g.NewAttribute(staffType, "Unvan", DataType.String, AttributeKind.Indexed);
            int staffCountryType = g.NewAttribute(staffType, "Ulke", DataType.String, AttributeKind.Indexed);

            #endregion Schema' nın Oluşturulması

            #region Edge Tanımlamaları

            // Bu senaryoda sadece Directed Edge kullanılmıştır. Normalde hem Tail hem de Head rolü üstlenen bir node söz konusu ise UnDirected Edge kullanılması gerekir.
            // Directed Edge' ler de bir Tail' den Head' e doğru giden bir ilişki ifade edilir

            int roleType = g.NewEdgeType("Rol", false, false);
            int roleTitleType = g.NewAttribute(roleType, "Title", DataType.String, AttributeKind.Basic);

            #endregion Edge Tanımlamaları

            #region Örnek Veri Eklenmesi

            Value value = new Value();

            long marcusGoree = g.NewNode(staffType);
            g.SetAttribute(marcusGoree, staffIdType, value.SetLong(1));
            g.SetAttribute(marcusGoree, staffNameType, value.SetString("Marcus Goree"));
            g.SetAttribute(marcusGoree, staffTitleType, value.SetString("Power Forward"));
            g.SetAttribute(marcusGoree, staffCountryType, value.SetString("USA"));

            long rudyGobert = g.NewNode(staffType);
            g.SetAttribute(rudyGobert, staffIdType, value.SetLong(2));
            g.SetAttribute(rudyGobert, staffNameType, value.SetString("Rudy Gobert"));
            g.SetAttribute(rudyGobert, staffTitleType, value.SetString("Power Forward"));
            g.SetAttribute(rudyGobert, staffCountryType, value.SetString("FR"));

            long gasperVidmar = g.NewNode(staffType);
            g.SetAttribute(gasperVidmar, staffIdType, value.SetLong(3));
            g.SetAttribute(gasperVidmar, staffNameType, value.SetString("Gasper Vidmar"));
            g.SetAttribute(gasperVidmar, staffTitleType, value.SetString("Center"));
            g.SetAttribute(gasperVidmar, staffCountryType, value.SetString("SL"));

            long semihErden = g.NewNode(staffType);
            g.SetAttribute(semihErden, staffIdType, value.SetLong(4));
            g.SetAttribute(semihErden, staffNameType, value.SetString("Semih Erden"));
            g.SetAttribute(semihErden, staffTitleType, value.SetString("Center"));
            g.SetAttribute(semihErden, staffCountryType, value.SetString("TR"));

            long oguzSavas = g.NewNode(staffType);
            g.SetAttribute(oguzSavas, staffIdType, value.SetLong(5));
            g.SetAttribute(oguzSavas, staffNameType, value.SetString("Oğuz Savaş"));
            g.SetAttribute(oguzSavas, staffTitleType, value.SetString("Center"));
            g.SetAttribute(oguzSavas, staffCountryType, value.SetString("TR"));

            long simonePianigiani = g.NewNode(staffType);
            g.SetAttribute(simonePianigiani, staffIdType, value.SetLong(6));
            g.SetAttribute(simonePianigiani, staffNameType, value.SetString("Simone Pianigiani"));
            g.SetAttribute(simonePianigiani, staffTitleType, value.SetString("Coach"));
            g.SetAttribute(simonePianigiani, staffCountryType, value.SetString("IT"));

            long ermanKunter = g.NewNode(staffType);
            g.SetAttribute(simonePianigiani, staffIdType, value.SetLong(7));
            g.SetAttribute(simonePianigiani, staffNameType, value.SetString("Erman Kunter"));
            g.SetAttribute(simonePianigiani, staffTitleType, value.SetString("Coach"));
            g.SetAttribute(simonePianigiani, staffCountryType, value.SetString("IT"));

            long besiktas = g.NewNode(teamType);
            g.SetAttribute(besiktas, teamIdType, value.SetLong(8));
            g.SetAttribute(besiktas, teamNameType, value.SetString("Beşiktaş"));
            g.SetAttribute(besiktas, teamCountryType, value.SetString("TR"));

            long cholet = g.NewNode(teamType);
            g.SetAttribute(cholet, teamIdType, value.SetLong(9));
            g.SetAttribute(cholet, teamNameType, value.SetString("Cholet"));
            g.SetAttribute(cholet, teamCountryType, value.SetString("FR"));

            long fenerbahceUlker = g.NewNode(teamType);
            g.SetAttribute(fenerbahceUlker, teamIdType, value.SetLong(10));
            g.SetAttribute(fenerbahceUlker, teamNameType, value.SetString("Fenerbahçe Ülker"));
            g.SetAttribute(fenerbahceUlker, teamCountryType, value.SetString("TR"));

            long montepaschiSiena = g.NewNode(teamType);
            g.SetAttribute(montepaschiSiena, teamIdType, value.SetLong(11));
            g.SetAttribute(montepaschiSiena, teamNameType, value.SetString("Montepaschi Siena"));
            g.SetAttribute(montepaschiSiena, teamCountryType, value.SetString("IT"));

            long edge;
            edge = g.NewEdge(roleType,marcusGoree,cholet);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynuyor"));

            edge = g.NewEdge(roleType, rudyGobert, cholet);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynuyor"));
            
            edge = g.NewEdge(roleType, ermanKunter, cholet);
            g.SetAttribute(edge, roleTitleType, value.SetString("Yönetti"));

            edge = g.NewEdge(roleType, ermanKunter, besiktas);
            g.SetAttribute(edge, roleTitleType, value.SetString("Yönetiyor"));

            edge = g.NewEdge(roleType, gasperVidmar, besiktas);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynuyor"));

            edge = g.NewEdge(roleType, gasperVidmar, fenerbahceUlker);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynadı"));

            edge = g.NewEdge(roleType, semihErden, besiktas);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynuyor"));

            edge = g.NewEdge(roleType, semihErden, fenerbahceUlker);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynadı"));

            edge = g.NewEdge(roleType, oguzSavas, fenerbahceUlker);
            g.SetAttribute(edge, roleTitleType, value.SetString("Oynuyor"));

            edge = g.NewEdge(roleType, simonePianigiani, fenerbahceUlker);
            g.SetAttribute(edge, roleTitleType, value.SetString("Yönetiyor"));

            edge = g.NewEdge(roleType, simonePianigiani, montepaschiSiena);
            g.SetAttribute(edge, roleTitleType, value.SetString("Yönetti"));

            #endregion Örnek Veri Eklenmesi

            #region Bir Node' un bağlantılarına bakmak

            // Erman Kunter ile ilişkili olan takımlar

            Objects trace = g.Neighbors(semihErden, roleType, EdgesDirection.Outgoing);
            
            ObjectsIterator iterator = trace.Iterator();

            Value nameValue = new Value();
            Value countryValue = new Value();
            Console.WriteLine("Semih Erden bağlantıları\n");

            while (iterator.HasNext())
            {
                long objectId = iterator.Next();
                g.GetAttribute(objectId, teamNameType, nameValue);
                g.GetAttribute(objectId, teamCountryType, countryValue);

                Console.WriteLine("Takım {0}, Ülke {1}",
                    nameValue.GetString(),
                    countryValue.GetString());
            }

            #endregion

            #region Edge değeri okumak

            Value roleTitleValue = new Value();

            Console.WriteLine("\nÇeşitli Edge değerleri\n");

            long edgeId=g.FindEdge(roleType, semihErden, besiktas);            
            g.GetAttribute(edgeId, roleTitleType, roleTitleValue);
            Console.WriteLine("Semih Erden - ({0}) -> Beşiktaş",roleTitleValue );

            edgeId = g.FindEdge(roleType, simonePianigiani, montepaschiSiena);
            g.GetAttribute(edgeId, roleTitleType, roleTitleValue);
            Console.WriteLine("Simone Pianigiani - ({0}) -> Montepaschi Siena", roleTitleValue);

            edgeId = g.FindEdge(roleType, oguzSavas, fenerbahceUlker);
            g.GetAttribute(edgeId, roleTitleType, roleTitleValue);
            Console.WriteLine("Oguz Savas - ({0}) -> Fenerbahçe Ülker", roleTitleValue);

            #endregion Edge değeri okumak           

            iterator.Close();
            trace.Close();
            session.Close();            
            database.Close();

        }
    }
}
