﻿
namespace CustomerServiceV1
{
    public class CustomerService 
        : ICustomerService
    {
        public string GetCustomer(string customerNumber)
        {
            return "Müşteri numarası ile müşteri bilgisi talep edildi";
        }
    }
}
