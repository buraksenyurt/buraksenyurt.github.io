﻿using System.ServiceModel;

namespace CustomerServiceV1
{
    [ServiceContract]
    public interface ICustomerService
    {
        [OperationContract]
        string GetCustomer(string customerNumber);
    }
}
