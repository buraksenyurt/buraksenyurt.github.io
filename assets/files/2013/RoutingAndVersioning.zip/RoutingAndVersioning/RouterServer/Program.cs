﻿using System;
using System.ServiceModel;
using System.ServiceModel.Routing;

namespace RouterServer
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceHost serviceHost =new ServiceHost(typeof(RoutingService)))
            {
                serviceHost.Open();
                Console.WriteLine("Yönlendirme servisi etkin. Kapatmak için bir tuşa basınız.");
                Console.ReadLine();
            }
        }
    }
}
