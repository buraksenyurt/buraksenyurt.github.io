﻿using ClientApp.CustomerServiceReference;
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace ClientApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Çalıştırmak istediğiniz servise ait versiyon numarasını giriniz. 1, 2");
            string versionNumber=Console.ReadLine();

            try
            {
                //Routing servis için bir Endpoint bildirimi yapılır
                EndpointAddress ea = new EndpointAddress("http://localhost:62323/routingservice/router/customer");

                // Proxy nesnesi örneklenir
                CustomerServiceClient client = new CustomerServiceClient(new BasicHttpBinding(), ea);

                // Scope örneklenir
                using (OperationContextScope context = new OperationContextScope((client.InnerChannel)))
                {
                    //Header bilgisi alınır
                    MessageHeaders header = OperationContext.Current.OutgoingMessageHeaders;
                    //Header bilgisine kullanılmak istenen versiyon numarası verilir
                    header.Add(MessageHeader.CreateHeader("SrvVersion", "http://core.services.customer/", versionNumber));
                    // Operasyon çalıştırılır
                    string result1 = client.GetCustomer("1122");

                    Console.WriteLine(result1);
                    Console.ReadLine();
                }
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
            }
        }
    }
}
