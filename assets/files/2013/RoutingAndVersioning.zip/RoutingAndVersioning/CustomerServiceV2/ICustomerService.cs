﻿using System.ServiceModel;

namespace CustomerServiceV2
{
    [ServiceContract]
    public interface ICustomerService
    {
        [OperationContract]
        string GetCustomer(string tckn);
    }
}
