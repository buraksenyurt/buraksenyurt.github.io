﻿
namespace CustomerServiceV2
{
    public class CustomerService 
        : ICustomerService
    {
        public string GetCustomer(string tckn)
        {
            return "TCKN ile müşteri bilgisi çekilir";
        }
    }
}
