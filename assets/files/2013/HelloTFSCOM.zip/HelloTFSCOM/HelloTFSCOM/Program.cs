﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Framework.Client;
using Microsoft.TeamFoundation.Framework.Common;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System;
using System.Configuration;
using System.Net;

namespace HelloTFSCOM
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Team Collection -> Team Projects Listelerinin Okunması

            Uri tfsAddress = new Uri(ConfigurationManager.AppSettings["TfsAddress"]);

            TfsConfigurationServer tfsServer =
                TfsConfigurationServerFactory.GetConfigurationServer(tfsAddress);
            NetworkCredential credential= new NetworkCredential(
                ConfigurationManager.AppSettings["Username"],
                ConfigurationManager.AppSettings["Password"]
                //, ConfigurationManager.AppSettings["Domain"]
                );            
            tfsServer.Credentials = credential;

            tfsServer.Connect(ConnectOptions.None);
            Console.WriteLine("TFS Server : {0}\n"
                , tfsServer.Name
                );

            var teamCollections = tfsServer.CatalogNode.QueryChildren(
                new[] { CatalogResourceTypes.ProjectCollection },
                false, CatalogQueryOptions.None);

            foreach (var teamCollection in teamCollections)
            {
                Guid teamCollectionId = new Guid(teamCollection.Resource.Properties["InstanceId"]);
                TfsTeamProjectCollection teamProjectCollection = tfsServer.GetTeamProjectCollection(teamCollectionId);

                Console.WriteLine("Team Project Collection : {0}\n"
                    , teamProjectCollection.Name
                    );

                var teamProjects = teamCollection.QueryChildren(
                    new[] { CatalogResourceTypes.TeamProject },
                    false, CatalogQueryOptions.None);

                foreach (CatalogNode teamProject in teamProjects)
                {
                    Console.WriteLine("Team Project {0}\n\tDescription {1}"
                        , teamProject.Resource.DisplayName
                        , teamProject.Resource.Description
                        );
                }
            }
            
            #endregion Team Collection -> Team Projects Listelerinin Okunması


            #region Bir Team Collection' daki Task' ların Çekilmesi

//            TfsTeamProjectCollection tfsCollection = new TfsTeamProjectCollection(
//                new Uri(ConfigurationManager.AppSettings["TfsAddress"] + "/DefaultCollection"));
//            tfsCollection.Credentials = new NetworkCredential(
//                ConfigurationManager.AppSettings["Username"],
//                ConfigurationManager.AppSettings["Password"]
//                , ConfigurationManager.AppSettings["Domain"]
//                );

//            WorkItemStore store = (WorkItemStore)tfsCollection.GetService(typeof(WorkItemStore));

//            WorkItemCollection queryResults = store.Query(@"
//                           Select [State], [Title] 
//                           From WorkItems
//                           Where [Work Item Type] = 'Task' and [Team Project]='ARGE'
//                           Order By [State] Asc, [Changed Date] Desc");

//            for (int i = 0; i < queryResults.Count; i++)
//            {
//                Console.WriteLine("{0}\n{1}\n{2}\n", queryResults[i].Title, queryResults[i].State, queryResults[i].ChangedDate.ToString());
//            }

            #endregion Bir Team Collection' daki Task' ların Çekilmesi
        }
    }
}
