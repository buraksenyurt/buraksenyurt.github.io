﻿using System.Transactions;
using WorkflowConsoleApplication1.localhost;

namespace WorkflowConsoleApplication1
{
    public class Excecuter
    {
        public static int InsertBranchFromWebService(int branchId,string title,int code)
        {
            WebService1 service = new WebService1();
            byte[] propToken = TransactionInterop.GetTransmitterPropagationToken(Transaction.Current);
            return service.InsertBranch(branchId, title, code, propToken);
        }
    }
}
