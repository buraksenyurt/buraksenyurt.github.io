﻿using System;
using System.Activities;

namespace WorkflowConsoleApplication1
{

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Activity wf = new Activity1();
                WorkflowInvoker.Invoke(wf);
            }
            catch (Exception excp)
            {
                Console.WriteLine(excp.Message);
            }
        }
    }
}
