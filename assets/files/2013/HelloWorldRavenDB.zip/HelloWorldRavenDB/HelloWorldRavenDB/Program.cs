﻿using Raven.Client.Document;
using System;
using System.Linq;

namespace HelloWorldRavenDB
{
    class Program
    {
        static DocumentStore docStore = null;

        static void Main(string[] args)
        {            
            docStore=new DocumentStore { ConnectionStringName = "RavenDBConnection" };
            docStore.Initialize();

            #region Örnek ürünlerin eklenmesi

            AddProduct(new Product
            {
                Id="9",
                ProductNumber = "E1-1001",
                Title = "LG-Optical Mouse",
                ListPrice = 34.50,
                StockLevel = 100
            }
            );

            AddProduct(new Product
            {
                Id = "7",
                ProductNumber = "E1-1002",
                Title = "LG-Optical Keyboard",
                ListPrice = 44.25,
                StockLevel = 85
            }
            );

            AddProduct(new Product
            {
                Id = "8",
                ProductNumber = "B1-1005",
                Title = "SOA Design Patterns",
                ListPrice = 49.95,
                StockLevel = 12
            }
            );

            #endregion

            ListAllProducts();

            ChangeStockLevel("8",45);            

            ListAllProducts();

            DeleteProductByNumber("B1-1005");

            Product product=FindProductByNumber("E1-1002");
            Console.WriteLine(product.Title);
        }

        private static void AddProduct(Product newProduct)
        {
            using (var session = docStore.OpenSession())
            {                
                session.Store(newProduct);
                session.SaveChanges();
            }
        }

        private static void ChangeStockLevel(string id,int newStockLevel)
        {
            using (var session = docStore.OpenSession())
            {
                Product product = session.Load<Product>(id);
                if(product!=null)
                {                   
                    product.StockLevel = newStockLevel;
                    session.SaveChanges();
                }
            }
        }

        private static void DeleteProductByNumber(string productNumber)
        {
            using (var session = docStore.OpenSession())
            {
                Product product = session
                    .Query<Product>()
                    .Where(p => p.ProductNumber == productNumber)
                    .SingleOrDefault();
                if (product != null)
                {
                    session.Delete(product);
                    session.SaveChanges();
                }
            }
        }

        private static void ListAllProducts()
        {
            using (var session = docStore.OpenSession())
            {
                var products = session.Query<Product>()
                    .OrderBy(p => p.Title)
                    .ToList();

                foreach (var product in products)
                {
                    Console.WriteLine("{0}-{1},{2},{3}"
                        ,product.ProductNumber
                        ,product.Title
                        ,product.ListPrice.ToString("C2")
                        ,product.StockLevel.ToString());
                }
                Console.WriteLine("");
            }
        }

        private static Product FindProductByNumber(string productNumber)
        {
            using (var session = docStore.OpenSession())
            {
                return session
                    .Query<Product>()
                    .Where(p => p.ProductNumber == productNumber)
                    .SingleOrDefault();
            }
        }
    }

    class Product
    {
        public string Id { get; set; }
        public string ProductNumber { get; set; }
        public string Title { get; set; }
        public double ListPrice { get; set; }
        public int StockLevel { get; set; }
    }
}
